<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// FRAMEWORK SETTINGS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$settings           = array(
  'menu_title'      => esc_html__('Theme Options', 'bready-helpers'),
  'menu_type'       => 'menu', // menu, submenu, options, theme, etc.
  'menu_slug'       => '_noubready_options',
  'ajax_save'       => false,
  'show_reset_all'  => false,
  'framework_title' => esc_html__('Bready Theme', 'bready-helpers').' '.BREADY_HELPERS_VER,
);

// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// FRAMEWORK OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options        = array();
$options[]    = array(
  'name'      => 'section_1',
  'title'     => 'Section #1',
  'icon'      => 'fa fa-repeat',
  'fields'    => array(

	// a text field
	array(
	  'id'    => 'section_1_text',
	  'type'  => 'text',
	  'title' => 'Text Option Field',
	),

	// a textarea field
	array(
	  'id'    => 'section_1_textarea',
	  'type'  => 'textarea',
	  'title' => 'Textarea Option Field',
	),

  )
);
Bready_Helpers_CSFramework::instance( $settings, $options );
