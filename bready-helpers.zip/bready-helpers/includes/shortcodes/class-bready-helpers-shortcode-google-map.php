<?php
/**
* 
*/
class Bready_Helpers_Shortcode_Google_Map
{
	
	public static function shortcode($atts){
		$atts = shortcode_atts( array(
			'title' => '',
		), $atts, 'noubready_google_map' );

		ob_start(); 
			?>
			<div id="contact-map" data-type="<?php echo esc_attr(noubready_theme_option('noubready_map_type', 'address'));?>" data-address="<?php echo esc_attr(noubready_theme_option('noubready_map_address'));?>" data-lng="<?php echo esc_attr(noubready_theme_option('noubready_map_longitude'));?>" data-lat="<?php echo esc_attr(noubready_theme_option('noubready_map_latitude'));?>" data-zoom="<?php echo esc_attr(noubready_theme_option('noubready_map_zoom', 17));?>" data-icon="<?php echo esc_attr(noubready_theme_option('noubready_map_marker', BREADY_HELPERS_URL.'public/images/marker.png'));?>" data-title="<?php echo esc_attr(noubready_theme_option('noubready_map_address'));?>"></div>
			<?php
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Bready - Google map", 'bready-helpers' ),
	      	"base" => "noubready_google_map",
	      	"class" => "",
	      	"category" => esc_html__( "Bready Theme", 'bready-helpers'),
    		"params" => array(
		     
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "heading" => esc_html__( "Title", 'bready-helpers' ),
		            "param_name" => "title"
		        ),
	      	)
	    ) );
		endif;
	}
}