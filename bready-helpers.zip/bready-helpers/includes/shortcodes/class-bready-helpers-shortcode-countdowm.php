<?php
/**
* 
*/
class Bready_Helpers_Shortcode_Countdowm
{
	
	/**
	 * Countdowm
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		$atts = shortcode_atts( array(
			'width' => ''
		), $atts, 'noubready_countdown' );
		
		$width = !empty($atts['width']) ? $atts['width'] : '';
		ob_start();
			if(!empty($content)):
			?>
			<div class="ps-about-number">
				<div class="<?php echo esc_attr($width); ?>">
					<div class="row">
		          		<?php echo do_shortcode($content);?>
		          	</div>
		        </div>
		    </div>
			<?php	
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Bready - Countdown", "bready-helpers" ),
	      	"base" => "noubready_countdown",
	      	"class" => "",
	      	"category" => esc_html__( "Bready Theme", "bready-helpers"),
	      	"params" => array(

	      		array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Width', 'bready-helpers' ),
					'param_name' => 'width',
					'value' => array(
						esc_html__( 'Default', 'bready-helpers' ) => 'ps-container',
						esc_html__( 'Container', 'bready-helpers' ) => 'container',
						esc_html__( 'Full width', 'bready-helpers' ) => 'none',
					),
				),

	      	),
	      	"as_parent" => array('only' => 'noubready_countdown_item'),
	      	"content_element" => true,
		    "show_settings_on_create" => false,
		    "is_container" => true,
		    "js_view" => 'VcColumnView'
	    ) );
		endif;
	}
}
?>