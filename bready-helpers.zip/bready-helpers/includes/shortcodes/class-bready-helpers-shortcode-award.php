<?php
/**
* 
*/
class Bready_Helpers_Shortcode_Award
{
	
	public static function shortcode($atts){
		$atts = shortcode_atts( array(
			'title' => '',
			'subtitle' => '',
			'desc' => '',
			'icon' => '',
			'size' => 'full',
		), $atts, 'noubready_award' );
		
		$icon = '';
		
		if(!empty($atts['icon'])){
			$image = wp_get_attachment_image_src($atts['icon'], $atts['size']);
			if($image){
				$icon = $image[0];
			}
		}
		ob_start();
			?>
			<div class="ps-block--award">
				<?php if(!empty($icon)){ ?>
					<img src="<?php echo esc_attr($icon);?>" alt="<?php echo esc_attr($atts['title']);?>" />
				<?php }?>
				<?php if(!empty($atts['title'])){?>
					<h4>
						<?php echo esc_html($atts['title']);?> 
						<?php if(!empty($atts['subtitle'])){?>
							<span><?php echo esc_html($atts['subtitle']);?></span>
						<?php }?>
					</h4>
				<?php }?>
				<?php if(!empty($atts['desc'])){?><?php echo wpautop(esc_html($atts['desc']));?><?php }?>
            </div>
			<?php
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Bready - Icon Award", 'bready-helpers' ),
	      	'description' => esc_html__('Icon with content', 'bready-helpers'),
	      	"base" => "noubready_award",
	      	"class" => "",
	      	"category" => esc_html__( "Bready Theme", 'bready-helpers'),
    		"params" => array(
			
				array(
		            "type" => "textfield",
		            "holder" => "div",
		            "heading" => esc_html__( "Title", 'bready-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textfield",
		            "heading" => esc_html__( "Subtitle", 'bready-helpers' ),
		            "param_name" => "subtitle",
		        ),
		        array(
		            "type" => "textarea",
		            "heading" => esc_html__( "Description", 'bready-helpers' ),
		            "param_name" => "desc",
		        ),
				
				array(
		            "type" => "attach_image",
		            "class" => "",
					"heading" => esc_html__( "Icon", 'bready-helpers' ),
					"description" 	=> "Select icon image",
		            "param_name" => "icon",
				),
				array(
		            "type" => "textfield",
					"heading" => esc_html__( "Size", 'bready-helpers' ),
					"description" 	=> "You can choose one of the sizes: thumbnail, medium, large, full. Default size: full",
		            "param_name" => "size",
				),
	      	)
	    ) );
		endif;
	}
}