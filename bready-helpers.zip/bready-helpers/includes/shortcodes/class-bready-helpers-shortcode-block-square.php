<?php
/**
* 
*/
class Bready_Helpers_Shortcode_Block_Square
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		$atts = shortcode_atts( array(
			'class'=> ''
		), $atts, 'noubready_block_square' );
		
		ob_start();
			if(!empty($content)):
			?>
			<div class="ps-home-contact">
				<div class="ps-container">
					<div class="ps-block--square-grid">
		          		<?php echo do_shortcode($content);?>
		          	</div>
		        </div>
		    </div>
			<?php	
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Bready - Block Square Grid", "bready-helpers" ),
	      	"base" => "noubready_block_square",
	      	"class" => "",
	      	"category" => esc_html__( "Bready Theme", "bready-helpers"),
	      	"params" => array(
				array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Custom Class", 'bready-helpers' ),
		            "param_name" => "class",
		        ),

	      	),
	      	"as_parent" => array('only' => 'noubready_block_square_item'),
	      	"content_element" => true,
		    "show_settings_on_create" => false,
		    "is_container" => true,
		    "js_view" => 'VcColumnView'
	    ) );
		endif;
	}
}
?>