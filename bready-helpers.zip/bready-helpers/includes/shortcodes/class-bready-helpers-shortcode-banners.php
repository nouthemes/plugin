<?php
/**
* 
*/
class Bready_Helpers_Shortcode_Banners
{
	
	public static function shortcode($atts){
		$atts = shortcode_atts( array(
			'img' => '',
			'img2' => '',
		), $atts, 'noubready_banners' );

		$img = $img2 = '';
		
		if(!empty($atts['img'])){
			$image = wp_get_attachment_image_src($atts['img'], 'full');
			if($image){
				$img = $image[0];
			}
		}
		if(!empty($atts['img2'])){
			$image2 = wp_get_attachment_image_src($atts['img2'], 'full');
			if($image2){
				$img2 = $image2[0];
			}
		}
		ob_start(); 
			if(!empty($img) && !empty($img2)):
			?>
				<div class="ps-section__images">
					<img src="<?php echo esc_url($img);?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>">
					<img src="<?php echo esc_url($img2);?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>">
				</div>
			<?php
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Bready - Banner Simple", 'bready-helpers' ),
	      	'description' => esc_html__('Banner simple just image.', 'bready-helpers'),
	      	"base" => "noubready_banners",
	      	"class" => "",
	      	"category" => esc_html__( "Bready Theme", 'bready-helpers'),
    		"params" => array(
		        array(
		            "type" => "attach_image",
		            "class" => "",
					"heading" => esc_html__( "Image", 'bready-helpers' ),
					"description" 	=> "Select image",
		            "param_name" => "img",
				),
				array(
		            "type" => "attach_image",
		            "class" => "",
					"heading" => esc_html__( "Image 2", 'bready-helpers' ),
					"description" 	=> "Select image",
		            "param_name" => "img2",
				),
	      	)
	    ) );
		endif;
	}
}