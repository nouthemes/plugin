<?php
/**
* 
*/
class Bready_Helpers_Shortcode_Feature
{
	
	public static function shortcode($atts){
		$atts = shortcode_atts( array(
			'title' => '',
			'subtitle' => '',
			'desc' => '',
			'type' => '',
			'icon_fontawesome' => '',
			'icon_openiconic' => '',
			'icon_typicons' => '',
			'icon_entypo' => '',
			'icon_linecons' => '',
			'icon_monosocial' => '',
			'icon_material' => '',
			'icon_custom' => '',
		), $atts, 'noubready_feature' );
		
		$type = !empty($atts['type']) ? $atts['type'] : 'fontawesome';
		ob_start();
			?>
			<div class="ps-block--iconbox" data-mh="icon">
				<?php if(!empty($atts['icon_'.$type])){?>
					<i class="<?php echo esc_attr($atts['icon_'.$type]);?>"></i>
				<?php }?>
				<?php if(!empty($atts['title'])){?>
					<h4>
						<?php echo esc_html($atts['title']);?> 
						<?php if(!empty($atts['subtitle'])){?>
							<span><?php echo esc_html($atts['subtitle']);?></span>
						<?php }?>
					</h4>
				<?php }?>
				<?php if(!empty($atts['desc'])){?><?php echo wpautop(esc_html($atts['desc']));?><?php }?>
            </div>
			<?php
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Bready - Icon Feature", 'bready-helpers' ),
	      	'description' => esc_html__('Icon with content', 'bready-helpers'),
	      	"base" => "noubready_feature",
	      	"class" => "",
	      	"category" => esc_html__( "Bready Theme", 'bready-helpers'),
    		"params" => array(
		    
				array(
		            "type" => "textfield",
		            "holder" => "div",
		            "heading" => esc_html__( "Title", 'bready-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textfield",
		            "heading" => esc_html__( "Subtitle", 'bready-helpers' ),
		            "param_name" => "subtitle",
		        ),
		        array(
		            "type" => "textarea",
		            "heading" => esc_html__( "Description", 'bready-helpers' ),
		            "param_name" => "desc",
		        ),
				
		        array(
					'type' => 'dropdown',
					'heading' => __( 'Icon library', 'bready-helpers' ),
					'value' => array(
						__( 'Font Awesome', 'bready-helpers' ) => 'fontawesome',
						__( 'Open Iconic', 'bready-helpers' ) => 'openiconic',
						__( 'Typicons', 'bready-helpers' ) => 'typicons',
						__( 'Entypo', 'bready-helpers' ) => 'entypo',
						__( 'Linecons', 'bready-helpers' ) => 'linecons',
						__( 'Mono Social', 'bready-helpers' ) => 'monosocial',
						__( 'Material', 'bready-helpers' ) => 'material',
						__( 'Custom', 'bready-helpers' ) => 'custom',
					),
					'admin_label' => true,
					'param_name' => 'type',
					'description' => __( 'Select icon library.', 'bready-helpers' ),
		            'group' => esc_html__('Icon', 'bready-helpers'),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'bready-helpers' ),
					'param_name' => 'icon_fontawesome',
					'value' => 'fa fa-adjust',
					// default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => false,
						// default true, display an "EMPTY" icon?
						'iconsPerPage' => 4000,
						// default 100, how many icons per/page to display, we use (big number) to display all icons in single page
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'fontawesome',
					),
					'description' => __( 'Select icon from library.', 'bready-helpers' ),
					'group' => esc_html__('Icon', 'bready-helpers'),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'bready-helpers' ),
					'param_name' => 'icon_openiconic',
					'value' => 'vc-oi vc-oi-dial',
					// default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => false,
						// default true, display an "EMPTY" icon?
						'type' => 'openiconic',
						'iconsPerPage' => 4000,
						// default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'openiconic',
					),
					'description' => __( 'Select icon from library.', 'bready-helpers' ),
					'group' => esc_html__('Icon', 'bready-helpers'),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'bready-helpers' ),
					'param_name' => 'icon_typicons',
					'value' => 'typcn typcn-adjust-brightness',
					// default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => false,
						// default true, display an "EMPTY" icon?
						'type' => 'typicons',
						'iconsPerPage' => 4000,
						// default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'typicons',
					),
					'description' => __( 'Select icon from library.', 'bready-helpers' ),
					'group' => esc_html__('Icon', 'bready-helpers'),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'bready-helpers' ),
					'param_name' => 'icon_entypo',
					'value' => 'entypo-icon entypo-icon-note',
					// default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => false,
						// default true, display an "EMPTY" icon?
						'type' => 'entypo',
						'iconsPerPage' => 4000,
						// default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'entypo',
					),
					'group' => esc_html__('Icon', 'bready-helpers'),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'bready-helpers' ),
					'param_name' => 'icon_linecons',
					'value' => 'vc_li vc_li-heart',
					// default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => false,
						// default true, display an "EMPTY" icon?
						'type' => 'linecons',
						'iconsPerPage' => 4000,
						// default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'linecons',
					),
					'description' => __( 'Select icon from library.', 'bready-helpers' ),
					'group' => esc_html__('Icon', 'bready-helpers'),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'bready-helpers' ),
					'param_name' => 'icon_monosocial',
					'value' => 'vc-mono vc-mono-fivehundredpx',
					// default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => false,
						// default true, display an "EMPTY" icon?
						'type' => 'monosocial',
						'iconsPerPage' => 4000,
						// default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'monosocial',
					),
					'description' => __( 'Select icon from library.', 'bready-helpers' ),
					'group' => esc_html__('Icon', 'bready-helpers'),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'bready-helpers' ),
					'param_name' => 'icon_material',
					'value' => 'vc-material vc-material-cake',
					// default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => false,
						// default true, display an "EMPTY" icon?
						'type' => 'material',
						'iconsPerPage' => 4000,
						// default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'material',
					),
					'description' => __( 'Select icon from library.', 'bready-helpers' ),
					'group' => esc_html__('Icon', 'bready-helpers'),
				),
				array(
		            "type" => "textfield",
		            "heading" => esc_html__( "Custom Icon", 'bready-helpers' ),
		            "param_name" => "icon_custom",
		            'dependency' => array(
						'element' => 'type',
						'value' => 'custom',
					),
					'group' => esc_html__('Icon', 'bready-helpers'),
		        ),
	      	)
	    ) );
		endif;
	}
}