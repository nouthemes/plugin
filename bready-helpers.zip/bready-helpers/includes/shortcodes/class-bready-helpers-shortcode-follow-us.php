<?php
/**
* 
*/
class Bready_Helpers_Shortcode_Follow_Us
{
	
	public static function shortcode($atts){
		$atts = shortcode_atts( array(
			'title' => '',
			'facebook' => '',
			'google' => '',
			'twitter' => '',
			'linkedin' => '',
			'pinterest' => '',
			'instagram' => '',
			'tumblr' => '',
			'dribbble' => '',
			'feed' => '',
		), $atts, 'noubready_follow_us' );

		$title = !empty($atts['title']) ? $atts['title'] : '';
		$facebook = !empty($atts['facebook']) ? $atts['facebook'] : '';
		$google = !empty($atts['google']) ? $atts['google'] : '';
		$twitter = !empty($atts['twitter']) ? $atts['twitter'] : '';
		$linkedin = !empty($atts['linkedin']) ? $atts['linkedin'] : '';
		$pinterest = !empty($atts['pinterest']) ? $atts['pinterest'] : '';
		$instagram = !empty($atts['instagram']) ? $atts['instagram'] : '';
		$tumblr = !empty($atts['tumblr']) ? $atts['tumblr'] : '';
		$dribbble = !empty($atts['dribbble']) ? $atts['dribbble'] : '';
		$feed = !empty($atts['feed']) ? $atts['feed'] : '';

		ob_start();
		?>
		<div class="ps-block--contact-2">
			<?php if(!empty($title)){ ?><h3><?php echo esc_html($title);?></h3><?php } ?>
			<ul class="ps-list--social ps-list--social-simple">
			  <?php if(!empty($facebook)):?><li><a href="<?php echo esc_url($facebook);?>"><i class="fa fa-facebook"></i></a></li><?php endif;?>
			  <?php if(!empty($google)):?><li><a href="<?php echo esc_url($google);?>"><i class="fa fa-google-plus"></i></a></li><?php endif;?>
			  <?php if(!empty($twitter)):?><li><a href="<?php echo esc_url($twitter);?>"><i class="fa fa-twitter"></i></a></li><?php endif;?>
			  <?php if(!empty($linkedin)):?><li><a href="<?php echo esc_url($linkedin);?>"><i class="fa fa-linkedin"></i></a></li><?php endif;?>
			  <?php if(!empty($pinterest)):?><li><a href="<?php echo esc_url($pinterest);?>"><i class="fa fa-pinterest"></i></a></li><?php endif;?>
			  <?php if(!empty($instagram)):?><li><a href="<?php echo esc_url($instagram);?>"><i class="fa fa-instagram"></i></a></li><?php endif;?>
			  <?php if(!empty($tumblr)):?><li><a href="<?php echo esc_url($tumblr);?>"><i class="fa fa-tumblr"></i></a></li><?php endif;?>
			  <?php if(!empty($dribbble)):?><li><a href="<?php echo esc_url($dribbble);?>"><i class="fa fa-dribbble"></i></a></li><?php endif;?>
			  <?php if(!empty($feed)):?><li><a href="<?php echo esc_url($feed);?>"><i class="fa fa-feed"></i></a></li><?php endif;?>
			</ul>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Bready - Follow Us", 'bready-helpers' ),
	      	"base" => "noubready_follow_us",
	      	"class" => "",
	      	"category" => esc_html__( "Bready Theme", 'bready-helpers'),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", 'bready-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Facebook Link", 'bready-helpers' ),
		            "param_name" => "facebook",
		        ),
				array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Google Plus Link", 'bready-helpers' ),
		            "param_name" => "google",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Twitter Link", 'bready-helpers' ),
		            "param_name" => "twitter",
		        ),
				array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Linkedin Link", 'bready-helpers' ),
		            "param_name" => "linkedin",
		        ),
				array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Pinterest Link", 'bready-helpers' ),
		            "param_name" => "pinterest",
		        ),
				array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Instagram Link", 'bready-helpers' ),
		            "param_name" => "instagram",
		        ),
				array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Tumblr Link", 'bready-helpers' ),
		            "param_name" => "tumblr",
		        ),
				array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Dribbble Link", 'bready-helpers' ),
		            "param_name" => "dribbble",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Feed Link", 'bready-helpers' ),
		            "param_name" => "feed",
		        ),
	      	)
	    ) );
		endif;
	}
}