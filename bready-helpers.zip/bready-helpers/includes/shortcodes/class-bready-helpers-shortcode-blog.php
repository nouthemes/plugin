<?php
/**
* 
*/
class Bready_Helpers_Shortcode_Blog
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		if(empty($atts)){
			return '';
		}

		$atts = shortcode_atts( array(
			'title' => '',
			'desc' => '',
			'ids' => '',
			'cat' => '',
			'number' => '',
		), $atts, 'noubready_posts' );
		
		$per_page = !empty($atts['number']) ? intval($atts['number']) : '3';
		$args = array(
			'post_type' => 'post', 
			'post_status' => 'publish',
			'posts_per_page' => $per_page,
			'category__not_in' => array( 1 )
			);

		if(!empty($atts['ids'])){
			$args['post__in'] = explode(',', $atts['ids']);
		}else{
			if(!empty($atts['cat'])){
				$args['tax_query'] = array(
					array(
						'taxonomy' => 'category',
						'field'    => 'term_id',
						'terms'    => $atts['cat'],
					),
				);
			}
		}

		$query = new WP_Query($args);
		ob_start();
			if($query->have_posts()):
				
				$link = home_url('/');
				$show_on_front = get_option('show_on_front');
				if($show_on_front == 'page'){
					$link = get_permalink(get_option('page_for_posts'));
				}
				?>
				
				<div class="ps-home-blog">
				  <div class="ps-container">
					<?php
					if(!empty($atts['title'])):
					?>
					<div class="ps-section__header">
						<h3 class="ps-section__title"><?php echo esc_html($atts['title']);?></h3>
						<?php if(!empty($atts['desc'])){  ?> <?php echo wpautop(esc_html($atts['desc']));?> <?php } ?>
						<span>
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/icons/floral.png" alt="<?php echo esc_attr($atts['title']);?>">
						</span>
					</div>
					<?php	
					endif;
					?>
					<div class="ps-section__content">
						<div class="row">
							<?php while($query->have_posts()): $query->the_post(); ?>
							<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
							  <article <?php post_class('ps-post'); ?>>
								<?php noubready_post_thumbnail('noubready_450x400'); ?>
								<div class="ps-post__content">
									<?php noubready_get_meta_post__date(); ?>
									<h3 class="ps-post__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
									
									<?php noubready_get_meta_post__byline() ?>
									
									<?php if('gallery' != get_post_format()):?>
										<p><?php echo wp_trim_words(get_the_excerpt(), 25, '...');?></p>
									<?php endif;?>
									
									<a class="ps-post__morelink" href="<?php the_permalink(); ?>"><?php esc_html_e('READ MORE', 'bready-helpers'); ?></a>
								</div>
							  </article>
							</div>
							<?php endwhile;?>	
						</div>
					</div>
				  </div>
				</div>
				<?php
			endif;
			wp_reset_postdata();
		return ob_get_clean();
	}

	/**
	 * Map shortcode Post items.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Bready - Posts", 'bready-helpers' ),
	      	"base" => "noubready_posts",
	      	"class" => "",
	      	"category" => esc_html__( "Bready Theme", 'bready-helpers'),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", 'bready-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Description", 'bready-helpers' ),
		            "param_name" => "desc",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "IDs posts, EX: 21,22,23", 'bready-helpers' ),
		            "param_name" => "ids",
		            'group' => esc_html__('Display', 'bready-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Category ID", 'bready-helpers' ),
		            "param_name" => "cat",
		            'group' => esc_html__('Display', 'bready-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Number of posts show(default 3)", 'bready-helpers' ),
		            "param_name" => "number",
		            'group' => esc_html__('Display', 'bready-helpers'),
		        ),
	      	)
	    ) );
		endif;
	}
}
?>