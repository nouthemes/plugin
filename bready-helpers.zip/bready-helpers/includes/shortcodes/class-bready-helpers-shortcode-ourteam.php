<?php
/**
* 
*/
class Bready_Helpers_Shortcode_Ourteam
{
	public static function shortcode($atts){
		$atts = shortcode_atts( array(
			'name' => '',
			'position' => '',
			'desc' => '',
			'tel' => '',
			'email' => '',
			'img' => '',
			'fb' => '',
			'twitter' => '',
			'dribbble' => '',
		), $atts, 'noubready_our_team' );
		
		$img = '';
		if(!empty($atts['img'])){
			$images = wp_get_attachment_image_src($atts['img'], 'noubready_330x495');
			if($images){
				$img = $images[0];
			}
		}
		ob_start();
		?>
			<div class="ps-block--people">
              	<?php if(!empty($img)): ?>
              	<div class="ps-block__thumbnail">
					<img src="<?php echo esc_url($img);?>" alt="<?php echo esc_attr($atts['name']);?>">
              	</div>
              	<?php endif;?>

              	<div class="ps-block__content">
					<div class="ps-block__header">
						<?php if(!empty($atts['name'])):?>
							<h3><?php echo esc_html($atts['name']);?></h3>
						<?php endif;?>
						<?php if(!empty($atts['position'])):?>
							<span><?php echo esc_html($atts['position']);?></span>
						<?php endif;?>
					</div>
				  
					<?php if(!empty($atts['desc'])):?>
					<?php echo wpautop(esc_html($atts['desc']));?>
					<?php endif;?>
					<div class="ps-block__footer">
						<p>
							<?php if(!empty($atts['tel'])):?>
								<?php esc_html_e('Tel: ', 'bready-helpers');?> <?php echo esc_html($atts['tel']);?>
							<?php endif;?>
							<br>
							<?php if(!empty($atts['email'])):?>
								<a href="mailto:<?php echo esc_attr($atts['email']);?>"><?php echo esc_html($atts['email']);?></a>
							<?php endif;?>
						</p>
						<ul class="ps-list--social">
						<?php if(!empty($atts['fb'])):?>
							<li><a href="<?php echo esc_url($atts['fb']);?>" target="_blank"><i class="fa fa-facebook"></i></a></li>
							<?php endif;?>


							<?php if(!empty($atts['twitter'])):?>
							<li><a href="<?php echo esc_url($atts['twitter']);?>" target="_blank"><i class="fa fa-twitter"></i></a></li>
							<?php endif;?>
							
							
							<?php if(!empty($atts['dribbble'])):?>
							<li><a href="<?php echo esc_url($atts['dribbble']);?>" target="_blank"><i class="fa fa-dribbble"></i></a></li>
							<?php endif;?>
						</ul>
					</div>
                    
              	</div>
            </div>
		<?php
		return ob_get_clean();
	}

	public static function map(){
		if(function_exists('vc_map')):
			vc_map( array(
		      	"name" => esc_html__( "Bready - Our team", "bready-helpers" ),
		      	"base" => "noubready_our_team",
		      	"class" => "",
		      	"category" => esc_html__( "Bready Theme", "bready-helpers"),
		      	"params" => array(
			        
			        array(
			            "type" => "textfield",
			            "holder" => "div",
			            "class" => "",
			            "heading" => esc_html__( "Name", "bready-helpers" ),
			            "param_name" => "name",
			        ),
			        array(
			            "type" => "textfield",
			            "class" => "",
			            "heading" => esc_html__( "Position", "bready-helpers" ),
			            "param_name" => "position",
			        ),
			        array(
			            "type" => "textarea",
			            "class" => "",
			            "heading" => esc_html__( "Description", "bready-helpers" ),
			            "param_name" => "desc",
			        ),
			        array(
			            "type" => "attach_image",
			            "class" => "",
			            "heading" => esc_html__( "Image", "bready-helpers" ),
			            "param_name" => "img",
			        ),
			        array(
			            "type" => "textfield",
			            "class" => "",
			            "heading" => esc_html__( "Phone", "bready-helpers" ),
			            "param_name" => "tel",
			        ),
					array(
			            "type" => "textfield",
			            "class" => "",
			            "heading" => esc_html__( "Email", "bready-helpers" ),
			            "param_name" => "email",
			        ),
			        array(
			            "type" => "textfield",
			            "class" => "",
			            "heading" => esc_html__( "Facebook URL", "bready-helpers" ),
			            "param_name" => "fb",
			            'group' => esc_html__('Social', 'bready-helpers'),
			        ),
			        array(
			            "type" => "textfield",
			            "class" => "",
			            "heading" => esc_html__( "Twitter URL", "bready-helpers" ),
			            "param_name" => "twitter",
			            'group' => esc_html__('Social', 'bready-helpers'),
			        ),
			        array(
			            "type" => "textfield",
			            "class" => "",
			            "heading" => esc_html__( "Dribbble URL", "bready-helpers" ),
			            "param_name" => "dribbble",
			            'group' => esc_html__('Social', 'bready-helpers'),
			        ),
		      	)
		    ) );
		endif;
	}
}
?>