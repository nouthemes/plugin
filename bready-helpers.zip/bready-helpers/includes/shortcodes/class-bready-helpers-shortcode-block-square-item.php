<?php
/**
* 
*/
class Bready_Helpers_Shortcode_Block_Square_Item
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		$atts = shortcode_atts( array(
			'type' => '',
			'img' => '',
			'type_content' => '',
			'title' => '',
			'subtitle' => '',
			'desc' => '',
			'email' => '',
			'name_btn' => '',
			'link_btn' => '',
			'class'=> ''
		), $atts, 'noubready_block_square_item' );
		$img = '';
		if(!empty($atts['img'])){
			$images = wp_get_attachment_image_src($atts['img'], 'noubready_345x360');
			if($images){
				$img = $images[0];
			}
		}
		ob_start();
			?>
			<div class="ps-block--square <?php echo esc_attr($atts['class']);?>">
				<div class="ps-block__thumbnail bg--cover" data-background="<?php echo esc_attr($img); ?>"></div>
				<div class="ps-block__content">
					<?php if($atts['type'] == 'map'): ?>
						<div id="contact-map" data-type="<?php echo esc_attr(noubready_theme_option('noubready_map_type', 'address'));?>" data-address="<?php echo esc_attr(noubready_theme_option('noubready_map_address'));?>" data-lng="<?php echo esc_attr(noubready_theme_option('noubready_map_longitude'));?>" data-lat="<?php echo esc_attr(noubready_theme_option('noubready_map_latitude'));?>" data-zoom="<?php echo esc_attr(noubready_theme_option('noubready_map_zoom', 17));?>" data-icon="<?php echo esc_attr(noubready_theme_option('noubready_map_marker', BREADY_HELPERS_URL.'public/images/marker.png'));?>" data-title="<?php echo esc_attr(noubready_theme_option('noubready_map_address'));?>"></div>
					<?php else: ?>
						
						<?php if($atts['type_content'] == 'type_button'): ?>
							<figure>
								<h3><?php echo esc_html($atts['title']);?></h3>
								<?php echo wp_kses_post(wpautop($atts['desc']));?>
								<a class="ps-btn" href="<?php echo esc_attr($atts['link_btn']);?>"><?php echo esc_html($atts['name_btn']);?></a>
							  </figure>
						<?php elseif($atts['type_content'] == 'time'): ?>
							<figure>
								<h3><?php echo esc_html($atts['title']);?></h3>
								<?php echo wp_kses_post(wpautop($atts['desc']));?>
							</figure>
						<?php else: ?>
							<h3><?php echo esc_html($atts['title']);?></h3>
							<h4><?php echo esc_html($atts['subtitle']);?></h4>
							<a href="mailto:<?php echo esc_attr($atts['email']);?>"><?php echo esc_html($atts['email']);?></a>
							  <?php echo wp_kses_post(wpautop($atts['desc']));?>
						<?php endif;?>
					<?php endif;?>
					
				</div>
			  </div>
			<?php
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		vc_map( array(
	      	"name" => esc_html__( "Bready - Block Square Item", 'bready-helpers' ),
	      	"base" => "noubready_block_square_item",
	      	"class" => "",
	      	"category" => esc_html__( "Bready Theme", 'bready-helpers'),
	      	"content_element" => true,
    		"as_child" => array('only' => 'noubready_block_square'),
    		"params" => array(
				array(
		            "type" => "dropdown",
		            "class" => "",
		            "holder" => "div",
		            "heading" => esc_html__( "Type of section show", 'bready-helpers' ),
		            "param_name" => "type",
		            "value" => array(
						esc_html__('Text', 'bready-helpers') => 'default', 
						esc_html__('Google Map', 'bready-helpers') => 'map'
					)
		        ),
				array(
					"type" => "attach_image",
					"class" => "",
					"heading" => esc_html__( "Background image", "bready-helpers" ),
					"param_name" => "img",
					'admin_label'=> false
				),
				array(
		            "type" => "dropdown",
		            "class" => "",
		            "holder" => "div",
		            "heading" => esc_html__( "Type content", 'bready-helpers' ),
		            "param_name" => "type_content",
		            "value" => array(
						esc_html__('Address', 'bready-helpers') => 'address', 
						esc_html__('Time Open', 'bready-helpers') => 'time',
						esc_html__('Button', 'bready-helpers') => 'type_button'
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'default',
					),
		        ),
				array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", 'bready-helpers' ),
		            "param_name" => "title",
					'admin_label'=> false,
					'dependency' => array(
						'element' => 'type',
						'value' => 'default',
					),
		        ),
				array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Sub Title", 'bready-helpers' ),
		            "param_name" => "subtitle",
					'admin_label'=> false,
					'dependency' => array(
						'element' => 'type_content',
						'value' => 'address',
					),
		        ),
		        array(
		            "type" => "textarea",
		            "class" => "",
		            "heading" => esc_html__( "Description", 'bready-helpers' ),
		            "param_name" => "desc",
					'dependency' => array(
						'element' => 'type',
						'value' => 'default',
					),
		        ),
				array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Email", 'bready-helpers' ),
		            "param_name" => "email",
					'admin_label'=> false,
					'dependency' => array(
						'element' => 'type_content',
						'value' => 'address',
					),
		        ),
				
				array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Button Name", 'bready-helpers' ),
		            "param_name" => "name_btn",
					'admin_label'=> false,
					'dependency' => array(
						'element' => 'type_content',
						'value' => 'type_button',
					),
		        ),
				array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Link Button", 'bready-helpers' ),
		            "param_name" => "link_btn",
					'admin_label'=> false,
					'dependency' => array(
						'element' => 'type_content',
						'value' => 'type_button',
					),
		        ),
				array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Custom Class", 'bready-helpers' ),
		            "param_name" => "class",
					'admin_label'=> false
		        ),
	      	)
	    ) );
	}
}
?>