<?php
/**
* 
*/
class Bready_Helpers_Shortcode_Quote
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		$atts = shortcode_atts( array(
			'type' => '',
			'title' => '',
			'name' => '',
			'desc' => '',
			'img' => '',
			'signature' => '',
			'class'=> ''
		), $atts, 'noubready_quote' );
		$img = $signature = '';
		if(!empty($atts['img'])){
			$images = wp_get_attachment_image_src($atts['img'], 'full');
			if($images){
				$img = $images[0];
			}
		}
		if(!empty($atts['signature'])){
			$signatures = wp_get_attachment_image_src($atts['signature'], 'full');
			if($signatures){
				$signature = $signatures[0];
			}
		}
		
		ob_start(); ?>
			<?php if($atts['type'] == 'style-3') : ?>
				<div class="ps-section__header">
					<?php if(!empty($atts['title'])):?><h3 class="ps-section__title"><?php echo esc_html($atts['title']);?></h3><?php endif;?>
					<?php echo wpautop($atts['desc']);?>
					<?php if(!empty($atts['name'])):?><small><?php echo esc_html($atts['name']);?></small><?php endif;?>
					<img src="<?php echo esc_url($signature);?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>">
				</div>
			<?php else : ?>
			<div class="ps-block--signature <?php if($atts['type'] == 'style-2') { echo 'ps-block--signature--2'; } ?>">
				<div class="ps-block__thumbnail"><img src="<?php echo esc_url($img);?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>"></div>
				<div class="ps-block__content">
					<?php if($atts['type'] == 'style-2'): ?>
						<?php if(!empty($atts['name'])):?><h3><?php echo esc_html($atts['name']);?></h3><?php endif;?>
						<?php echo wpautop($atts['desc']);?>
					<?php else: ?>
						<?php echo wpautop($atts['desc']);?>
						<?php if(!empty($atts['name'])):?><small><?php echo esc_html($atts['name']);?></small><?php endif;?>
					<?php endif;?>
					<img src="<?php echo esc_url($signature); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>">
				</div>
			</div>
	  
			<?php	
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		vc_map( array(
	      	"name" => esc_html__( "Bready - Quote", 'bready-helpers' ),
	      	"base" => "noubready_quote",
	      	"class" => "",
	      	"category" => esc_html__( "Bready Theme", 'bready-helpers'),
    		"params" => array(
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Style', 'bready-helpers' ),
					'param_name' => 'type',
					'value' => array(
						esc_html__( 'Style 1', 'bready-helpers' ) => 'style-1',
						esc_html__( 'Style 2', 'bready-helpers' ) => 'style-2',
						esc_html__( 'Style 3', 'bready-helpers' ) => 'style-3',
					),
				),
				array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", 'bready-helpers' ),
		            "param_name" => "title",
					'dependency' => array(
						'element' => 'type',
						'value' => 'style-3',
					),
		        ),
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Name", 'bready-helpers' ),
		            "param_name" => "name",
		        ),
		        array(
		            "type" => "textarea",
		            "class" => "",
		            "heading" => esc_html__( "Quote", 'bready-helpers' ),
		            "param_name" => "desc",
		        ),
				array(
					"type" => "attach_image",
					"class" => "",
					"heading" => esc_html__( "Image", "bready-helpers" ),
					"param_name" => "img",
				),
				array(
					"type" => "attach_image",
					"class" => "",
					"heading" => esc_html__( "Signature ", "bready-helpers" ),
					"param_name" => "signature",
				),
	      	)
	    ) );
	}
}
?>