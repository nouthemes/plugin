<?php
/**
* 
*/
class Bready_Helpers_Shortcode_Sectiontitle
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		$atts = shortcode_atts( array(
			'title' => '',
			'sub' => '',
		), $atts, 'noubready_section_title' );
		
		ob_start();
			if(!empty($atts['title'])):
			?>
			<div class="ps-section__header text-center">
				<h3 class="ps-section__title"><?php echo esc_html($atts['title']);?></h3>
				<?php if(!empty($atts['sub'])){  ?> <p><?php echo esc_html($atts['sub']); ?></p><?php } ?>
				<span><img src="<?php echo get_template_directory_uri(); ?>/assets/images/icons/floral.png" alt="<?php echo esc_attr($atts['title']);?>"></span>
			</div>
		
			<?php	
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Bready - Section Title", 'bready-helpers' ),
	      	"base" => "noubready_section_title",
	      	"class" => "",
	      	"category" => esc_html__( "Bready Theme", 'bready-helpers'),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", 'bready-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Subtitle", 'bready-helpers' ),
		            "param_name" => "sub",
		        ),
	      	)
	    ) );
		endif;
	}
}
?>