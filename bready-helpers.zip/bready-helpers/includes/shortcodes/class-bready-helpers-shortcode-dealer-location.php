<?php
/**
* 
*/
class Bready_Helpers_Shortcode_Dealer_Location
{
	
	public static function shortcode($atts){
		$atts = shortcode_atts( array(
			'title' => '',
			'address' => '',
			'email' => '',
			'phone' => '',
		), $atts, 'noubready_dealer_location' );

		$title = !empty($atts['title']) ? $atts['title'] : '';
		$address = !empty($atts['address']) ? $atts['address'] : '';
		$email = !empty($atts['email']) ? $atts['email'] : '';
		$phone = !empty($atts['phone']) ? $atts['phone'] : '';

		ob_start();
		?>
		<div class="ps-block--contact-2">
			<?php if(!empty($title)){ ?><h3><?php echo esc_html($title);?></h3><?php } ?>
			<?php if(!empty($address)){ ?><h4><?php echo esc_html($address); ?></h4><?php } ?>
			<?php if(!empty($email)):?><p><i class="fa fa-envelope-o"></i><a href="mailto:<?php echo esc_html($email);?>"><?php echo esc_html($email);?></a></p><?php endif;?>
			<?php if(!empty($phone)):?><p><i class="fa fa-phone"></i> <?php echo esc_html($phone);?></p><?php endif;?>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Bready - Dealer Location", 'bready-helpers' ),
	      	"base" => "noubready_dealer_location",
	      	"class" => "",
	      	"category" => esc_html__( "Bready Theme", 'bready-helpers'),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", 'bready-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Address", 'bready-helpers' ),
		            "param_name" => "address",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Email", 'bready-helpers' ),
		            "param_name" => "email",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Phone", 'bready-helpers' ),
		            "param_name" => "phone",
		        ),
	      	)
	    ) );
		endif;
	}
}