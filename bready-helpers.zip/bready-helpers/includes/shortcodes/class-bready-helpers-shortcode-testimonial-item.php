<?php
/**
* 
*/
class Bready_Helpers_Shortcode_Testimonial_Item
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		$atts = shortcode_atts( array(
			'name' => '',
			'position' => '',
			'rating' => '',
			'img' => '',
			'desc' => '',
		), $atts, 'noubready_testimonial_item' );
		
		ob_start();
			if(!empty($atts['desc'])):
			?>
			<div class="ps-block--tesimonial">
				<?php 
				if($atts['img']):
				$image = wp_get_attachment_image_src($atts['img'], 'thumbnail');
				if($image){	
				?>
				<div class="ps-block__user"><img src="<?php echo esc_url($image[0]);?>" alt="<?php echo esc_attr($atts['name']);?>"></div>
				<?php }endif;?>
				
				<div class="ps-block__content">
					<?php if(!empty($atts['rating'])):?>
						<select class="ps-rating">
						  <option value="1" <?php selected($atts['rating'], 1);?>>1</option>
						  <option value="2" <?php selected($atts['rating'], 2);?>>2</option>
						  <option value="3" <?php selected($atts['rating'], 3);?>>3</option>
						  <option value="4" <?php selected($atts['rating'], 4);?>>4</option>
						  <option value="5" <?php selected($atts['rating'], 5);?>>5</option>
						</select>
					<?php endif;?>
					<?php echo wpautop(esc_html($atts['desc']));?>
				</div>
				
				<div class="ps-block__footer">
				  <p><?php if(!empty($atts['name'])):?><strong><?php echo esc_html($atts['name']);?></strong><?php endif;?> - <?php if(!empty($atts['position'])): echo esc_html($atts['position']); endif;?></p>
				</div>
				
            </div>
			<?php	
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		vc_map( array(
	      	"name" => esc_html__( "Bready - Testimonial Item", 'bready-helpers' ),
	      	"base" => "noubready_testimonial_item",
	      	"class" => "",
	      	"category" => esc_html__( "Bready Theme", 'bready-helpers'),
	      	"content_element" => true,
    		"as_child" => array('only' => 'noubready_testimonial'),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Name", 'bready-helpers' ),
		            "param_name" => "name",
		        ),
				array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Position", 'bready-helpers' ),
		            "param_name" => "position",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Rating", 'bready-helpers' ),
		            "param_name" => "rating",
		        ),
		        array(
		            "type" => "attach_image",
		            "class" => "",
		            "heading" => esc_html__( "Image", 'bready-helpers' ),
		            "param_name" => "img",
		        ),
		        array(
		            "type" => "textarea",
		            "class" => "",
		            "heading" => esc_html__( "Description", 'bready-helpers' ),
		            "param_name" => "desc",
		        )
	      	)
	    ) );
	}
}
?>