<?php
/**
* 
*/
class Bready_Helpers_Shortcode_Products
{
	
	/**
	 * Products
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		if ( empty( $atts ) ) {
			return '';
		}

		$atts = shortcode_atts( array(
			'style' => '',
			'bg' => '',
			'title' => '',
			'subtitle' => '',
			'type' => '',
			'size' => '',
			'ids' => '',
			'cat' => '',
			'number' => '',
			'order_by' => '',
			'class' => '',
		), $atts, 'noubready_products' );
		
		$bg = '';
		if(!empty($atts['bg'])){
			$images = wp_get_attachment_image_src($atts['bg'], 'full');
			if($images){
				$bg = $images[0];
			}
		}
		$products = self::get_products($atts);
		ob_start();
			if($products->have_posts()):
			?>
			<div class="ps-home-product <?php echo esc_attr($atts['class']); ?>" data-background="<?php echo esc_attr($bg); ?>">
				<div class="ps-container">
					<?php
					if(!empty($atts['title'])):
					?>
					<div class="ps-section__header text-center">
						<h3 class="ps-section__title"><?php echo esc_html($atts['title']);?></h3>
						<?php if(!empty($atts['subtitle'])){  ?> <p><?php echo esc_html($atts['subtitle']); ?></p><?php } ?>
						<span><img src="<?php echo get_template_directory_uri(); ?>/assets/images/icons/floral.png" alt="<?php echo esc_attr($atts['title']);?>"></span>
					</div>
					<?php endif; ?>
					
					<div class="ps-section__content">
						<div class="row products">
							<?php
							while($products->have_posts()): $products->the_post();
								if(isset($atts['style']) && $atts['style'] == 'product_side') :
									wc_get_template_part('content', 'product-side'); 
								else : 
									wc_get_template_part('content', 'product-masonry');
								endif;
							endwhile;
							?>	
						</div>
					</div>
				</div>
			</div>
			<?php
			endif;
			wp_reset_postdata();
		return ob_get_clean();
		
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		vc_map( array(
	      	"name" => esc_html__( "Bready - Products", 'bready-helpers' ),
	      	"base" => "noubready_products",
	      	"class" => "",
	      	"category" => esc_html__( "Bready Theme", 'bready-helpers'),
	      	'description' => esc_html__('Products display grid', 'bready-helpers'),
    		"params" => array(
				array(
		            "type" => "dropdown",
		            "class" => "",
		            "holder" => "div",
		            "heading" => esc_html__( "Type of section show", 'bready-helpers' ),
		            "param_name" => "style",
		            "value" => array(
						esc_html__('Default', 'bready-helpers') => 'default', 
						esc_html__('Product side', 'bready-helpers') => 'product_side'
					)
		        ),
				array(
					"type" => "attach_image",
					"class" => "",
					"heading" => esc_html__( "Background image", "bready-helpers" ),
					"param_name" => "bg",
					'dependency' => array(
						'element' => 'style',
						'value' => 'product_side',
					),
				),
				array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", 'bready-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Subtitle", 'bready-helpers' ),
		            "param_name" => "subtitle",
		        ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "holder" => "div",
		            "heading" => esc_html__( "Type of products show", 'bready-helpers' ),
		            "param_name" => "type",
		            "value" => array(esc_html__('--Select type--', 'bready-helpers') => '', esc_html__('Recent', 'bready-helpers') => 'recent', esc_html__('Featured', 'bready-helpers') => 'featured', esc_html__('Sale', 'bready-helpers') => 'onsale', esc_html__('Best sale', 'bready-helpers') => 'bestsale'), 
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "IDs, EX: 21,22,23", 'bready-helpers' ),
		            "param_name" => "ids",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Product Category ID", 'bready-helpers' ),
		            "param_name" => "cat",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Number of posts show(default 6)", 'bready-helpers' ),
		            "param_name" => "number",
		        ),
				array(
		            "type" => "textfield",
		            "heading" => esc_html__( "Custom Class CSS", 'bready-helpers' ),
		            "param_name" => "class",
		        ),
	      	)
	    ) );
	}

	private static function get_products($atts){
		
		$per_page = !empty($atts['number']) ? intval($atts['number']) : '6';
		$args = array(
			'post_type' => 'product', 
			'post_status' => 'publish',
			'posts_per_page' => $per_page
			);

		if(!empty($atts['ids'])){
			$args['post__in'] = explode(',', $atts['ids']);
		}else{
			if(!empty($atts['cat'])){
				$args['tax_query'] = array(
					array(
						'taxonomy' => 'product_cat',
						'field'    => 'term_id',
						'terms'    => $atts['cat'],
					),
				);
			}
		}
		switch ( $atts['type'] ) {
			case 'featured' :
				$args['tax_query'][] = array(
                    'taxonomy' => 'product_visibility',
                    'field'    => 'name',
                    'terms'    => 'featured',
                );
				break;
			case 'onsale' :
				$product_ids_on_sale    = wc_get_product_ids_on_sale();
				$product_ids_on_sale[]  = 0;
				$args['post__in'] = $product_ids_on_sale;
				break;	
			case 'bestsale' :
				$args['meta_key'] = 'total_sales';
				$args['orderby']  = 'meta_value_num';
		}
		
		return new WP_Query( apply_filters( 'noubready_products_shortcode_query_args', $args ) );
	}
}
?>