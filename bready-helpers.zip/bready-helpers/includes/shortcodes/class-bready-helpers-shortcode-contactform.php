<?php
/**
* 
*/
class Bready_Helpers_Shortcode_Contactform
{
	
	public static function shortcode($atts){
		$atts = shortcode_atts( array(
			'title' => '',
		), $atts, 'noubready_contact_form' );
		ob_start();
		?>
		<form class="ps-form--contact" action="<?php echo esc_url(home_url('/'));?>" method="post">
			<div class="row">
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 ">
				  <div class="form-group">
					<label><?php esc_html_e('Name', 'bready-helpers');?> <sup>*</sup></label>
					<input class="form-control" name="name" type="text" placeholder="">
				  </div>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 ">
				  <div class="form-group">
					<label><?php esc_html_e('Email', 'bready-helpers');?> <sup>*</sup></label>
					<input class="form-control" name="email" type="text" placeholder="">
				  </div>
				</div>
			</div>
			<div class="form-group">
				<label><?php esc_html_e('Your Message', 'bready-helpers');?> <sup>*</sup></label>
				<textarea class="form-control" rows="7" name="content"></textarea>
			</div>
			<div class="form-group submit">
				<button class="ps-btn ps-btn--yellow"><?php esc_html_e('Send your message', 'bready-helpers');?></button>
			</div>
		</form>
		<?php
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Bready - Contact Form", 'bready-helpers' ),
	      	"base" => "noubready_contact_form",
	      	"class" => "",
	      	"category" => esc_html__( "Bready Theme", 'bready-helpers'),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", 'bready-helpers' ),
		            "param_name" => "title",
		        ),
	      	)
	    ) );
		endif;
	}
}