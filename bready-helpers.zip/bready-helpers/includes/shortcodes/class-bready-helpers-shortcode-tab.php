<?php
/**
* 
*/
class Bready_Helpers_Shortcode_Tab
{
	
	/**
	 * Tab
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		if(empty($atts)){
			return '';
		}

		$atts = shortcode_atts( array(
			'type' => '',
			'title' => '',
			'desc' => '',
			'ids' => '',
			'cat' => '',
			'number' => '',
		), $atts, 'noubready_tab' );
		
		$per_page = !empty($atts['number']) ? intval($atts['number']) : '3';
		$args = array(
			'post_type' => 'package', 
			'post_status' => 'publish',
			'order' => 'ASC',
			'posts_per_page' => $per_page
		);

		if(!empty($atts['ids'])){
			$args['post__in'] = explode(',', $atts['ids']);
		}else{
			if(!empty($atts['cat'])){
				$args['tax_query'] = array(
					array(
						'taxonomy' => 'package_cat',
						'field'    => 'term_id',
						'terms'    => $atts['cat'],
					),
				);
			}
		}
	
		$query = new WP_Query($args);
		$i = $j = 0;
		ob_start();
			if($query->have_posts()):
				if($atts['type'] == 'type-2'): ?>
				<div class="ps-product-collection">
					<div class="ps-container">
						<?php
							if(!empty($atts['title'])):
						?>
						<div class="ps-section__header text-center">
							<h3 class="ps-section__title"><?php echo esc_html($atts['title']);?></h3>
							<?php if(!empty($atts['desc'])){  ?> 
								<?php echo wpautop(esc_html($atts['desc']));?> 
							<?php } ?>
							<span>
								<img src="<?php echo get_template_directory_uri(); ?>/assets/images/icons/floral.png" alt="<?php echo esc_attr($atts['title']);?>">
							</span>
						</div>
						<?php	
							endif;
						?>
						
						
						<div class="ps-section__content">
						  <ul class="tab-list" role="tablist">
							<?php while($query->have_posts()): $query->the_post(); $i++ ?>
							<?php $package = noubready_package_settings();?>
							<li class="<?php echo $i == 1 ? 'active':''; ?>">
								<a href="#tab_<?php echo esc_attr(get_the_ID()); ?>" aria-controls="tab_<?php echo esc_attr(get_the_ID()); ?>" role="tab" data-toggle="tab"><i class="<?php echo esc_attr($package['icon']); ?>"></i><?php echo esc_html($package['title']); ?></a>
							</li>
							<?php endwhile;?>
						  </ul>
						  
						  <div class="tab-content">
							<?php while($query->have_posts()): $query->the_post(); $j++ ?>
								<?php 
								$package = noubready_package_settings();
								$thumb		= wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full');
								$thumb_url 	= $thumb['0'];
								?>
								<div class="tab-pane <?php echo $j == 1 ? 'active':''; ?>" id="tab_<?php echo esc_attr(get_the_ID()); ?>" role="tabpanel">
									<div class="ps-block--product-set">
										<div class="ps-block__thumbnail">
											<img src="<?php echo esc_url($thumb_url); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>">
										</div>
										<div class="ps-block__content">
											<h3><?php echo get_the_title(); ?></h3>
										  
											<?php the_content(); ?>
											<div class="ps-block--product-status">
												<h5>
													<?php esc_html_e('Only today: ', 'bready-helpers'); ?> 
													<del><?php echo wc_price($package['regular']); ?></del> 
													<strong><?php echo wc_price($package['sale']); ?></strong>
												</h5>
												<div class="ps-block__status">
													<span> <?php esc_html_e('Already sold: ', 'bready-helpers'); ?><strong><?php echo esc_html($package['sold']); ?></strong></span>
													<span class="right">
														<?php esc_html_e('Available: ', 'bready-helpers'); ?> 
														<strong><?php echo esc_html($package['available']); ?></strong>
													</span>
													<div class="clearfix"></div>
													<div class="ps-status-bar" data-width="<?php echo esc_attr($package['sold']/$package['available'] *100); ?>"><span></span></div>
													<a class="ps-btn" href="<?php echo esc_attr($package['link']); ?>"><?php echo esc_html($package['button']); ?></a>
												</div>
											</div>
										</div>
									</div>
								</div>
							<?php endwhile;?>
						  </div>
						</div>
						
					</div>
				</div>
				
				<?php else: ?>
				<div class="ps-home-about--2">
					<div class="ps-container">
						<?php
							if(!empty($atts['title'])):
						?>
						<div class="ps-section__header text-center">
							<h3 class="ps-section__title"><?php echo esc_html($atts['title']);?></h3>
							<?php if(!empty($atts['desc'])){  ?> 
								<?php echo wpautop(esc_html($atts['desc']));?> 
							<?php } ?>
							<span>
								<img src="<?php echo get_template_directory_uri(); ?>/assets/images/icons/floral.png" alt="<?php echo esc_attr($atts['title']);?>">
							</span>
						</div>
						<?php	
							endif;
						?>
						
						
						<div class="ps-section__content">
						  <ul class="tab-list" role="tablist">
							<?php while($query->have_posts()): $query->the_post(); $i++ ?>
							<li class="<?php echo $i == 1 ? 'active':''; ?>">
								<a href="#tab_<?php echo esc_attr(get_the_ID()); ?>" aria-controls="tab_<?php echo esc_attr(get_the_ID()); ?>" role="tab" data-toggle="tab"><?php echo esc_html(get_the_title()); ?></a>
							</li>
							<?php endwhile;?>
						  </ul>
						  
						  <div class="tab-content">
							<?php while($query->have_posts()): $query->the_post(); $j++ ?>
								<div class="tab-pane <?php echo $j == 1 ? 'active':''; ?>" id="tab_<?php echo esc_attr(get_the_ID()); ?>" role="tabpanel">
								<?php the_content(); ?>
							</div>
							<?php endwhile;?>
						  </div>
						</div>
						
					</div>
				</div>
				<?php endif;
			endif;
			wp_reset_postdata();
		return ob_get_clean();
	}

	/**
	 * Map shortcode Post items.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Bready - Tab", 'bready-helpers' ),
	      	"base" => "noubready_tab",
	      	"class" => "",
	      	"category" => esc_html__( "Bready Theme", 'bready-helpers'),
    		"params" => array(
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Type', 'bready-helpers' ),
					'param_name' => 'type',
					'value' => array(
						esc_html__( 'Default', 'bready-helpers' ) => 'type-1',
						esc_html__( 'Vertical', 'bready-helpers' ) => 'type-2',
					),
				),
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", 'bready-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Description", 'bready-helpers' ),
		            "param_name" => "desc",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "IDs packages, EX: 21,22,23", 'bready-helpers' ),
		            "param_name" => "ids",
		            'group' => esc_html__('Display', 'bready-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Category ID", 'bready-helpers' ),
		            "param_name" => "cat",
		            'group' => esc_html__('Display', 'bready-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Number of posts show(default 3)", 'bready-helpers' ),
		            "param_name" => "number",
		            'group' => esc_html__('Display', 'bready-helpers'),
		        ),
	      	)
	    ) );
		endif;
	}
}
?>