<?php
/**
* 
*/
class Bready_Helpers_Shortcode_Delivery_Form_Item
{
	
	public static function shortcode($atts){
		$atts = shortcode_atts( array(
			'title' => '',
			'address' => '',
			'email' => '',
			'phone' => '',
		), $atts, 'noubready_delivery_form_item' );

		$title = !empty($atts['title']) ? $atts['title'] : '';
		$address = !empty($atts['address']) ? $atts['address'] : '';
		$email = !empty($atts['email']) ? $atts['email'] : '';
		$phone = !empty($atts['phone']) ? $atts['phone'] : '';

		ob_start();
		?>
		<div class="ps-block--contact">
			<?php if(!empty($title)){ ?><h4><?php echo esc_html($title);?></h4><?php } ?>
			<?php if(!empty($address)){ ?><h5><?php echo esc_html($address); ?></h5><?php } ?>
			<?php if(!empty($email)):?><p><i class="fa fa-envelope"></i><a href="mailto:<?php echo esc_html($email);?>"><?php echo esc_html($email);?></a></p><?php endif;?>
			<?php if(!empty($phone)):?><p><i class="fa fa-phone-square"></i> <?php echo esc_html($phone);?></p><?php endif;?>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Bready - Dealer Location", 'bready-helpers' ),
	      	"base" => "noubready_delivery_form_item",
	      	"class" => "",
			"as_child" => array('only' => 'noubready_delivery_form'),
	      	"category" => esc_html__( "Bready Theme", 'bready-helpers'),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", 'bready-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Address", 'bready-helpers' ),
		            "param_name" => "address",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Email", 'bready-helpers' ),
		            "param_name" => "email",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Phone", 'bready-helpers' ),
		            "param_name" => "phone",
		        ),
	      	)
	    ) );
		endif;
	}
}