<?php
/**
* 
*/
class Bready_Helpers_Shortcode_Countdown_Item
{
	
	public static function shortcode($atts){
		$atts = shortcode_atts( array(
			'number_from' => '',
			'number_to' => '',
			'title' => '',
			'type' => '',
			'icon_fontawesome' => '',
			'icon_openiconic' => '',
			'icon_typicons' => '',
			'icon_entypo' => '',
			'icon_linecons' => '',
			'icon_monosocial' => '',
			'icon_material' => '',
			'icon_custom' => '',
			'col' => '',
		), $atts, 'noubready_countdown_item' );
		$type = !empty($atts['type']) ? $atts['type'] : 'fontawesome';
		$col = !empty($atts['col']) ? $atts['col'] : '4';
		$class = 'col-lg-'.intval(12/$col).' col-md-'.intval(12/$col).'';
		ob_start();
		?>
		<div class="<?php echo esc_attr($class);?> col-sm-6 col-xs-12 ">
			<div class="ps-block--countdown">
				<?php if(!empty($atts['icon_'.$type])){?>
					<i class="<?php echo esc_attr($atts['icon_'.$type]);?>"></i>
				<?php }?>
				<?php if(!empty($atts['number_from']) || !empty($atts['number_to'])){?>
					<span class="number ps-block__number" data-from="<?php echo esc_attr($atts['number_from']);?>" data-to="<?php echo esc_attr($atts['number_to']);?>"> <?php echo esc_html($atts['number_to']);?></span>
				<?php }?>
				<?php if(!empty($atts['title'])){?>
					<h4><?php echo esc_html($atts['title']);?></h4>
				<?php }?>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Bready - Countdown Item", 'bready-helpers' ),
	      	'description' => esc_html__('Icon with content', 'bready-helpers'),
	      	"base" => "noubready_countdown_item",
	      	"class" => "",
			"as_child" => array('only' => 'noubready_countdown'),
	      	"category" => esc_html__( "Bready Theme", 'bready-helpers'),
    		"params" => array(
				array(
		            "type" => "textfield",
		            "holder" => "div",
		            "heading" => esc_html__( "Number From", 'bready-helpers' ),
		            "param_name" => "number_from",
		        ),
				array(
		            "type" => "textfield",
		            "holder" => "div",
		            "heading" => esc_html__( "Number To", 'bready-helpers' ),
		            "param_name" => "number_to",
		        ),
		        array(
		            "type" => "textfield",
		            "heading" => esc_html__( "Title", 'bready-helpers' ),
		            "param_name" => "title",
		        ),
				
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Width', 'bready-helpers' ),
					'param_name' => 'col',
					'value' => array(
						esc_html__( '1 column - 1/12', 'bready-helpers' ) => '1',
						esc_html__( '2 columns - 1/6', 'bready-helpers' ) => '2',
						esc_html__( '3 columns - 1/4', 'bready-helpers' ) => '4',
						esc_html__( '4 columns - 1/3', 'bready-helpers' ) => '3',
						esc_html__( '6 columns - 1/2', 'bready-helpers' ) => '2',
					),
					'group' => esc_html__( 'Responsive Options', 'bready-helpers' ),
					'description' => esc_html__( 'Select column width.', 'bready-helpers' ),
					'std' => '3',
				),
		        array(
					'type' => 'dropdown',
					'heading' => __( 'Icon library', 'bready-helpers' ),
					'value' => array(
						__( 'Font Awesome', 'bready-helpers' ) => 'fontawesome',
						__( 'Open Iconic', 'bready-helpers' ) => 'openiconic',
						__( 'Typicons', 'bready-helpers' ) => 'typicons',
						__( 'Entypo', 'bready-helpers' ) => 'entypo',
						__( 'Linecons', 'bready-helpers' ) => 'linecons',
						__( 'Mono Social', 'bready-helpers' ) => 'monosocial',
						__( 'Material', 'bready-helpers' ) => 'material',
						__( 'Custom', 'bready-helpers' ) => 'custom',
					),
					'admin_label' => true,
					'param_name' => 'type',
					'description' => __( 'Select icon library.', 'bready-helpers' ),
		            'group' => esc_html__('Icon', 'bready-helpers'),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'bready-helpers' ),
					'param_name' => 'icon_fontawesome',
					'value' => 'fa fa-adjust',
					// default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => false,
						// default true, display an "EMPTY" icon?
						'iconsPerPage' => 4000,
						// default 100, how many icons per/page to display, we use (big number) to display all icons in single page
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'fontawesome',
					),
					'description' => __( 'Select icon from library.', 'bready-helpers' ),
					'group' => esc_html__('Icon', 'bready-helpers'),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'bready-helpers' ),
					'param_name' => 'icon_openiconic',
					'value' => 'vc-oi vc-oi-dial',
					// default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => false,
						// default true, display an "EMPTY" icon?
						'type' => 'openiconic',
						'iconsPerPage' => 4000,
						// default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'openiconic',
					),
					'description' => __( 'Select icon from library.', 'bready-helpers' ),
					'group' => esc_html__('Icon', 'bready-helpers'),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'bready-helpers' ),
					'param_name' => 'icon_typicons',
					'value' => 'typcn typcn-adjust-brightness',
					// default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => false,
						// default true, display an "EMPTY" icon?
						'type' => 'typicons',
						'iconsPerPage' => 4000,
						// default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'typicons',
					),
					'description' => __( 'Select icon from library.', 'bready-helpers' ),
					'group' => esc_html__('Icon', 'bready-helpers'),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'bready-helpers' ),
					'param_name' => 'icon_entypo',
					'value' => 'entypo-icon entypo-icon-note',
					// default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => false,
						// default true, display an "EMPTY" icon?
						'type' => 'entypo',
						'iconsPerPage' => 4000,
						// default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'entypo',
					),
					'group' => esc_html__('Icon', 'bready-helpers'),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'bready-helpers' ),
					'param_name' => 'icon_linecons',
					'value' => 'vc_li vc_li-heart',
					// default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => false,
						// default true, display an "EMPTY" icon?
						'type' => 'linecons',
						'iconsPerPage' => 4000,
						// default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'linecons',
					),
					'description' => __( 'Select icon from library.', 'bready-helpers' ),
					'group' => esc_html__('Icon', 'bready-helpers'),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'bready-helpers' ),
					'param_name' => 'icon_monosocial',
					'value' => 'vc-mono vc-mono-fivehundredpx',
					// default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => false,
						// default true, display an "EMPTY" icon?
						'type' => 'monosocial',
						'iconsPerPage' => 4000,
						// default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'monosocial',
					),
					'description' => __( 'Select icon from library.', 'bready-helpers' ),
					'group' => esc_html__('Icon', 'bready-helpers'),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'bready-helpers' ),
					'param_name' => 'icon_material',
					'value' => 'vc-material vc-material-cake',
					// default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => false,
						// default true, display an "EMPTY" icon?
						'type' => 'material',
						'iconsPerPage' => 4000,
						// default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'material',
					),
					'description' => __( 'Select icon from library.', 'bready-helpers' ),
					'group' => esc_html__('Icon', 'bready-helpers'),
				),
				array(
		            "type" => "textfield",
		            "heading" => esc_html__( "Custom Icon", 'bready-helpers' ),
		            "param_name" => "icon_custom",
		            'dependency' => array(
						'element' => 'type',
						'value' => 'custom',
					),
					'group' => esc_html__('Icon', 'bready-helpers'),
		        ),
	      	)
	    ) );
		endif;
	}
}