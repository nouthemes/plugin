<?php
/**
* 
*/
class Bready_Helpers_Shortcode_Contact_Footer
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts ) {
		$atts = shortcode_atts( array(
			'title' => '',
			'desc' => '',
			'class'=> ''
		), $atts, 'noubready_contact_footer' );
		
		$bg = '';
		if(!empty($atts['img'])){
			$images = wp_get_attachment_image_src($atts['img'], 'full');
			if($images){
				$bg = $images[0];
			}
		}
		ob_start();
		?>
		<div class="ps-home-contact-2 <?php echo esc_attr($atts['class']);?>">
			<div class="ps-container">
				<div class="ps-block--working-time">
				  <h4><?php echo esc_html($atts['title']);?></h4>
				  <?php echo wp_kses_post(wpautop($atts['desc']));?>
				</div>
				<form class="ps-form--get-in-touch" action="<?php echo esc_url(home_url('/'));?>" method="post">
					<h3><?php echo esc_html('Get in touch', 'bready-helpers');?></h3>
					<div class="form-group">
						<label><?php esc_html_e('Name', 'bready-helpers');?> <sup>*</sup></label>
						<input class="form-control" name="name" type="text" placeholder="">
					</div>
					<div class="form-group">
						<label><?php esc_html_e('Email', 'bready-helpers');?> <sup>*</sup></label>
						<input class="form-control" name="email" type="email" placeholder="">
					</div>
					<div class="form-group">
						<label><?php esc_html_e('Phone Number', 'bready-helpers');?> <sup>*</sup></label>
						<input class="form-control" name="phone" type="text" placeholder="">
					</div>
					<div class="form-group submit">
						<button class="ps-btn"><?php esc_html_e('Contact Us', 'bready-helpers');?></button>
					</div>
				</form>

				<?php echo get_template_part('template-parts/footer/newsletter'); ?>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Bready - Contact Footer", "bready-helpers" ),
	      	"base" => "noubready_contact_footer",
	      	"class" => "",
	      	"category" => esc_html__( "Bready Theme", "bready-helpers"),
	      	"params" => array(
				array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", 'bready-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textarea",
		            "class" => "",
		            "heading" => esc_html__( "Description", 'bready-helpers' ),
		            "param_name" => "desc",
		        ),
				array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Custom Class", 'bready-helpers' ),
		            "param_name" => "class",
		        ),
	      	)
	    ) 
		);
		endif;
	}
}
?>