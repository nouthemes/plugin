<?php

/**
 * AJAX handler
 */
class Bready_Helpers_Ajax {

	/**
	 * Hook in ajax handlers.
	 */
	public static function init() 
	{
		self::add_ajax_events();
	}

	/**
	 * Hook in methods - uses WordPress ajax handlers (admin-ajax).
	 */
	public static function add_ajax_events() 
	{
		
		$ajax_events = array(
			'post_like',
			'wishlist',
			'compare',
			'product_quick_view',
			'product_after_added_to_cart',
			'remove_product_from_lists',
			'email_contact',
			'quick_order',
			'search_products',

		);

		foreach ( $ajax_events as $ajax_event ) {
			add_action( 'wp_ajax_bready_helpers_' . $ajax_event, array( __CLASS__, $ajax_event ) );
			add_action( 'wp_ajax_nopriv_bready_helpers_' . $ajax_event, array( __CLASS__, $ajax_event ) );
		}
	}

	public static function remove_product_from_lists(){
		$status = array('status' => '0', 'html' => '');
		if( !empty($_POST['product_id']) && !empty($_POST['type'] ) && !empty($_POST['nonce'] ) && wp_verify_nonce( $_POST['nonce'], 'noubready-theme-nonce' ) ){

			switch ($_POST['type']) {
				case 'wishlist':
					$delete = Bready_Helpers_Wishlist::delete($_POST['product_id']);
					$status['status'] = $delete;
					break;
				case 'compare':
					$delete = Bready_Helpers_Compare::delete($_POST['product_id']);
					$status['status'] = $delete;
					break;
			}
		}
		wp_send_json($status);
		exit();
	}

	public static function wishlist(){
		$status = array('status' => '0', 'html' => '');
		if( !empty($_POST['product_id'] ) && !empty($_POST['nonce'] ) && wp_verify_nonce( $_POST['nonce'], 'noubready-theme-nonce' ) ){
			$wishlist = true;
			switch ($_POST['do_action']) {
				case 'add':
					$wishlist = Bready_Helpers_Wishlist::add($_POST['product_id']);
					if($wishlist){
						$status['html'] = esc_html__('added to wishlist.', 'bready-helpers');
					}else{
						$status['html'] = esc_html__('has exists in wishlist.', 'bready-helpers');
					}
					break;
				case 'delete':
					$wishlist = Bready_Helpers_Wishlist::delete($_POST['product_id']);
					if($wishlist){
						$status['html'] = esc_html__('Delete from wishlist successfully.', 'bready-helpers');
					}else{
						$status['html'] = esc_html__('not exists in wishlist.', 'bready-helpers');
					}
					break;
			}

			if($wishlist){
				$status['status'] = '1';
			}
		}
		wp_send_json($status);
		exit();
	}

	public static function compare(){
		$status = array('status' => '0', 'html' => '');
		if( !empty($_POST['product_id']) && !empty($_POST['nonce']) && wp_verify_nonce( $_POST['nonce'], 'noubready-theme-nonce' ) ){
			$compare = false;
			switch ($_POST['do_action']) {
				case 'add':
					$compare = Bready_Helpers_Compare::add($_POST['product_id']);
					if($compare){
						$status['html'] = esc_html__('added to compare.', 'bready-helpers');
					}else{
						$status['html'] = esc_html__('has exists in compare list.', 'bready-helpers');
					}
					$status['product_id'] = $compare;
					break;
				case 'delete':
					$compare = Bready_Helpers_Compare::delete($_POST['product_id']);
					if($compare){
						$status['html'] = esc_html__('Delete from compare list successfully.', 'bready-helpers');
					}else{
						$status['html'] = esc_html__('not exists in compare list.', 'bready-helpers');
					}
					break;
			}

			if($compare){
				$status['status'] = '1';
			}
		}
		wp_send_json($status);
		exit();
	}
	
	public static function email_contact()
	{
		$status = array('status' => '0', 'html' => '');

		if( !empty($_POST['nonce'] ) && wp_verify_nonce( $_POST['nonce'], 'noubready-theme-nonce' ) ){
			$status['status'] = 2;
			if(!empty($_POST['name']) && !empty($_POST['email']) && !empty($_POST['content']) && is_email($_POST['email'])){
				$subject = sprintf(esc_html__('[%s] Email from contact form', 'bready-helpers'), get_bloginfo('name'));
			
					$message = sprintf(esc_html__('This email was sent from form contact on website %s', 'bready-helpers'), get_bloginfo('name'))." \n\n\n";
					$message .= esc_html__('Name:', 'bready-helpers')." ".esc_html($_POST['name'])." \n\n";
					$message .= esc_html__('Email:', 'bready-helpers')." ".esc_html($_POST['email'])." \n\n";
					$message .= esc_html__('Comments:', 'bready-helpers')."\n ".wp_kses_post($_POST['content'])."";
					
				Bready_Helpers_Email::send( get_option('admin_email'), $subject, $message );
				$status['status'] = 1;
			}
		}

		wp_send_json($status);
		exit();
	}
	
	public static function post_like() {
		// Security
		$nonce = isset( $_POST['security'] ) ? sanitize_text_field( $_POST['security'] ) : 0;
		
		if ( !wp_verify_nonce( $nonce, 'noubready-theme-nonce' ) ) {
			exit( esc_html__( 'Not permitted', 'bready-helpers' ) );
		}
		// Test if javascript is disabled
		$disabled = ( isset( $_POST['disabled'] ) && $_POST['disabled'] == true ) ? true : false;
		// Test if this is a comment
		$is_comment = ( isset( $_POST['is_comment'] ) && $_POST['is_comment'] == 1 ) ? 1 : 0;
		// Base variables
		$post_id = ( isset( $_POST['post_id'] ) && is_numeric( $_POST['post_id'] ) ) ? $_POST['post_id'] : '';
		
		$result = array();
		$post_users = NULL;
		$like_count = 0;

		// Get plugin options
		if ( $post_id != '' ) {

			$count = get_post_meta( $post_id, "_post_like_count", true );
			$count = ( isset( $count ) && is_numeric( $count ) ) ? $count : 0;
			
			if ( !bready_helpers_already_liked( $post_id, $is_comment ) ) { // Like the post

				if ( is_user_logged_in() ) { // user is logged in

					$user_id = get_current_user_id();
					$post_users = bready_helpers_post_user_likes( $user_id, $post_id, $is_comment );
					
					if ( $is_comment == 1 ) {

						// Update User & Comment
						$user_like_count = get_user_option( "_comment_like_count", $user_id );
						$user_like_count =  ( isset( $user_like_count ) && is_numeric( $user_like_count ) ) ? $user_like_count : 0;
						update_user_option( $user_id, "_comment_like_count", ++$user_like_count );
						
						if ( $post_users ) {
							update_comment_meta( $post_id, "_user_comment_liked", $post_users );
						}

					} else {

						// Update User & Post
						$user_like_count = get_user_option( "_user_like_count", $user_id );
						$user_like_count =  ( isset( $user_like_count ) && is_numeric( $user_like_count ) ) ? $user_like_count : 0;
						update_user_option( $user_id, "_user_like_count", ++$user_like_count );
						
						if ( $post_users ) {
							update_post_meta( $post_id, "_user_liked", $post_users );
						}
					}

				} else { // user is anonymous

					$user_ip = bready_helpers_get_ip();
					$post_users = bready_helpers_post_ip_likes( $user_ip, $post_id, $is_comment );
					
					// Update Post
					if ( $post_users ) {
						if ( $is_comment == 1 ) {
							update_comment_meta( $post_id, "_user_comment_IP", $post_users );
						} else { 
							update_post_meta( $post_id, "_user_IP", $post_users );
						}
					}

				}

				$like_count = ++$count;
				$response['status'] = "liked";
				$response['icon'] = bready_helpers_get_liked_icon();

			} else { // Unlike the post

				if ( is_user_logged_in() ) { // user is logged in

					$user_id = get_current_user_id();
					$post_users = bready_helpers_post_user_likes( $user_id, $post_id, $is_comment );
					// Update User
					if ( $is_comment == 1 ) {
						$user_like_count = get_user_option( "_comment_like_count", $user_id );
						$user_like_count =  ( isset( $user_like_count ) && is_numeric( $user_like_count ) ) ? $user_like_count : 0;
						if ( $user_like_count > 0 ) {
							update_user_option( $user_id, "_comment_like_count", --$user_like_count );
						}
					} else {
						$user_like_count = get_user_option( "_user_like_count", $user_id );
						$user_like_count =  ( isset( $user_like_count ) && is_numeric( $user_like_count ) ) ? $user_like_count : 0;
						if ( $user_like_count > 0 ) {
							update_user_option( $user_id, '_user_like_count', --$user_like_count );
						}
					}
					// Update Post
					if ( $post_users ) {	
						$uid_key = array_search( $user_id, $post_users );
						unset( $post_users[$uid_key] );
						if ( $is_comment == 1 ) {
							update_comment_meta( $post_id, "_user_comment_liked", $post_users );
						} else { 
							update_post_meta( $post_id, "_user_liked", $post_users );
						}
					}
				} else { // user is anonymous
					$user_ip = bready_helpers_get_ip();
					$post_users = bready_helpers_post_ip_likes( $user_ip, $post_id, $is_comment );
					// Update Post
					if ( $post_users ) {
						$uip_key = array_search( $user_ip, $post_users );
						unset( $post_users[$uip_key] );
						if ( $is_comment == 1 ) {
							update_comment_meta( $post_id, "_user_comment_IP", $post_users );
						} else { 
							update_post_meta( $post_id, "_user_IP", $post_users );
						}
					}
				}

				$like_count = ( $count > 0 ) ? --$count : 0; // Prevent negative number
				$response['status'] = "unliked";
				$response['icon'] = bready_helpers_get_unliked_icon();
			}

			if ( $is_comment == 1 ) {
				update_comment_meta( $post_id, "_comment_like_count", $like_count );
				update_comment_meta( $post_id, "_comment_like_modified", date( 'Y-m-d H:i:s' ) );
			} else { 
				update_post_meta( $post_id, "_post_like_count", $like_count );
				update_post_meta( $post_id, "_post_like_modified", date( 'Y-m-d H:i:s' ) );
			}

			$response['count'] = bready_helpers_post_like($post_id);

			$liked = bready_helpers_already_liked($post_id);
			if($liked){
				$class = esc_attr( 'liked', 'bready-helpers' );
				$icon = bready_helpers_get_liked_icon();
			}else{
				$icon = bready_helpers_get_unliked_icon();
			}

			$response['button'] = '<a data-id="'.intval($post_id).'" class="post-like like '.esc_attr($class).'">'.wp_kses_post($icon).'<span><i>'.$count.'</i></span></a>';

			wp_send_json( $response );
			exit();
		}
	}
	
	public static function product_after_added_to_cart(){
		$status = array('status' => '0', 'html' => '');

		if( !empty($_POST['nonce'] ) && !empty($_POST['product_id'] )){
			if ( ! isset( $_POST['product_id'] ) ) {
				die();
			}

			$product_id = intval( $_POST['product_id'] );

			// set the main wp query for the product
			wp( 'p=' . $product_id . '&post_type=product' );

			ob_start();
			
			while ( have_posts() ) : the_post();
			global $product;
			?>
			<div id="product-<?php the_ID(); ?>" <?php post_class(); ?>>
				<div class="row">
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 ">
						<div class="ps-product__image">
							<?php 
								if ( has_post_thumbnail( $product->id ) ) {
								$attachment_ids[0] = get_post_thumbnail_id( $product->id );
								 $attachment = wp_get_attachment_image_src($attachment_ids[0], 'noubready_1000x769' ); 
							?>    
								<img src="<?php echo $attachment[0] ; ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>" />
							<?php } ?>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 ">
						<div class="ps-product__summary">
							<span class="ps-product__added"><i class="fa fa-check"></i></span>
							<h3 class="ps-product__name"><?php the_title();?></h3>
							<p class="ps-product__alert"><?php echo esc_html__('has just been added to your cart', 'bready-helpers'); ?></p>
							<div class="ps-product__qty_cart ps-form--shopping">
								<span class="title"><?php echo esc_html__('Select quantity', 'bready-helpers'); ?></span>
								<form class="woocommerce-cart-form-new" method="post">
									<?php
										foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
											$_product   = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
											if ( $product_id == $cart_item['product_id'] ){
												$product_quantity = woocommerce_quantity_input( array(
													'input_name'  => "qty",
													'input_value' => $cart_item['quantity'],
													'max_value'   => $_product->get_max_purchase_quantity(),
													'min_value'   => '0',
												), $_product, false );
												?>
												<input type="hidden" name="product_id" value="<?php echo esc_attr($cart_item['product_id']);?>">
												<?php
												echo apply_filters( 'woocommerce_cart_item_quantity', $product_quantity, $cart_item_key, $cart_item );
											}
										}
									?>
									<button type="submit" class="ps-btn btn-update-cart" name="bready_update_cart" value="<?php esc_attr_e( 'Update cart', 'bready-helpers' ); ?>"><?php esc_attr_e( 'Update cart', 'bready-helpers' ); ?></button>

								</form>
							</div>
							
							<div class="modal-price">
								<span class="title"><?php echo esc_html__('Price: ', 'bready-helpers'); ?></span>
								<?php
									woocommerce_template_single_price();
								?>
							</div>
							<div class="ps-product__buttons">
								<a href="<?php echo get_permalink(wc_get_page_id ('shop')); ?>" class="ps-btn">
									<?php esc_html_e( 'Continue Shopping', 'bready-helpers' ); ?>
								</a>
								<a href="<?php echo esc_url( wc_get_checkout_url() );?>" class="ps-btn">
									<?php esc_html_e( 'Go to checkout', 'bready-helpers' ); ?>
								</a>
							</div>
							
							<div class="payment"><img src="<?php echo NOUBREADY_ASSETS ?>/images/payment.png" alt="<?php echo esc_attr(get_bloginfo('name')); ?>"></div>
						</div>
					</div>
	            </div>
				<div class="ps-total__cart">
					<p class="cart-count">
					<img src="<?php echo NOUBREADY_ASSETS ?>/images/market.svg" alt="<?php echo esc_attr(get_bloginfo('name')); ?>">
					<?php esc_html_e( 'There are', 'bready-helpers' ); ?> <b><?php echo intval(WC()->cart->get_cart_contents_count());?></b> <?php esc_html_e( 'item in your cart', 'bready-helpers' ); ?>
					</p>
					
					<p class="cart-total"><?php wc_cart_totals_subtotal_html(); ?></p>
				</div>
	        </div>
			<?php
			endwhile;
			$status['status'] =  1;
			$status['html'] =  ob_get_clean();
		}

		wp_send_json($status);
		exit();
	}
	
	public static function product_quick_view(){
		$status = array('status' => '0', 'html' => '');
		if( !empty($_POST['nonce'] ) && wp_verify_nonce( $_POST['nonce'], 'noubready-theme-nonce' ) ){

			if ( ! isset( $_POST['product_id'] ) ) {
				die();
			}

			$product_id = intval( $_POST['product_id'] );
			
			wp( 'p=' . $product_id . '&post_type=product' );

			ob_start();
			while ( have_posts() ) : the_post();
			$all_images = noubready_product_images(get_the_ID());
			?>
			<div id="product-<?php the_ID(); ?>" <?php post_class(); ?> data-id="<?php the_ID();?>" data-url="<?php the_permalink();?>" data-title="<?php the_title();?>">
				<div class="col-lg-5 col-md-5 col-sm-12 col-xs-12 ">
	                <div class="ps-product__thumbnail">
	                  <div class="quickview--main" data-owl-auto="true" data-owl-loop="false" data-owl-speed="10000" data-owl-gap="0" data-owl-nav="false" data-owl-dots="false" data-owl-animate-in="" data-owl-animate-out="" data-owl-item="1" data-owl-item-xs="1" data-owl-item-sm="1" data-owl-item-md="1" data-owl-item-lg="1" data-owl-nav-left="&lt;i class=&quot;fa fa-angle-left&quot;&gt;&lt;/i&gt;" data-owl-nav-right="&lt;i class=&quot;fa fa-angle-right&quot;&gt;&lt;/i&gt;">
		                    <?php
								if ( count($all_images) > 0 ) {

									foreach ($all_images as $id) {
										$images = wp_get_attachment_image_src($id, 'noubready_1000x769');
										if($images){
											?>
											<div class="ps-product__image">
							                    <img src="<?php echo esc_attr($images[0]);?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>"/>
							                </div>
											<?php
										}
									}
									
								} else {
									echo apply_filters( 'woocommerce_single_product_image_html', sprintf( '<div class="ps-product__image"><img src="%s" alt="%s" class="gallery-image"/></div>', wc_placeholder_img_src(), __( 'Placeholder', 'bready' ) ), get_the_ID() );
								}

								
							?>
	                  </div>
	                  <?php if ( count($all_images) > 0 ) {?>
	                  <div class="quickview--thumbnail" data-owl-auto="true" data-owl-loop="false" data-owl-speed="10000" data-owl-gap="20" data-owl-nav="false" data-owl-dots="false" data-owl-animate-in="" data-owl-animate-out="" data-owl-item="4" data-owl-item-xs="2" data-owl-item-sm="3" data-owl-item-md="4" data-owl-item-lg="4" data-owl-nav-left="&lt;i class=&quot;fa fa-angle-left&quot;&gt;&lt;/i&gt;" data-owl-nav-right="&lt;i class=&quot;fa fa-angle-right&quot;&gt;&lt;/i&gt;">
	                  	<?php
							if ( count($all_images) > 0 ) {

								foreach ($all_images as $id) {
									$images = wp_get_attachment_image_src($id, 'thumbnail');
									if($images){
										?>
										<div class="item">
											<img src="<?php echo esc_attr($images[0]);?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>"/>
										</div>
										<?php
									}
								}
								
							}
							
							?>
							<?php if(!empty($video_url)):?>
							<div class="item"><div class="ps-video"><a class="popup-youtube ps-product__video" href="<?php echo esc_url($video_url);?>">
								<img src="<?php echo esc_url($video_img);?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>"><i class="fa fa-play"></i>
							</a></div></div>
							<?php endif;?>
	                  </div>
	                  <?php }?>
	                </div>
	            </div>
	            <div class="col-lg-7 col-md-7 col-sm-12 col-xs-12 ">
	                <div class="ps-product__info">

					<?php
						/**
						 * woocommerce_single_product_summary hook.
						 *
						 * @hooked woocommerce_template_single_title - 5
						 * @hooked woocommerce_template_single_rating - 10
						 * @hooked woocommerce_template_single_price - 10
						 * @hooked woocommerce_template_single_excerpt - 20
						 * @hooked woocommerce_template_single_add_to_cart - 30
						 * @hooked woocommerce_template_single_meta - 40
						 * @hooked woocommerce_template_single_sharing - 50
						 * @hooked WC_Structured_Data::generate_product_data() - 60
						 */
						do_action( 'woocommerce_single_product_summary' );
					?>

					</div>
	            </div>
	        </div>
			<?php
			endwhile;
			$status['status'] =  1;
			$status['html'] =  ob_get_clean();
		}

		wp_send_json($status);
		exit();
	}
	
	public static function quick_order(){
		$status = array('status' => '0', 'html' => '');
		if( !empty($_POST['product_id'] ) && !empty($_POST['nonce'] ) && wp_verify_nonce( $_POST['nonce'], 'noubready-theme-nonce' ) ){
			$title = esc_html__('Order from quick order form', 'bready-helpers');
			// Create post object
			$quick_order = array(
			  'post_title'    => esc_html__('Order from quick order form', 'bready-helpers'),
			  'post_content'  => esc_html__('Order from quick order form', 'bready-helpers'),
			  'post_type' 	  => 'shop_order',
			  'post_status'   => 'wc-on-hold',
			  'post_excerpt'  => esc_html($_POST['note'])
			);
			// Insert the post into the database
			$id = wp_insert_post( $quick_order );

			if(intval($id)){
				update_post_meta($id, '_created_via', 'quick_order');
				update_post_meta($id, '_billing_first_name', esc_html($_POST['name']));
				update_post_meta($id, '_billing_address_1', esc_html($_POST['address']));
				update_post_meta($id, '_billing_email', esc_html($_POST['email']));
				update_post_meta($id, '_billing_phone', esc_html($_POST['phone']));

				$data_order_date = array(
				    'comment_post_ID' => $id,
				    'comment_author' => esc_html__('WooCommerce', 'bready-helpers'),
				    'comment_content' => esc_html__('The date customer want order bready: ', 'bready-helpers').esc_html($_POST['date']),
				    'comment_type' => 'order_note',
				    'comment_agent' => esc_html__('WooCommerce', 'bready-helpers'),
				    'comment_approved' => 1,
				);
				wp_insert_comment($data_order_date);

				global $wpdb;
				$wpdb->insert( $wpdb->prefix . 'woocommerce_order_items', array(
					'order_item_name' => get_the_title($_POST['product_id']),
					'order_item_type' => 'line_item',
					'order_id'        => $id,
				) );
				if($wpdb->insert_id){
					$wpdb->query( $wpdb->prepare( "
						INSERT INTO {$wpdb->prefix}woocommerce_order_itemmeta ( order_item_id, meta_key, meta_value )
						VALUES (%s, '_product_id', %s);", $wpdb->insert_id, $_POST['product_id'] ) );
					$wpdb->query( $wpdb->prepare( "
						INSERT INTO {$wpdb->prefix}woocommerce_order_itemmeta ( order_item_id, meta_key, meta_value )
						VALUES (%s, '_qty', %s);", $wpdb->insert_id, $_POST['product_qty'] ) );
				}

				$order = wc_get_order($id);
				$mailer = WC()->mailer();
				$mails = $mailer->get_emails();
				if ( ! empty( $mails ) ) {
					foreach ( $mails as $mail ) {
						if ( $mail->id == 'new_order' || $mail->id == 'customer_invoice' ) {
							$mail->trigger( $order->get_id(), $order );
						}
					}
				}
				$status['status'] = '1';
			}

		}
		wp_send_json($status);
		exit();
	}
	public static function search_products()
	{
		global $woocommerce;
        $search_keyword 	=  $_POST['key'];
        $suggestions = array();
        $status = array('status' => '0', 'html' => '', 'count' => 0);
        $html = '';
        if( !empty($_POST['nonce'] )){
	        $args = array(
		        's'           => $search_keyword,
		        'post_type'   => 'product',
		        'post_status' => 'publish',
		        'posts_per_page' => 5,
	        );
	        $args['meta_key'] = 'total_sales';
			$args['orderby'] = 'meta_value_num'; 
	        $products = new WP_Query( $args );
	        if ( ! empty( $products->have_posts()) ) {
				
	        	ob_start();?>
	        		<div class="row products">
	        			<?php
	        			$i = 1; 
	        			while ($products->have_posts()) { $products->the_post(); 
	        				global $post;
					        $product = wc_get_product( get_the_ID() );
							
					        if(!empty($product) && $i <= 4):
					        	$class = implode( ' ', array_filter( array(
						            'button',
						            'product_type_' . $product->get_type(),
						            $product->is_purchasable() && $product->is_in_stock() ? 'add_to_cart_button' : '',
						            $product->supports( 'ajax_add_to_cart' ) ? 'ajax_add_to_cart' : '',
						        ) ) );
					        	?>
						        <?php if($i == '1'){?><div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 "><?php }?>
						    	<div class="product ps-product--list ps-product--list-light mt-60">
				                    <div class="ps-product__thumbnail">
				                    	<a class="ps-product__overlay" href="<?php echo get_permalink($post->ID);?>"></a>
	      								<?php echo noubready_post_thumbnail($post->ID);?>
				                    </div>
				                    <div class="ps-product__content">
				                      <h4 class="ps-product__title"><a href="<?php echo get_permalink($post->ID);?>"><?php echo get_the_title($post->ID);?></a></h4>
				                      <?php echo wp_kses_post(wpautop(wp_trim_words($post->post_excerpt, 10)));?>
				                      <p class="ps-product__price">
				                        <?php echo wp_kses_post($product->get_price_html()); ?>
				                      </p>
				                      <?php
								      	echo apply_filters( 'woocommerce_search_products_add_to_cart_link',
											sprintf( '<a rel="nofollow" href="%s" data-quantity="%s" data-product_id="%s" data-product_sku="%s" class="ps-btn ps-btn--xs product-item-cart %s">%s</a>',
												esc_url( $product->add_to_cart_url() ),
												esc_attr( isset( $quantity ) ? $quantity : 1 ),
												esc_attr( $product->get_id() ),
												esc_attr( $product->get_sku() ),
												esc_attr( isset( $class ) ? $class : 'button' ),
												esc_html( $product->add_to_cart_text() )
											),
										$product );
								      ?>
				                    </div>
				                </div>
				                <?php if($i == '2'){?></div><?php }?>
				                <?php if($i == '2' && $products->found_posts >= 4){?><div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 "><?php }?>
				                <?php if($i == '4' && $products->found_posts >= 4){?></div><?php }?>
						        <?php
					        endif;
					        $i++;
				        }
	        			?>
	        		</div>
			    <?php
			    $html = ob_get_clean();
		        }
		        
				$status['i'] = $i;
		        $status['status'] = 1;
		        $status['count'] = $products->found_posts;
		        $status['html'] = $html;
		        wp_reset_postdata();
	    }

        wp_send_json($status);
        die();
	}

}
