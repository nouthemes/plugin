<?php 
defined( 'ABSPATH' ) OR exit;
/**
* Class widget about
*/
class Bready_Helpers_Widget_About_Footer_1 extends WP_Widget {
	
	public function __construct() {
		$widget_ops = array(
			'classname' => 'ps-site-info',
			'description' => esc_html__( 'About store with intro, social...', 'bready-helpers' ),
			'customize_selective_refresh' => true,
		);
		parent::__construct('Bready_Helpers_Widget_About_Footer_1', esc_html__('* About Footer 1', 'bready-helpers'), $widget_ops);
	}
	
	
	// Widget Backend 
	public function form( $instance ) {
		$instance = wp_parse_args((array)$instance, array(
			'logo' => '',
			'intro' => '',
			'facebook' => '',
			'google' => '',
			'twitter' => '',
			'linkedin' => '',
			'pinterest' => '',
			'instagram' => '',
			'tumblr' => '',
			'dribbble' => '',
			
		));
		
		$logo     			= sanitize_text_field( $instance['logo'] );
		$intro     			= 	strip_tags($instance['intro']);
		$facebook           	= sanitize_text_field( $instance['facebook'] );
		$goole           	= sanitize_text_field( $instance['goole'] );
		$twitter           	= sanitize_text_field( $instance['twitter'] );
		$linkedin           	= sanitize_text_field( $instance['linkedin'] );
		$pinterest           	= sanitize_text_field( $instance['pinterest'] );
		$instagram           	= sanitize_text_field( $instance['instagram'] );
		$tumblr           	= sanitize_text_field( $instance['tumblr'] );
		$dribbble           	= sanitize_text_field( $instance['dribbble'] );
		?>
		<p><label for="<?php echo esc_attr( $this->get_field_id('logo') ); ?>"><?php esc_html_e('Logo:', 'bready-helpers'); ?></label>
		<?php echo bready_helpers_cs_add_element(
      		array(
      			'id' => esc_attr( $this->get_field_id('logo') ),
      			'name' => esc_attr( $this->get_field_name('logo') ),
      			'type' => 'upload'
      		),
			$logo
      	);?></p>
		
		<p><label for="<?php echo esc_attr( $this->get_field_id('intro') ); ?>"><?php esc_html_e('Intro:', 'bready-helpers'); ?></label>
		<textarea class="widefat" id="<?php echo esc_attr( $this->get_field_id('intro') ); ?>" name="<?php echo esc_attr( $this->get_field_name('intro') ); ?>"><?php echo esc_attr($intro); ?></textarea></p>
		
		<h3><?php esc_html_e('Social', 'bready-helpers'); ?></h3>
		<p><label for="<?php echo esc_attr( $this->get_field_id('facebook') ); ?>"><?php esc_html_e('Facebook:', 'bready-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('facebook') ); ?>" name="<?php echo esc_attr( $this->get_field_name('facebook') ); ?>" type="text" value="<?php echo esc_attr($facebook); ?>" /></p>
		
		<p><label for="<?php echo esc_attr( $this->get_field_id('google') ); ?>"><?php esc_html_e('Google Plus:', 'bready-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('google') ); ?>" name="<?php echo esc_attr( $this->get_field_name('google') ); ?>" type="text" value="<?php echo esc_attr($google); ?>" /></p>
		
		<p><label for="<?php echo esc_attr( $this->get_field_id('twitter') ); ?>"><?php esc_html_e('Twitter:', 'bready-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('twitter') ); ?>" name="<?php echo esc_attr( $this->get_field_name('twitter') ); ?>" type="text" value="<?php echo esc_attr($twitter); ?>" /></p>
		
		<p><label for="<?php echo esc_attr( $this->get_field_id('linkedin') ); ?>"><?php esc_html_e('Linkedin:', 'bready-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('linkedin') ); ?>" name="<?php echo esc_attr( $this->get_field_name('linkedin') ); ?>" type="text" value="<?php echo esc_attr($linkedin); ?>" /></p>
		
		<p><label for="<?php echo esc_attr( $this->get_field_id('pinterest') ); ?>"><?php esc_html_e('Pinterest:', 'bready-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('pinterest') ); ?>" name="<?php echo esc_attr( $this->get_field_name('pinterest') ); ?>" type="text" value="<?php echo esc_attr($pinterest); ?>" /></p>
		
		<p><label for="<?php echo esc_attr( $this->get_field_id('instagram') ); ?>"><?php esc_html_e('Instagram:', 'bready-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('instagram') ); ?>" name="<?php echo esc_attr( $this->get_field_name('instagram') ); ?>" type="text" value="<?php echo esc_attr($instagram); ?>" /></p>
		
		<p><label for="<?php echo esc_attr( $this->get_field_id('tumblr') ); ?>"><?php esc_html_e('Tumblr:', 'bready-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('tumblr') ); ?>" name="<?php echo esc_attr( $this->get_field_name('tumblr') ); ?>" type="text" value="<?php echo esc_attr($tumblr); ?>" /></p>
		
		<p><label for="<?php echo esc_attr( $this->get_field_id('dribbble') ); ?>"><?php esc_html_e('Dribbble:', 'bready-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('dribbble') ); ?>" name="<?php echo esc_attr( $this->get_field_name('dribbble') ); ?>" type="text" value="<?php echo esc_attr($dribbble); ?>" /></p>
		
		<?php
	}
	
	// Updating widget replacing old instances with new
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		$instance['logo']     		= sanitize_text_field( $new_instance['logo'] );
		$instance['intro'] 				= strip_tags($new_instance['intro']);
		$instance['facebook']            = sanitize_text_field( $new_instance['facebook'] );
		$instance['google']            = sanitize_text_field( $new_instance['google'] );
		$instance['twitter']            = sanitize_text_field( $new_instance['twitter'] );
		$instance['linkedin']            = sanitize_text_field( $new_instance['linkedin'] );
		$instance['pinterest']            = sanitize_text_field( $new_instance['twitter'] );
		$instance['instagram']            = sanitize_text_field( $new_instance['instagram'] );
		$instance['tumblr']            = sanitize_text_field( $new_instance['tumblr'] );
		$instance['dribbble']            = sanitize_text_field( $new_instance['dribbble'] );

		return $instance;
	}
	
	/**
	 * @param array $args
	 * @param array $instance
	 */
	public function widget( $args, $instance ) {
		$logo = ( isset($instance['logo']) && !empty($instance['logo']) ) ? $instance['logo'] : '';
		$intro = ( isset($instance['intro']) && !empty($instance['intro']) ) ? $instance['intro'] : '';
		//Social
		$facebook = ( isset($instance['facebook']) && !empty($instance['facebook']) ) ? $instance['facebook'] : '';
		$google = ( isset($instance['google']) && !empty($instance['google']) ) ? $instance['google'] : '';
		$twitter = ( isset($instance['twitter']) && !empty($instance['twitter']) ) ? $instance['twitter'] : '';
		$linkedin = ( isset($instance['linkedin']) && !empty($instance['linkedin']) ) ? $instance['linkedin'] : '';
		$pinterest = ( isset($instance['pinterest']) && !empty($instance['pinterest']) ) ? $instance['pinterest'] : '';
		$instagram = ( isset($instance['instagram']) && !empty($instance['instagram']) ) ? $instance['instagram'] : '';
		$tumblr = ( isset($instance['tumblr']) && !empty($instance['tumblr']) ) ? $instance['tumblr'] : '';
		$dribbble = ( isset($instance['dribbble']) && !empty($instance['dribbble']) ) ? $instance['dribbble'] : '';
		
		echo $args['before_widget'];
			?>
			<?php if(!empty($logo)){ ?>
				<a class="ps-logo" href="<?php echo esc_url(home_url('/'));?>">
					<img src="<?php echo esc_attr($logo);?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>">
				</a>
			<?php }?>
			
			<?php if(!empty($intro)){ ?>
				<?php echo wp_kses_post(wpautop($intro));?>
			<?php }?>
			
			<ul class="ps-list--social">
				<?php if(!empty($facebook)){?><li><a href="<?php echo esc_url($facebook);?>"><i class="fa fa-facebook"></i></a></li><?php }?>
				<?php if(!empty($google)){?><li><a href="<?php echo esc_url($google);?>"><i class="fa fa-google-plus"></i></a></li><?php }?>
				<?php if(!empty($twitter)){?><li><a href="<?php echo esc_url($twitter);?>"><i class="fa fa-twitter"></i></a></li><?php }?>
				<?php if(!empty($linkedin)){?><li><a href="<?php echo esc_url($linkedin);?>"><i class="fa fa-linkedin"></i></a></li><?php }?>
				<?php if(!empty($pinterest)){?><li><a href="<?php echo esc_url($pinterest);?>"><i class="fa fa-pinterest"></i></a></li><?php }?>
				<?php if(!empty($instagram)){?><li><a href="<?php echo esc_url($instagram);?>"><i class="fa fa-instagram"></i></a></li><?php }?>
				<?php if(!empty($tumblr)){?><li><a href="<?php echo esc_url($tumblr);?>"><i class="fa fa-tumblr"></i></a></li><?php }?>
				<?php if(!empty($dribbble)){?><li><a href="<?php echo esc_url($dribbble);?>"><i class="fa fa-dribbble"></i></a></li><?php }?>
			</ul>
			<?php
		echo $args['after_widget'];
	}
}

?>