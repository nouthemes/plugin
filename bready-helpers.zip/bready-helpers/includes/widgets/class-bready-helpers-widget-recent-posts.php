<?php
/**
 * Extend Recent Posts Widget 
 *
 * Adds different formatting to the default WordPress Recent Posts Widget
 */

Class Bready_Helpers_Widget_Recent_Posts extends WP_Widget {
	public function __construct() {
		$widget_ops = array(
			'classname' => 'widget_recent-posts',
			'description' => esc_html__( 'Custom list posts.', 'bready-helpers' ),
			'customize_selective_refresh' => true,
		);
		parent::__construct('Bready_Helpers_Recent_Posts_Widget', esc_html__('* Custom Recent Posts', 'bready-helpers'), $widget_ops);
	}
	function widget($args, $instance) {
	
		extract( $args );
		
		$title = apply_filters('widget_title', empty($instance['title']) ? __('Recent Posts', 'bready-helpers') : $instance['title'], $instance, $this->id_base);
				
		if( empty( $instance['number'] ) || ! $number = absint( $instance['number'] ) )
			$number = 5;
					
		$r = new WP_Query( apply_filters( 'widget_posts_args', array( 'posts_per_page' => $number, 'no_found_rows' => true, 'post_status' => 'publish', 'ignore_sticky_posts' => true ) ) );
		if( $r->have_posts() ) :
			
			echo $before_widget;
			if( $title ) echo $before_title . $title . $after_title; ?>
			<div class="widget_recent-posts__content">
				<?php while( $r->have_posts() ) : $r->the_post(); ?>
					<div class="ps-post--sidebar">
                        <?php noubready_post_thumbnail('thumbnail'); ?>
                        <div class="ps-post__content"><a class="ps-post__title" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                          <p><?php echo get_the_date();?></p>
                        </div>
                     </div>
					  
				<?php endwhile; ?>
			</div>
			 
			<?php
			echo $after_widget;
		
		wp_reset_postdata();
		
		endif;
	}
	
	// Widget Backend 
	public function form( $instance ) {

		$instance = wp_parse_args( 
			(array) $instance, array(
			 'title' => '',
			 'number' => '',
			 ) 
		);
		$title 				= strip_tags($instance['title']);
		$number 				= strip_tags($instance['number']);
		?>

		<p><label for="<?php echo esc_attr( $this->get_field_id('title') ); ?>"><?php esc_html_e('Title:', 'bready-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('title') ); ?>" name="<?php echo esc_attr( $this->get_field_name('title') ); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>
		
		
		<p><label for="<?php echo esc_attr( $this->get_field_id('number') ); ?>"><?php esc_html_e('Number of posts to show:', 'bready-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('number') ); ?>" name="<?php echo esc_attr( $this->get_field_name('number') ); ?>" type="text" value="<?php echo esc_attr($number); ?>" /></p>
		<?php
	}

	
	
	// Updating widget replacing old instances with new
	public function update( $new_instance, $old_instance ) {
		
		$instance = $old_instance;

		$instance['title'] 	= strip_tags($new_instance['title']);
		$instance['number'] 	= strip_tags($new_instance['number']);

		return $instance;
	}
	
}