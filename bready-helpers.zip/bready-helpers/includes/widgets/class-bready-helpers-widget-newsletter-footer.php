<?php 
defined( 'ABSPATH' ) OR exit;
/**
* Class widget about
*/
class Bready_Helpers_Widget_Newsletter_Footer extends WP_Widget {
	
	public function __construct() {
		$widget_ops = array(
			'description' => esc_html__( 'Get News & Offer Form...', 'bready-helpers' ),
			'customize_selective_refresh' => true,
		);
		parent::__construct('Bready_Helpers_Widget_Newsletter_Footer', esc_html__('* Newsletter Footer', 'bready-helpers'), $widget_ops);
	}
	
	
	// Widget Backend 
	public function form( $instance ) {
		$instance = wp_parse_args((array)$instance, array());
	}
	
	// Updating widget replacing old instances with new
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		return $instance;
	}
	
	/**
	 * @param array $args
	 * @param array $instance
	 */
	public function widget( $args, $instance ) {
		echo $args['before_widget'];
			get_template_part('template-parts/footer/newsletter');
		echo $args['after_widget'];
	}
}

?>