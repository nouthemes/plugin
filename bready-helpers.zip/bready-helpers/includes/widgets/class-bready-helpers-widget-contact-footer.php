<?php 
defined( 'ABSPATH' ) OR exit;
/**
* Class widget about
*/
class Bready_Helpers_Widget_Contact_Footer extends WP_Widget {
	
	public function __construct() {
		$widget_ops = array(
			'description' => esc_html__( 'About store with address, phone newsletter ...', 'bready-helpers' ),
			'customize_selective_refresh' => true,
		);
		parent::__construct('Bready_Helpers_Widget_Contact_Footer', esc_html__('* Contact Footer', 'bready-helpers'), $widget_ops);
	}
	
	
	// Widget Backend 
	public function form( $instance ) {
		$instance = wp_parse_args((array)$instance, array(
			'title' => '',
			'address' => '',
			'phone' => '',
			
		));
		$title     		=  $instance['title'] ;
		$address     		=  $instance['address'] ;
		$phone           	=  $instance['phone'] ;
		?>
		<p><label for="<?php echo esc_attr( $this->get_field_id('title') ); ?>"><?php esc_html_e('Title:', 'bready-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('title') ); ?>" name="<?php echo esc_attr( $this->get_field_name('title') ); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>
		
		<p><label for="<?php echo esc_attr( $this->get_field_id('address') ); ?>"><?php esc_html_e('Address:', 'bready-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('address') ); ?>" name="<?php echo esc_attr( $this->get_field_name('address') ); ?>" type="text" value="<?php echo esc_attr($address); ?>" /></p>
		
		<p><label for="<?php echo esc_attr( $this->get_field_id('phone') ); ?>"><?php esc_html_e('Phone:', 'bready-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('phone') ); ?>" name="<?php echo esc_attr( $this->get_field_name('phone') ); ?>" type="text" value="<?php echo esc_attr($phone); ?>" /></p>
		
		<?php
	}
	
	// Updating widget replacing old instances with new
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		$instance['title']     		= sanitize_text_field( $new_instance['title'] );
		$instance['address']     		= sanitize_text_field( $new_instance['address'] );
		$instance['phone']            = sanitize_text_field( $new_instance['phone'] );

		return $instance;
	}
	
	/**
	 * @param array $args
	 * @param array $instance
	 */
	public function widget( $args, $instance ) {
		$title = ( isset($instance['title']) && !empty($instance['title']) ) ? $instance['title'] : '';
		$address = ( isset($instance['address']) && !empty($instance['address']) ) ? $instance['address'] : '';
		$phone = ( isset($instance['phone']) && !empty($instance['phone']) ) ? $instance['phone'] : '';
		
		echo $args['before_widget'];
			?>
			<div class="ps-footer__contact">
				<?php if(!empty($title)){?><h4><?php echo esc_attr($title);?></h4><?php }?>
				<?php if(!empty($address)){?><p><?php echo esc_attr($address);?></p><?php }?>
				<?php if(!empty($phone)){?><P><?php echo esc_attr($phone);?></P><?php }?>
			 </div>
			<?php
		echo $args['after_widget'];
	}
}

?>