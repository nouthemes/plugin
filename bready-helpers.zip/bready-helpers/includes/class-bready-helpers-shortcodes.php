<?php 
/**
* 
*/
class Bready_Helpers_Shortcodes
{
	
	/**
	 * Init shortcodes.
	 */
	public static function init() {
		$shortcodes = array(
			'section_title'  	=> 'Bready_Helpers_Shortcode_Sectiontitle',
			'google_map'  	=> 'Bready_Helpers_Shortcode_Google_Map',
			'contact_form'  	=> 'Bready_Helpers_Shortcode_Contactform',
			'dealer_location'  	=> 'Bready_Helpers_Shortcode_Dealer_Location',
			'follow_us'  	=> 'Bready_Helpers_Shortcode_Follow_Us',
			'feature'  	=> 'Bready_Helpers_Shortcode_Feature',
			'award'  	=> 'Bready_Helpers_Shortcode_Award',
			'posts'  	=> 'Bready_Helpers_Shortcode_Blog',
			'banners' 			   => 'Bready_Helpers_Shortcode_Banners',
			'products' 			   => 'Bready_Helpers_Shortcode_Products',
			'testimonial' 				   => 'Bready_Helpers_Shortcode_Testimonial',
			'testimonial_item' 			   => 'Bready_Helpers_Shortcode_Testimonial_Item',
			'quote' 			   => 'Bready_Helpers_Shortcode_Quote',
			'our_team' 			   => 'Bready_Helpers_Shortcode_Ourteam',
			'countdown' 			   => 'Bready_Helpers_Shortcode_Countdowm',
			'countdown_item' 			   => 'Bready_Helpers_Shortcode_Countdown_Item',
			'delivery_form' 			   => 'Bready_Helpers_Shortcode_Delivery_Form',
			'delivery_form_item' 			   => 'Bready_Helpers_Shortcode_Delivery_Form_Item',
			'contact_footer' 			   => 'Bready_Helpers_Shortcode_Contact_Footer',
			'block_square' 			   => 'Bready_Helpers_Shortcode_Block_Square',
			'block_square_item' 			   => 'Bready_Helpers_Shortcode_Block_Square_Item',
			'tab' 			   => 'Bready_Helpers_Shortcode_Tab',
		);

		if(!empty($shortcodes)):
			foreach ( $shortcodes as $shortcode => $function ) {
				add_shortcode( apply_filters( "noubready_{$shortcode}_shortcode_tag", 'noubready_'.$shortcode ), array($function, 'shortcode') );
				add_action( 'vc_before_init', array($function, 'map') );
			}

			add_action( 'vc_before_init', array(__CLASS__, 'add_params') );
		endif;
	}

	public static function add_params(){
		$attribute_vc_row = array(
		    'type' => 'dropdown',
			'heading' => esc_html__( "Row with container", 'bready-helpers' ),
			'param_name' => 'with_container',
			'value' => array(
				esc_html__( 'Default', 'bready-helpers' ) => 'default',
				esc_html__( 'Container', 'bready-helpers' ) => 'container',
				esc_html__( 'PS Container', 'bready-helpers' ) => 'ps-container',
			),
		);
		vc_add_param( 'vc_row', $attribute_vc_row );
	}


	/**
	 * get-attributes-of-nested-shortcodes
	 *
	 * @param string $str
	 * @param array $atts
	 *
	 * @return string
	 * @link http://wordpress.stackexchange.com/questions/121562/get-attributes-of-nested-shortcodes
	 */
	public static function get_attributes_nested_shortcodes( $str, $att = null ) {
		$res = array();
		$reg = get_shortcode_regex();
		preg_match_all( '~' . $reg . '~', $str, $matches );
		$i = 0;
		foreach ( $matches[2] as $key => $name ) {
			$parsed = shortcode_parse_atts( $matches[3][ $key ] );
			$parsed = is_array( $parsed ) ? $parsed : array();

			$res[ $i ]              = array_key_exists( $att, $parsed ) ? $parsed[ $att ] : $parsed;
			$res[ $i ]['name']      = $name;
			$res[ $i ]['shortcode'] = $matches[0][ $key ];
			$i                      = $i + 1;
		}

		return $res;
	}

}
?>