<?php
/**
* Sync from customizer vs theme options
* 
* @author nouthemes [nouthemes@gmail.com]
* @since 1.0
* @return url
* @code nouthemes
*/
if(!function_exists('bready_helpers_theme_option')){
  function bready_helpers_theme_option($setting, $default = '')
  { 
    $options = get_option( '_noubready_options', array() );
    $value = $default;
    if ( isset( $options[ $setting ] ) ) {
        $value = $options[ $setting ];
    }
    return $value;
  }
}

/**
 *
 * Get option
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! function_exists( 'bready_helpers_cs_get_option' ) ) {
  function bready_helpers_cs_get_option( $option_name = '', $default = '' ) {

    $options = apply_filters( 'cs_get_option', get_option( BREADY_HELPERS_CS_OPTION ), $option_name, $default );

    if( ! empty( $option_name ) && ! empty( $options[$option_name] ) ) {
      return $options[$option_name];
    } else {
      return ( ! empty( $default ) ) ? $default : null;
    }

  }
}

function bready_helpers_get_current_id(){
	$object_id = get_queried_object_id();
    if ( ( get_option( 'show_on_front' ) && get_option( 'page_for_posts' ) && is_home() ) || ( get_option( 'page_for_posts' ) && is_archive() && ! is_post_type_archive() && ! is_tax() ) && ! ( is_tax( 'product_cat' ) || is_tax( 'product_tag' ) ) || ( get_option( 'page_for_posts' ) && is_search() ) ) {
        
        $page_ID = get_option( 'page_for_posts' );

    } else {

        if ( isset( $object_id ) ) {
            $page_ID = $object_id;
        }

        if ( ! is_singular() ) {
            $page_ID = false;
        }

    }

    return $page_ID;
}

/**
 * Get post like
 *
 * @package Bready_Helpers
 * @since 1.0
 * @author nouthemes [nouthemes@gmail.com]
 */

if(!function_exists('bready_helpers_post_like')){
	function bready_helpers_post_like($id = null) 
	{
		$post_id = bready_helpers_get_current_id();
		if($id){
			$post_id = $id;
		}
		$meta = get_post_meta($post_id, '_post_like_count', true);

		if ( is_numeric( $meta ) && $meta > 0 ) { 
			$number = bready_helpers_format_count($meta);
		} else {
			$number = 0;
		}
			
	    return $number;
	}
}


/**
 * Format number with K, M, B
 *
 * @package Bready_Helpers
 * @since 1.0
 * @author nouthemes [nouthemes@gmail.com]
 */
if(!function_exists('bready_helpers_format_count')){
	function bready_helpers_format_count( $number ) {
		$precision = 2;
		if ( $number >= 1000 && $number < 1000000 ) {
			$formatted = number_format( $number/1000, $precision ).'K';
		} else if ( $number >= 1000000 && $number < 1000000000 ) {
			$formatted = number_format( $number/1000000, $precision ).'M';
		} else if ( $number >= 1000000000 ) {
			$formatted = number_format( $number/1000000000, $precision ).'B';
		} else {
			$formatted = $number; // Number is less than 1000
		}
		$formatted = str_replace( '.00', '', $formatted );
		return $formatted;
	}
}


/**
 * Get current IP address
 *
 * @package Bready_Helpers
 * @since 1.0
 * @author nouthemes [nouthemes@gmail.com]
 */
if(!function_exists('bready_helpers_get_ip')){
	function bready_helpers_get_ip() {
		if ( isset( $_SERVER['HTTP_CLIENT_IP'] ) && ! empty( $_SERVER['HTTP_CLIENT_IP'] ) ) {
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		} elseif ( isset( $_SERVER['HTTP_X_FORWARDED_FOR'] ) && ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} else {
			$ip = ( isset( $_SERVER['REMOTE_ADDR'] ) ) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
		}
		$ip = filter_var( $ip, FILTER_VALIDATE_IP );
		$ip = ( $ip === false ) ? '0.0.0.0' : $ip;
		return $ip;
	}
}


if(!function_exists('bready_helpers_already_liked')){
	function bready_helpers_already_liked( $post_id, $is_comment = null ) {
		
		$post_users = NULL;
		$user_id = NULL;

		if ( is_user_logged_in() ) { // user is logged in

			$user_id = get_current_user_id();
			$post_meta_users = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_liked" ) : get_post_meta( $post_id, "_user_liked" );
			
			if ( count( $post_meta_users ) != 0 ) {
				$post_users = $post_meta_users[0];
			}

		} else { // user is anonymous

			$user_id = bready_helpers_get_ip();
			$post_meta_users = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_IP" ) : get_post_meta( $post_id, "_user_IP" ); 
			
			if ( count( $post_meta_users ) != 0 ) { // meta exists, set up values
				$post_users = $post_meta_users[0];
			}
		}

		if ( is_array( $post_users ) && in_array( $user_id, $post_users ) ) {
			return true;
		} else {
			return false;
		}
	}
}

/**
 * Utility returns the button icon for "like" action
 * @since    1.0
 */
if(!function_exists('bready_helpers_get_liked_icon')){
	function bready_helpers_get_liked_icon() {
		$loved_icon = bready_helpers_theme_option('bready_helpers_loved_icon', 'icon ba-heart');
		$icon = ' <i class="'.esc_attr( $loved_icon ).'"></i>';
		return $icon;
	}
}	

if(!function_exists('bready_helpers_get_unliked_icon')){
	function bready_helpers_get_unliked_icon() {
		$love_icon = bready_helpers_theme_option('bready_helpers_love_icon', 'ba-heart');
		$icon = '<i class="'.esc_attr( $love_icon ).'"></i>';
		return $icon;
	}
}	

if(!function_exists('bready_helpers_button_like')){
	function bready_helpers_button_like($post_id, $class = '', $icon = '', $count = '', $title = '', $echo = true)
	{
		if(empty($title)){
			$title = esc_html__('Like', 'bready-helpers');
		}

		if(empty($icon)){
			$icon = bready_helpers_get_unliked_icon();
		}

		$liked = bready_helpers_already_liked($post_id);
		$count = get_post_meta( $post_id, "_post_like_count", true );
		if(empty($count)) {
			$count = 0; 
		}
		if($liked){
			$class = esc_attr( 'liked', 'bready-helpers' );
			$title = esc_html__( 'Unlike', 'bready-helpers' );
			$icon = bready_helpers_get_liked_icon();
		}
		$disableIcon = $count == 0 ? 'disabled' : '';
		$output = '<a data-id="'.intval($post_id).'" class="post-like like '.esc_attr($class).'">'.wp_kses_post($icon).'<span class="'.esc_attr($disableIcon).'"><i>'.$count.'</i></span></a>';

		
		$display_button = bready_helpers_theme_option('bready_helpers_post_like');
		$post_id = bready_helpers_get_current_id();
		if($post_id){
			$noubready_meta = get_post_meta( $post_id, 'noubready_layout_settings', true );
	        if ( !empty($noubready_meta['social_like']) ) {
	          $display_button = $noubready_meta['social_like'];
	        }
		}

		if(empty($display_button)){
			$output = '';
		}

		if($echo){
			echo $output;
		}else{
			return $output;
		}
	}
}


if(!function_exists('bready_helpers_share_post')){
	function bready_helpers_share_post()
	{
		$share = bready_helpers_theme_option('noubready_enable_share');
		$post_id = bready_helpers_get_current_id();
		if($post_id){
			$noubready_meta = get_post_meta( $post_id, 'noubready_layout_settings', true );
	        if ( !empty($noubready_meta['social_share']) ) {
	          $share = $noubready_meta['social_share'];
	        }
		}
		if($share):
			$facebook = bready_helpers_theme_option('noubready_single_share_facebook');
			$google = bready_helpers_theme_option('noubready_single_share_google');
			$twitter = bready_helpers_theme_option('noubready_single_share_twitter');
			if( !empty($facebook) || !empty($google) || !empty($twitter) ):
			?>
			<div class="ps-post__action shared">
				<a href="#"><i class="fa fa-share-alt"></i> <?php esc_html_e('Share', 'bready-helpers');?></a>
				<ul class="ps-list--shared" data-title="<?php the_title();?>" data-url="<?php the_permalink();?>">
					<?php if(!empty($facebook)):?>
					<li class="facebook"><a href="#" data-type="facebook"><i class="fa fa-facebook"></i></a></li>
					<?php endif;?>

					<?php if(!empty($twitter)):?>
					<li class="twitter"><a href="#" data-type="twitter"><i class="fa fa-twitter"></i></a></li>
					<?php endif;?>

					<?php if(!empty($google)):?>
					<li class="google"><a href="#" data-type="google"><i class="fa fa-google-plus"></i></a></li>
					<?php endif;?>
				</ul>
			</div>
			<?php
			endif;
		endif;
	}
}
if(!function_exists('bready_helpers_share_product')){
	function bready_helpers_share_product()
	{
		?>
		<p class="text-right" data-title="<?php the_title();?>" data-url="<?php the_permalink();?>"><?php esc_html_e('Share this:', 'bready-helpers');?>
			<a href="#" data-type="facebook"><i class="fa fa-facebook"></i></a>

			<a href="#" data-type="twitter"><i class="fa fa-twitter"></i></a>
			
			<a href="#" data-type="pinterest"><i class="fa fa-pinterest"></i></a>
		</p>
		<?php
	}
}

function bready_helpers_post_user_likes( $user_id, $post_id, $is_comment ) {
	$post_users = '';
	$post_meta_users = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_liked" ) : get_post_meta( $post_id, "_user_liked" );
	if ( count( $post_meta_users ) != 0 ) {
		$post_users = $post_meta_users[0];
	}
	if ( !is_array( $post_users ) ) {
		$post_users = array();
	}
	if ( !in_array( $user_id, $post_users ) ) {
		$post_users['user-' . $user_id] = $user_id;
	}
	return $post_users;
} 

function bready_helpers_post_ip_likes( $user_ip, $post_id, $is_comment ) {
	$post_users = '';
	$post_meta_users = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_IP" ) : get_post_meta( $post_id, "_user_IP" );
	// Retrieve post information
	if ( count( $post_meta_users ) != 0 ) {
		$post_users = $post_meta_users[0];
	}
	if ( !is_array( $post_users ) ) {
		$post_users = array();
	}
	if ( !in_array( $user_ip, $post_users ) ) {
		$post_users['ip-' . $user_ip] = $user_ip;
	}
	return $post_users;
}

function bready_helpers_get_image_by_id($id, $size, $class = array()){
	$image_attributes = wp_get_attachment_image_src( $id, $size );
	if($image_attributes){
		echo '<img src="'.esc_attr($image_attributes[0]).'" alt="'.esc_attr(get_bloginfo('name')).'">';
	}
}

add_action('wp_loaded', 'bready_helpers_update_cart_item_form_handler');
function bready_helpers_update_cart_item_form_handler(){
	if(isset($_POST['bready_update_cart']) && isset($_POST['product_id']) && isset($_POST['qty'])){
		if ( ! WC()->cart->is_empty() ) {
			foreach ( WC()->cart->get_cart() as $cart_item_key => $values ) {
				if ( $_POST['product_id'] == $values['product_id'] ){
					WC()->cart->set_quantity( $cart_item_key, $_POST['qty'], false );
					WC()->cart->calculate_totals();
					wc_add_notice( esc_html__( 'Cart updated.', 'bready-helpers' ) );
				}
			}
		}
	}
}

//Custom Post Type Package
add_action( 'init', 'bready_helpers_package_init' );
function bready_helpers_package_init() {
	$labels = array(
		'name'               => _x( 'Packages', 'post type general name', 'bready-helpers' ),
		'singular_name'      => _x( 'Package', 'post type singular name', 'bready-helpers' ),
		'menu_name'          => _x( 'Packages', 'admin menu', 'bready-helpers' ),
		'name_admin_bar'     => _x( 'Package', 'add new on admin bar', 'bready-helpers' ),
		'add_new'            => _x( 'Add New', 'package', 'bready-helpers' ),
		'add_new_item'       => __( 'Add New Package', 'bready-helpers' ),
		'new_item'           => __( 'New Package', 'bready-helpers' ),
		'edit_item'          => __( 'Edit Package', 'bready-helpers' ),
		'view_item'          => __( 'View Package', 'bready-helpers' ),
		'all_items'          => __( 'All Packages', 'bready-helpers' ),
		'search_items'       => __( 'Search Packages', 'bready-helpers' ),
		'parent_item_colon'  => __( 'Parent Packages:', 'bready-helpers' ),
		'not_found'          => __( 'No packages found.', 'bready-helpers' ),
		'not_found_in_trash' => __( 'No packages found in Trash.', 'bready-helpers' )
	);

	$args = array(
		'labels'             => $labels,
                'description'        => __( 'Description.', 'bready-helpers' ),
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'package' ),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => null,
		'supports'           => array( 'title', 'editor', 'thumbnail',)
	);

	register_post_type( 'package', $args );
}

add_action( 'init', 'bready_helpers_create_package_tax' );
function bready_helpers_create_package_tax() {
	register_taxonomy(
		'package_cat',
		'package',
		array(
			'label' => __( 'Categories' ),
			'rewrite' => array( 'slug' => 'package_cat' ),
			'hierarchical' => true,
			'public'       => true,
			'show_ui'      => true,
			'query_var'    => true
		)
	);
}
?>