<?php
/**
* 
*/
class Exist_Theme_Helpers_Shortcode_Contact_Info
{
	
	public static function shortcode($atts){
		$atts = shortcode_atts( array(
			'address' => '',
			'phone' => '',
			'email' => '',
			'working_hours' => '',
			'desc' => '',
			'title' => '',
			'css' => '',
			'attributes' => '',
			'form_id' => '',
			'style' => '',
		), $atts, 'nouexist_contact_info' );

		$style = !empty($atts['style']) ? $atts['style'] : '1';
		$title = !empty($atts['title']) ? $atts['title'] : '';
		$desc = !empty($atts['desc']) ? $atts['desc'] : '';
		$address = !empty($atts['address']) ? $atts['address'] : '';
		$phone = !empty($atts['phone']) ? $atts['phone'] : '';
		$email = !empty($atts['email']) ? $atts['email'] : '';
		$working_hours = !empty($atts['working_hours']) ? $atts['working_hours'] : '';

		
		$css = !empty($atts['css']) ? $atts['css'] : '';

		$attributes = !empty($atts['attributes']) ? $atts['attributes'] : '';
		$attributes = str_replace('``', '"', $attributes);
		
		ob_start(); 
			?>
			<div class="<?php echo esc_attr($css);?>" <?php echo Exist_Theme_Helpers_Unicode_Replace_Entities::UTF8entities(join(' ', explode(',', $attributes)));?>>
		        <div class="ps-contact__info">
		          	<?php if(!empty($title)){?><h3 class="ps-heading"><?php echo esc_html($title);?></h3><?php }?>
		          	<?php if(!empty($desc)){echo wp_kses_post(wpautop($desc));}?>

		          	<?php if($style == '1'):?>
				        <div class="ps-contact__detail">
				            <?php if(!empty($address)){?><p><span><?php esc_html_e('Address', 'exist-theme-helpers');?></span><?php echo esc_html($address);?></p><?php }?>
				            <?php if(!empty($phone)){?><p><span><?php esc_html_e('Phone', 'exist-theme-helpers');?></span><?php echo esc_html($phone);?></p><?php }?>
				            <?php if(!empty($email)){?><p><span><?php esc_html_e('Email', 'exist-theme-helpers');?></span><a href="mailto:<?php echo esc_html($email);?>"><?php echo esc_html($email);?></a></p><?php }?>
				            <?php if(!empty($working_hours)){?><p><span><?php esc_html_e('Working Hours', 'exist-theme-helpers');?></span> <?php echo wp_kses_post($working_hours);?></p><?php }?>
				        </div>
			        	<?php if(!empty($atts['form_id'])){echo do_shortcode('[contact-form-7 id="'.intval($atts['form_id']).'"]');}?>
		        	<?php endif;?>
		        </div>

		        <?php if($style == '2'):?>
		        <div class="row">

		        	<?php if(!empty($address)){?>
	                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 ">
	                  <div class="ps-block--contact"><img src="<?php echo esc_attr(EXIST_HELPERS_URL .'/public/');?>images/icons/icon-contact-1.png" alt="">
	                    <p><?php esc_html_e('Address', 'exist-theme-helpers');?></p>
	                    <p><strong><?php echo esc_html($address);?></strong></p>
	                  </div>
	                </div>
	                <?php }?>

	                <?php if(!empty($phone)){?>
	                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 ">
	                  <div class="ps-block--contact"><img src="<?php echo esc_attr(EXIST_HELPERS_URL .'/public/');?>images/icons/icon-contact-2.png" alt="">
	                    <p><?php esc_html_e('Phone', 'exist-theme-helpers');?></p>
	                    <p><strong><?php echo esc_html($phone);?></strong></p>
	                  </div>
	                </div>
	                <?php }?>

	                <?php if(!empty($email)){?>
	                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 ">
	                  <div class="ps-block--contact"><img src="<?php echo esc_attr(EXIST_HELPERS_URL .'/public/');?>images/icons/icon-contact-3.png" alt="">
	                    <p><?php esc_html_e('Email', 'exist-theme-helpers'); ?></p>
	                    <p><a href="mailto:<?php echo esc_html($email);?>"><?php echo esc_html($email);?></a></p>
	                  </div>
	                </div>
	                <?php }?>

	          	</div>
	          	<?php endif;?>

		    </div>
			<?php
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		/**
		 * Add Shortcode To Visual Composer
		 */
		$cf7 = get_posts( 'post_type="wpcf7_contact_form"&numberposts=-1' );

		$contact_forms = array(esc_html__('-- Select form --', 'exist-theme-helpers') => '');
		if ( $cf7 ) {
			foreach ( $cf7 as $cform ) {
				$contact_forms[ $cform->post_title ] = $cform->ID;
			}
		} else {
			$contact_forms[ __( 'No contact forms found', 'exist-theme-helpers' ) ] = 0;
		}


		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Exist - Contact info", 'exist-theme-helpers' ),
	      	"base" => "nouexist_contact_info",
	      	"class" => "",
	      	"category" => esc_html__( "Exist Theme", 'exist-theme-helpers'),
    		"params" => array(
		     
				array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Title", 'exist-theme-helpers' ),
		            "param_name" => "title",
		            "holder" => "div",
		        ),
				array(
		            "type" => "textarea",
		            "class" => "",
		            "heading" => esc_html__( "Description", 'exist-theme-helpers' ),
		            "param_name" => "desc",
		        ),
		        array(
		            "type" => "dropdown",
		            "heading" => esc_html__( "Type of section show", 'exist-theme-helpers' ),
		            "param_name" => "style",
		            "value" => array(esc_html__('Normal', 'exist-theme-helpers') => '1', esc_html__('Image icon', 'exist-theme-helpers') => '2'),
		        ),
		        array(
		            "type" => "textfield",
		            "heading" => esc_html__( "Address", 'exist-theme-helpers' ),
		            "param_name" => "address",
		        ),
		        array(
		            "type" => "textfield",
		            "heading" => esc_html__( "Email", 'exist-theme-helpers' ),
		            "param_name" => "email",
		        ),
		        array(
		            "type" => "textfield",
		            "heading" => esc_html__( "Phone", 'exist-theme-helpers' ),
		            "param_name" => "phone",
		        ),
		        array(
		            "type" => "textarea",
		            "heading" => esc_html__( "Working Hours", 'exist-theme-helpers' ),
		            "param_name" => "working_hours",
		            'dependency' => array(
						'element' => 'style',
						'value' => array('1'),
					),
		        ),

		        array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Select contact form', 'exist-theme-helpers' ),
					'param_name' => 'form_id',
					'value' => $contact_forms,
					'save_always' => true,
					'description' => esc_html__( 'Choose previously created contact form from the drop down list.', 'exist-theme-helpers' ),
					'group' => esc_html__('Contact form 7', 'exist-theme-helpers'),
					'dependency' => array(
						'element' => 'style',
						'value' => array('1'),
					),
				),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Custom class CSS", 'exist-theme-helpers' ),
		            "param_name" => "css",
		            'group' => esc_html__('Attributes', 'exist-theme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Custom attribute", 'exist-theme-helpers' ),
		            'description' => esc_html__('Add custom attribute separated by commas, EX: data-mh="contact-1",data-mh="contact-2"', 'exist-theme-helpers'),
		            "param_name" => "attributes",
		            'group' => esc_html__('Attributes', 'exist-theme-helpers'),
		        ),
	      	)
	    ) );
		endif;
	}
}
