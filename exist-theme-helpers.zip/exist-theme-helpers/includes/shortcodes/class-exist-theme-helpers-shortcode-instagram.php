<?php
/**
* 
*/
class Exist_Theme_Helpers_Shortcode_Instagram
{
	
	public static function shortcode($atts, $content = ''){
		$atts = shortcode_atts( array(
			'title' => '',
			'account' => '',
			'number' => '',
		), $atts, 'nouexist_instagram' );
		
		$title = !empty($atts['title']) ? $atts['title'] : '';
		$account = !empty($atts['account']) ? $atts['account'] : '';
		$number = !empty($atts['number']) ? $atts['number'] : '10';
		
		ob_start(); 
			if(!empty($account)):
				if(function_exists('nouexist_scrape_instagram')){
					$data = nouexist_scrape_instagram($account, $number);
		    		if ( !is_wp_error( $data ) && is_array($data) ) {
						?>
						<div class="ps-section--instagram">
						    <div class="container">
						        <div class="ps-section__header">
						          	<?php if(!empty($title)){?><h3><?php echo esc_html($title);?></h3><?php }?>
						          	<?php if(!empty($account)){?><p><?php echo esc_html($account);?></p><?php }?>
						        </div>
						        <div class="ps-section__content">
						          	<div class="ps-slider--instagram ps-slider--center owl-slider" data-owl-auto="true" data-owl-loop="true" data-owl-speed="7000" data-owl-gap="30" data-owl-nav="true" data-owl-dots="false" data-owl-item="4" data-owl-item-xs="3" data-owl-item-sm="4" data-owl-item-md="4" data-owl-item-lg="4" data-owl-duration="1000" data-owl-mousedrag="on" data-owl-nav-left="&lt;i class='exist-leftarrow'&gt;&lt;/i&gt;" data-owl-nav-right="&lt;i class='exist-rightarrow'&gt;&lt;/i&gt;">
						          		<?php 
										$i = 1;
										foreach ($data as $item) {
											if($i <= $number){
												echo '<a href="'.esc_url( $item['link'] ).'" target="_blank">
															<img src="'.esc_attr( $item['url_medium'] ).'" alt="">
														</a>';
											}
											$i++;	
										}
						          		?>
						          </div>
						        </div>
						    </div>
					    </div>
						<?php
					}
				}	
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Exist - Instagram", 'exist-theme-helpers' ),
	      	"base" => "nouexist_instagram",
	      	"class" => "",
	      	"category" => esc_html__( "Exist Theme", 'exist-theme-helpers'),
    		"params" => array(
		     
		        
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "heading" => esc_html__( "Title", 'exist-theme-helpers' ),
		            "param_name" => "title",
		        ),

		        array(
		            "type" => "textfield",
		            "heading" => esc_html__( "Account", 'exist-theme-helpers' ),
		            "param_name" => "account",
		        ),
		        array(
		            "type" => "textfield",
		            "heading" => esc_html__( "Number", 'exist-theme-helpers' ),
		            "param_name" => "number",
		        ),
	      	)
	    ) );
		endif;
	}
}
