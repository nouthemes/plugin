<?php
/**
* 
*/
class Exist_Theme_Helpers_Shortcode_Video
{
	
	public static function shortcode($atts, $content = ''){
		$atts = shortcode_atts( array(
			'title' => '',
			'btn_url' => '',
			'img' => ''
		), $atts, 'nouexist_video' );
		
		$title = !empty($atts['title']) ? $atts['title'] : '';
		$btn_url = !empty($atts['btn_url']) ? $atts['btn_url'] : '';
		$img = !empty($atts['img']) ? $atts['img'] : '';

		ob_start(); 
			if(!empty($img)):
			?>
			<div class="ps-video">
				<div class="ps-video__thumbnail">
					<?php echo nouexist_helpers_get_image_by_id($img, 'full');?>
					<a class="video-popup ps-video__play" href="<?php echo esc_url($btn_url);?>"><i class="exist-play"></i></a>
				</div>
				<div class="ps-video__content">
				<?php echo wp_kses_post(wpautop($title));?>
				</div>
			</div>
			<?php
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Exist - Video Youtube", 'exist-theme-helpers' ),
	      	"base" => "nouexist_video",
	      	"class" => "",
	      	"category" => esc_html__( "Exist Theme", 'exist-theme-helpers'),
    		"params" => array(
		     
		        
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "heading" => esc_html__( "Title", 'exist-theme-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textfield",
		            "heading" => esc_html__( "Button URL", 'exist-theme-helpers' ),
		            "description" => esc_html__( "Video Youtube", 'exist-theme-helpers' ),
		            "param_name" => "btn_url",
		        ),
		        array(
		            "type" => "attach_image",
		            "class" => "",
		            "heading" => esc_html__( "Image", 'exist-theme-helpers' ),
		            "param_name" => "img",
		        ),
	      	)
	    ) );
		endif;
	}
}
