<?php
/**
* 
*/
class Exist_Theme_Helpers_Shortcode_Quote
{
	
	public static function shortcode($atts, $content = ''){
		$atts = shortcode_atts( array(
			'desc' => '',
			'bg' => '',
			'url' => '',
			'btn_text' => '',
		), $atts, 'nouexist_quote' );
		
		$desc = !empty($atts['desc']) ? $atts['desc'] : '';
		$url = !empty($atts['url']) ? $atts['url'] : '';
		$btn_text = !empty($atts['btn_text']) ? $atts['btn_text'] : '';

		$bg = !empty($atts['bg']) ? $atts['bg'] : '';
		$bg_img = '';

		if(!empty($bg)){
			$image = wp_get_attachment_image_src($bg, 'full');
			if($image){
				$bg_img = $image[0];
			}
		}

		
		ob_start(); 
			if(!empty($bg_img)):
			?>
			<div class="ps-section--product-quote">
		      <div class="ps-container-fluid">
		        <div class="row">
		              <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12 ">
		              	<img src="<?php echo esc_attr($bg_img);?>" alt="">
		              </div>
		              <div class="col-lg-7 col-md-7 col-sm-7 col-xs-12 ">
		                <div class="ps-section__content">
		                  <?php if(!empty($desc)){?><h3><?php echo esc_html($desc);?></h3><?php }?>
		                  <?php if(!empty($btn_text)){?><a href="<?php echo esc_url($url);?>"><?php echo esc_html($btn_text);?></a><?php }?>
		                </div>
		              </div>
		        </div>
		      </div>
		    </div>
			<?php
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Exist - Quote", 'exist-theme-helpers' ),
	      	"base" => "nouexist_quote",
	      	"class" => "",
	      	"category" => esc_html__( "Exist Theme", 'exist-theme-helpers'),
    		"params" => array(
		     
		        
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "heading" => esc_html__( "Quote", 'exist-theme-helpers' ),
		            "param_name" => "desc",
		        ),
		        
		        array(
		            "type" => "attach_image",
		            "class" => "",
		            "heading" => esc_html__( "Avatar", 'exist-theme-helpers' ),
		            "param_name" => "bg",
		        ),

		        array(
		            "type" => "textfield",
		            "heading" => esc_html__( "URL", 'exist-theme-helpers' ),
		            "param_name" => "url",
		        ),
		        array(
		            "type" => "textfield",
		            "heading" => esc_html__( "Button text", 'exist-theme-helpers' ),
		            "param_name" => "btn_text",
		        ),
	      	)
	    ) );
		endif;
	}
}
