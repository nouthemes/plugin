<?php
/**
* 
*/
class Exist_Theme_Helpers_Shortcode_Banner_Masonry
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		$atts = shortcode_atts( array(
			'lg_col' => '',
			'md_col' => '',
			'sm_col' => '',
			'xs_col' => '',
			'gap' => '',
			'radio' => '',
			'css' => '',
			'container' => '',
		), $atts, 'nouexist_banner_masonry' );

		$lg_col = !empty($atts['lg_col']) ? $atts['lg_col']: '';
		$md_col = !empty($atts['md_col']) ? $atts['md_col']: '4';
		$sm_col = !empty($atts['sm_col']) ? $atts['sm_col']: '2';
		$xs_col = !empty($atts['xs_col']) ? $atts['xs_col']: '1';
		$gap = !empty($atts['gap']) ? $atts['gap']: '4:3';
		$radio = !empty($atts['radio']) ? $atts['radio']: '0';
		$css = !empty($atts['css']) ? $atts['css']: '';
		$container = !empty($atts['container']) ? $atts['container']: '';

		ob_start();
			if(!empty($content)):
				?>
				<?php if(!empty($css)){?><div class="<?php echo esc_attr($css);?>"><?php }?>
				    <?php if(!empty($container)){?><div class="<?php echo esc_attr($container);?>"><?php }?>
				        <div class="masonry-wrapper" data-col-lg="<?php echo esc_attr($lg_col);?>" data-col-md="<?php echo esc_attr($md_col);?>" data-col-sm="<?php echo esc_attr($sm_col);?>" data-col-xs="<?php echo esc_attr($xs_col);?>" data-gap="<?php echo esc_attr($gap);?>" data-radio="<?php echo esc_attr($radio);?>">
				          <div class="ps-masonry">
				            <div class="grid-sizer"></div>
				            <?php echo do_shortcode($content);?>
				          </div>
				        </div>
				    <?php if(!empty($container)){?></div><?php }?>
				<?php if(!empty($css)){?></div><?php }?>
				<?php
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Exist - Banner Masonry", 'exist-theme-helpers' ),
	      	"base" => "nouexist_banner_masonry",
	      	"class" => "",
	      	"category" => esc_html__( "Exist Theme", 'exist-theme-helpers'),
	      	"params" => array(
	      		array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Column big desktops screen", 'exist-theme-helpers' ),
		            "param_name" => "lg_col",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Column desktops screen", 'exist-theme-helpers' ),
		            "param_name" => "md_col",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Column tablets screen", 'exist-theme-helpers' ),
		            "param_name" => "sm_col",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Column phones screen", 'exist-theme-helpers' ),
		            "param_name" => "xs_col",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Data-gap", 'exist-theme-helpers' ),
		            'description' => esc_html__('Value from 5 to 100, step 5.'),
		            "param_name" => "gap",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Data-radio", 'exist-theme-helpers' ),
		            "param_name" => "radio",
		        ),

		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Custom class css", 'exist-theme-helpers' ),
		            "param_name" => "css",
		            'group' => esc_html__('Style', 'exist-theme-helpers'),
		        ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "heading" => esc_html__( "Container", 'exist-theme-helpers' ),
		            "param_name" => "container",
		            "value" => array(
		            	esc_html__('Default', 'exist-theme-helpers') => '', 
		            	esc_html__('Container', 'exist-theme-helpers') => 'container', 
		            	esc_html__('Container fluid', 'exist-theme-helpers') => 'ps-container-fluid',
		            ),
		            'group' => esc_html__('Style', 'exist-theme-helpers')
		        ),
	      	),
	      	"as_parent" => array('only' => 'nouexist_banner_masonry_item'),
	      	"content_element" => true,
		    "show_settings_on_create" => false,
		    "is_container" => true,
		    "js_view" => 'VcColumnView'
	    ) );
		endif;
	}
}
?>