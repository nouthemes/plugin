<?php
/**
* 
*/
class Exist_Theme_Helpers_Shortcode_Testimonial_Item
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		$atts = shortcode_atts( array(
			'name' => '',
			'date' => '',
			'img' => '',
			'desc' => '',
		), $atts, 'nouexist_testimonial_item' );
		
		ob_start();
			if(!empty($atts['desc'])):
			?>
			<div class="ps-block--testimonial">
                <div class="ps-block__header">
                	<?php 
					if($atts['img']):
						$image = wp_get_attachment_image_src($atts['img'], 'thumbnail');
						if($image){	
							echo '<img src="'.esc_attr($image[0]).'" alt="">';
						}
					endif;
					?>
                    
                    <?php if(!empty($atts['name'])):?>
	              		<h5><?php echo esc_html($atts['name']);?></h5>
	              	<?php endif;?>

                    <?php if(!empty($atts['date'])):?>
	              		<p><?php echo esc_html($atts['date']);?></p>
	              	<?php endif;?>
                </div>

                <?php if(!empty($atts['desc'])):?>
              	<div class="ps-block__content">
                	<p><?php echo esc_html($atts['desc']);?></p>
              	</div>
              	<?php endif;?>

            </div>
			<?php	
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		vc_map( array(
	      	"name" => esc_html__( "Exist - Testimonial Item", 'exist-theme-helpers' ),
	      	"base" => "nouexist_testimonial_item",
	      	"class" => "",
	      	"category" => esc_html__( "Exist Theme", 'exist-theme-helpers'),
	      	"content_element" => true,
    		"as_child" => array('only' => 'nouexist_testimonial'),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Name", 'exist-theme-helpers' ),
		            "param_name" => "name",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Date", 'exist-theme-helpers' ),
		            "param_name" => "date",
		        ),
		        array(
		            "type" => "attach_image",
		            "class" => "",
		            "heading" => esc_html__( "Avatar", 'exist-theme-helpers' ),
		            "param_name" => "img",
		        ),
		        array(
		            "type" => "textarea",
		            "class" => "",
		            "heading" => esc_html__( "Description", 'exist-theme-helpers' ),
		            "param_name" => "desc",
		        )
	      	)
	    ) );
	}
}
?>