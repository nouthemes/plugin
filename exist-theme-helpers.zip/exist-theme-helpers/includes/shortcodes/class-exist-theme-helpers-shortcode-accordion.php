<?php
/**
* 
*/
class Exist_Theme_Helpers_Shortcode_Accordion
{
	
	public static function shortcode($atts, $content = ''){
		$atts = shortcode_atts( array(
			'title' => '',
			'desc' => '',
			'active' => '',
		), $atts, 'nouexist_accordion' );
		
		$title = !empty($atts['title']) ? $atts['title'] : '';
		$desc = !empty($atts['desc']) ? $atts['desc'] : '';

		ob_start(); 
			if(!empty($desc)):
			?>
			<div class="ps-accordion <?php if(!empty($atts['active'])){echo 'active';}?>">

				<?php if(!empty($title)){?>
		        <div class="ps-accordion__header">
		            <p><?php echo esc_html($title);?></p>
		        </div>
		        <?php }?>

		        <div class="ps-accordion__content">
		            <?php echo wp_kses_post(wpautop($desc));?>
		        </div>
	        </div>
			<?php
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Exist - Accordion", 'exist-theme-helpers' ),
	      	"base" => "nouexist_accordion",
	      	"class" => "",
	      	"category" => esc_html__( "Exist Theme", 'exist-theme-helpers'),
    		"params" => array(
		     
		        
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "heading" => esc_html__( "Title", 'exist-theme-helpers' ),
		            "param_name" => "title",
		        ),
		        
		        array(
		            "type" => "textarea",
		            "class" => "",
		            "heading" => esc_html__( "Description", 'exist-theme-helpers' ),
		            "param_name" => "desc",
		        ),
		        array(
		            "type" => "checkbox",
		            "heading" => esc_html__( "Active?", 'exist-theme-helpers' ),
		            "param_name" => "active",
		        ),
	      	)
	    ) );
		endif;
	}
}
