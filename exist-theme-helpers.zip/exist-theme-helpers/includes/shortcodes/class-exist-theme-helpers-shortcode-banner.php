<?php
/**
* 
*/
class Exist_Theme_Helpers_Shortcode_Banner
{
	
	public static function shortcode($atts, $content = ''){
		$atts = shortcode_atts( array(
			'title' => '',
			'btn_text' => '',
			'btn_url' => '',
			'img' => '',
			'style' => '',
			'attributes' => '',
		), $atts, 'nouexist_banner' );
		
		$title = !empty($atts['title']) ? $atts['title'] : '';
		$btn_text = !empty($atts['btn_text']) ? $atts['btn_text'] : '';
		$btn_url = !empty($atts['btn_url']) ? $atts['btn_url'] : '';
		$img = !empty($atts['img']) ? $atts['img'] : '';
		$style = !empty($atts['style']) ? $atts['style'] : '1';

		$attributes = !empty($atts['attributes']) ? $atts['attributes'] : '';
		$attributes = str_replace('``', '"', $attributes);

		$bg = '';
		$image = wp_get_attachment_image_src($atts['img'], 'full');
		if($image){
			$bg = $image[0];
		}

		ob_start(); 
			if(!empty($img)):
				switch ($style) {
					case '2':
						?>
						<div class="ps-collection-column ps-collection--2">
							<?php echo nouexist_helpers_get_image_by_id($img, 'full');?>
		                  	<div class="ps-collection__content">
		                    	<?php if(!empty($title)){?><h3><?php echo wp_kses_post($title);?></h3><?php }?>

		                    	<?php if(!empty($btn_text)){?><a class="ps-btn ps-btn--outline" href="<?php echo esc_url($btn_url);?>"><?php echo esc_html($btn_text);?></a><?php }?>
		                  	</div>
		                </div>
						<?php
						break;

					case '3':
						?>
						<div class="ps-collection-column ps-collection--6 <?php if(!empty($bg)){echo 'bg--cover';}?>" <?php if(!empty($bg)){echo 'data-background="'.esc_attr($bg).'"';}?> <?php echo Exist_Theme_Helpers_Unicode_Replace_Entities::UTF8entities(join(' ', explode(',', $attributes)));?>>
		                  	<div class="ps-collection__content">
		                    	<?php if(!empty($title)){?><h4><?php echo wp_kses_post($title);?></h4><?php }?>
		                    	
		                    	<?php if(!empty($btn_text)){?><a class="ps-btn--underline" href="<?php echo esc_url($btn_url);?>"><?php echo esc_html($btn_text);?></a><?php }?>
		                  	</div>
		                </div>
						<?php
						break;
					

					case '4':
						?>
			
						<div class="ps-collection-column ps-collection--group">
							<?php echo nouexist_helpers_get_image_by_id($img, 'full');?>
				            <div class="ps-collection__content">
				              <?php if(!empty($title)){?><?php echo wp_kses_post($title);?><?php }?>
		                    	
		                    	<?php if(!empty($btn_text)){?><a class="ps-btn--underline" href="<?php echo esc_url($btn_url);?>"><?php echo esc_html($btn_text);?></a><?php }?>
				            </div>
				        </div>
						<?php
						break;
					

					case '5':
						?>
			
						<div class="ps-collection-column ps-collection">
							<?php if(!empty($btn_text)){?><a class="ps-collection__morelink" href="<?php echo esc_url($btn_url);?>"><?php echo esc_html($btn_text);?></a><?php }?>
							<?php if(!empty($bg)){?>
								<img class="ps-fullwidth" src="<?php echo esc_attr($bg);?>" alt="">
							<?php }?>
				            
				        </div>
						<?php
						break;
					
					default:
						?>
						<div class="ps-collection-column ps-collection--3">
							<?php echo nouexist_helpers_get_image_by_id($img, 'full');?>
							<?php if(!empty($btn_text)){?><a class="ps-btn" href="<?php echo esc_url($btn_url);?>"><?php echo esc_html($btn_text);?></a><?php }?>
						</div>
						<?php
						break;
				}
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Exist - Banner", 'exist-theme-helpers' ),
	      	"base" => "nouexist_banner",
	      	"class" => "",
	      	"category" => esc_html__( "Exist Theme", 'exist-theme-helpers'),
    		"params" => array(
		     
		        
		        array(
		            "type" => "textarea",
		            "holder" => "div",
		            "heading" => esc_html__( "Title", 'exist-theme-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textfield",
		            "heading" => esc_html__( "Button text", 'exist-theme-helpers' ),
		            "param_name" => "btn_text",
		        ),
		        array(
		            "type" => "textfield",
		            "heading" => esc_html__( "Button URL", 'exist-theme-helpers' ),
		            "param_name" => "btn_url",
		        ),
		        array(
		            "type" => "attach_image",
		            "class" => "",
		            "heading" => esc_html__( "Image", 'exist-theme-helpers' ),
		            "param_name" => "img",
		        ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "heading" => esc_html__( "Type of item show", 'exist-theme-helpers' ),
		            "param_name" => "style",
		            "value" => array(
		            	esc_html__('Style #1', 'exist-theme-helpers') => '1', 
		            	esc_html__('Style #2', 'exist-theme-helpers') => '2',
		            	esc_html__('Style #3', 'exist-theme-helpers') => '3',
		            	esc_html__('Style #4', 'exist-theme-helpers') => '4',
		            	esc_html__('Style #5', 'exist-theme-helpers') => '5',
		            ),
		            'group' => esc_html__('Display', 'exist-theme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Custom attribute", 'exist-theme-helpers' ),
		            'description' => esc_html__('Add custom attribute separated by commas, EX: data-mh="contact-1",data-mh="contact-2"', 'exist-theme-helpers'),
		            "param_name" => "attributes",
		            'group' => esc_html__('Attributes', 'exist-theme-helpers'),
		        ),
	      	)
	    ) );
		endif;
	}
}
