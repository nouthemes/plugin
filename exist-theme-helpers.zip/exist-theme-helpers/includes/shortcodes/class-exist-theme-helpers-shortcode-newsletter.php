<?php
/**
* 
*/
class Exist_Theme_Helpers_Shortcode_Newsletter
{
	
	public static function shortcode($atts, $content = ''){
		$atts = shortcode_atts( array(
			'title' => '',
			'desc' => '',
			'form' => '',
			'button_text' => '',
			'style' => '',
			'custom_bg' => '',
			'bg' => '',
			'css' => '',
			'attributes' => '',
		), $atts, 'nouexist_newsletter' );

		$form = exist_helpers_option('nouexist_newsletter_form');
		if(!empty($atts['form'])){
			$form = $atts['form'];
			$form = str_replace('```}`', '"]', $form);
			$form = str_replace('`{`', '[', $form);
			$form = str_replace('``', '"', $form);
		}

		$title = exist_helpers_option('nouexist_newsletter_title');
		if(!empty($atts['title'])){
			$title = $atts['title'];
		}

		$button_text = exist_helpers_option('nouexist_newsletter_button_text');
		if(!empty($atts['button_text'])){
			$button_text = $atts['button_text'];
		}

		$desc = exist_helpers_option('nouexist_newsletter_desc');
		if(!empty($atts['desc'])){
			$desc = $atts['desc'];
		}

		$style = !empty($atts['style']) ? $atts['style'] : '1';
		$bg = exist_helpers_option('nouexist_newsletter_bg', NOUEXIZT_IMG.'/background/subscribe-2.jpg');
		
		if($atts['custom_bg'] == 'hide'){
			$bg = '';
		}

		if($atts['custom_bg'] == 'custom' && !empty($atts['bg'])){
			$image = wp_get_attachment_image_src($atts['bg'], 'full');
			if($image){
				$bg = $image[0];
			}
		}

		$css = !empty($atts['css']) ? $atts['css'] : '';

		$attributes = !empty($atts['attributes']) ? $atts['attributes'] : '';
		$attributes = str_replace('``', '"', $attributes);

		ob_start(); 
			?>
			<?php 
			if(!empty($form)):
				echo '<div class="nouexist-subscribe '.esc_attr($css).'">';
					switch ($style) {
						case '2':
							?>
							<div class="ps-subscribe--2 <?php if(!empty($bg)){echo 'bg--cover';}?>" <?php if(!empty($bg)){echo 'data-background="'.esc_attr($bg).'"';}?> <?php echo Exist_Theme_Helpers_Unicode_Replace_Entities::UTF8entities(join(' ', explode(',', $attributes)));?>>
							    <div class="container">
							    	<div class="hidden"><?php if(!empty($form)){echo do_shortcode($form);}?></div>
							        <form class="ps-form--subscribe-2 nouexist-subscribe-form" method="post">
							          <?php if(!empty($title)){echo '<h3 class="ps-heading">'.esc_html($title).'</h3>';}?>
							          <?php echo wpautop($desc);?>
							          <div class="nouexist-subscribe-message"></div>
							          <div class="form-group">
							            <input class="form-control" name="your_email" type="email" placeholder="<?php esc_html_e('Your Email Address', 'exist-theme-helpers');?>" required>
							            <button class="btn-fake-subscribe ps-btn"><?php echo esc_html($button_text);?></button>
							          </div>
							        </form>
							    </div>
						    </div>
							<?php
							break;
						case '3':
							?>
							<div class="ps-subscribe--3 <?php if(!empty($bg)){echo 'bg--cover';}?>" <?php if(!empty($bg)){echo 'data-background="'.esc_attr($bg).'"';}?> <?php echo Exist_Theme_Helpers_Unicode_Replace_Entities::UTF8entities(join(' ', explode(',', $attributes)));?>>
							    <div class="ps-container-fluid">
							    	<div class="hidden"><?php if(!empty($form)){echo do_shortcode($form);}?></div>
							        <form class="ps-form--subscribe-3 nouexist-subscribe-form" method="post">
							          <?php if(!empty($title)){echo '<h3 class="ps-heading">'.esc_html($title).'</h3>';}?>
							          <?php echo wpautop($desc);?>
							          <div class="nouexist-subscribe-message"></div>
							          <div class="form-group">
							            <input class="form-control" name="your_email" type="email" placeholder="<?php esc_html_e('Your Email Address', 'exist-theme-helpers');?>" required>
							            <button class="btn-fake-subscribe ps-btn ps-btn--red"><?php echo esc_html($button_text);?></button>
							          </div>
							        </form>
							    </div>
						    </div>
							<?php
							break;
						case '4':
							?>
							<div class="<?php if(!empty($bg)){echo 'bg--cover';}?>" <?php if(!empty($bg)){echo 'data-background="'.esc_attr($bg).'"';}?> <?php echo Exist_Theme_Helpers_Unicode_Replace_Entities::UTF8entities(join(' ', explode(',', $attributes)));?>>
						    	<div class="hidden"><?php if(!empty($form)){echo do_shortcode($form);}?></div>
						    	<form class="ps-form--subscribe-4 nouexist-subscribe-form " method="post">
				                  <?php if(!empty($title)){echo '<h3 class="ps-heading">'.esc_html($title).'</h3>';}?>
						          <?php echo wpautop($desc);?>
				                  <div class="nouexist-subscribe-message"></div>
						          <div class="form-group">
						            <input class="form-control" name="your_email" type="email" placeholder="<?php esc_html_e('Your Email Address', 'exist-theme-helpers');?>" required>
				                    <button class="btn-fake-subscribe ps-btn"><?php echo esc_html($button_text);?></button>
				                  </div>
				                </form>
						    </div>
							<?php
							break;	
						case '5':
							?>
							<div class="ps-subscribe--4 <?php if(!empty($bg)){echo 'bg--cover';}?>" <?php if(!empty($bg)){echo 'data-background="'.esc_attr($bg).'"';}?> <?php echo Exist_Theme_Helpers_Unicode_Replace_Entities::UTF8entities(join(' ', explode(',', $attributes)));?>>
							    
								<div class="container">
									<div class="hidden"><?php if(!empty($form)){echo do_shortcode($form);}?></div>
							        <form class="ps-form--subscribe-5 nouexist-subscribe-form" method="post">
							          <div class="row">
							                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 ">
							                  	<?php if(!empty($title)){echo '<h3 class="ps-heading">'.esc_html($title).'</h3>';}?>
							          			<?php echo wpautop($desc);?>
							                </div>
							                <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 ">
							                 
									          <div class="form-group">
									            <input class="form-control" name="your_email" type="email" placeholder="<?php esc_html_e('Your Email Address', 'exist-theme-helpers');?>" required>
							                    <button class="btn-fake-subscribe ps-btn ps-btn--black"><?php echo esc_html($button_text);?></button>
							                  </div>
							                  <div class="nouexist-subscribe-message"></div>
							                </div>
							          </div>
							        </form>
							    </div>
						    </div>
							<?php
							break;	
						default:
							?>
							<div class="ps-section--subscribe <?php if(!empty($bg)){echo 'bg--cover';}?>" <?php if(!empty($bg)){echo 'data-background="'.esc_attr($bg).'"';}?>>
						    	<div class="ps-container-fluid">
						    		<div class="hidden"><?php if(!empty($form)){echo do_shortcode($form);}?></div>
						    		<form class="ps-form--subscribe nouexist-subscribe-form" method="post">
							          <?php if(!empty($title)){echo '<h3 class="ps-heading">'.esc_html($title).'</h3>';}?>
							          <?php echo wpautop($desc);?>
							          <div class="nouexist-subscribe-message"></div>
							          <div class="form-group">
							            <input class="form-control" name="your_email" type="email" placeholder="<?php esc_html_e('Your Email Address', 'exist-theme-helpers');?>" required>
							          </div>
							          <div class="form-group">
							            <button type="button" class="btn-fake-subscribe ps-btn ps-btn--black"><?php echo esc_html($button_text);?></button>
							          </div>
							        </form>
							    </div>
							</div>
							<?php
							break;
					}
				echo '</div>';	
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Exist - Newsletter", 'exist-theme-helpers' ),
	      	"base" => "nouexist_newsletter",
	      	"class" => "",
	      	"category" => esc_html__( "Exist Theme", 'exist-theme-helpers'),
    		"params" => array(
    			array(
		            "type" => "textfield",
		            "heading" => esc_html__( "Shortcode form MailChimp for WordPress", 'exist-theme-helpers' ),
		            "param_name" => "form",
		        ),
    			array(
		            "type" => "textfield",
		            "holder" => "div",
		            "heading" => esc_html__( "Title", 'exist-theme-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textfield",
		            "heading" => esc_html__( "Button title", 'exist-theme-helpers' ),
		            "param_name" => "button_text",
		        ),
		        array(
		            "type" => "textarea",
		            "class" => "",
		            "heading" => esc_html__( "Description", 'exist-theme-helpers' ),
		            "param_name" => "desc",
		        ),
    			array(
		            "type" => "dropdown",
		            "class" => "",
		            "holder" => "div",
		            "heading" => esc_html__( "Type of section show", 'exist-theme-helpers' ),
		            "param_name" => "style",
		            "value" => array(
		            	esc_html__('Style #1', 'exist-theme-helpers') => '1', 
		            	esc_html__('Style #2', 'exist-theme-helpers') => '2',
		            	esc_html__('Style #3', 'exist-theme-helpers') => '3',
		            	esc_html__('Style #4', 'exist-theme-helpers') => '4',
		            	esc_html__('Style #5', 'exist-theme-helpers') => '5',
		            ),
		        ),
		        array(
				    'type' => 'dropdown',
				    'heading' => esc_html__( "Custom Background", 'exist-theme-helpers' ),
				    'param_name' => 'custom_bg',
				    "value" => array(
				    	esc_html__('Default', 'exist-theme-helpers') => 'default', 
				    	esc_html__('Hide', 'exist-theme-helpers') => 'hide',
				    	esc_html__('Custom', 'exist-theme-helpers') => 'custom',
				    ),
				    'group' => esc_html__('Background', 'exist-theme-helpers')
				),
		        array(
		            "type" => "attach_image",
		            "class" => "",
		            "heading" => esc_html__( "Background image", 'exist-theme-helpers' ),
		            "param_name" => "bg",
		            'dependency' => array(
						'element' => 'custom_bg',
						'value' => array('custom'),
					),
					'group' => esc_html__('Background', 'exist-theme-helpers')
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Custom class CSS", 'exist-theme-helpers' ),
		            "param_name" => "css",
		            'group' => esc_html__('Attributes', 'exist-theme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Custom attribute", 'exist-theme-helpers' ),
		            'description' => esc_html__('Add custom attribute separated by commas, EX: data-mh="contact-1",data-mh="contact-2"', 'exist-theme-helpers'),
		            "param_name" => "attributes",
		            'group' => esc_html__('Attributes', 'exist-theme-helpers'),
		        ),
	      	)
	    ) );
		endif;
	}
}
