<?php
/**
* 
*/
class Exist_Theme_Helpers_Shortcode_Features
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		$atts = shortcode_atts( array(
			'desc' => '',
			'title' => '',
		), $atts, 'nouexist_features' );
		
		$title = !empty($atts['title']) ? $atts['title'] : '';
		$desc = !empty($atts['desc']) ? $atts['desc'] : '';
		
		ob_start();
			if(!empty($content)):
			?>
			<div class="ps-about-features">
			    <div class="container">
			        <div class="ps-section__header">
			          <?php if(!empty($title)){?><h3 class="ps-heading"><?php echo esc_html($title);?></h3><?php }?>
	                	<?php echo wp_kses_post(wpautop($desc));?>
			        </div>
			        <div class="ps-section__content">
			          <div class="row">
			                <?php echo do_shortcode($content);?>
			          </div>
			        </div>
			    </div>
			</div>
			<?php	
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Exist - Features", 'exist-theme-helpers' ),
	      	"base" => "nouexist_features",
	      	"class" => "",
	      	"category" => esc_html__( "Exist Theme", 'exist-theme-helpers'),
	      	"params" => array(
	      		array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Title", 'exist-theme-helpers' ),
		            "param_name" => "title",
		            "holder" => "div",
		        ),
				array(
		            "type" => "textarea",
		            "class" => "",
		            "heading" => esc_html__( "Description", 'exist-theme-helpers' ),
		            "param_name" => "desc",
		        ),
	      	),
	      	"as_parent" => array('only' => 'nouexist_feature_item'),
	      	"content_element" => true,
		    "show_settings_on_create" => false,
		    "is_container" => true,
		    "js_view" => 'VcColumnView'
	    ) );
		endif;
	}
}
?>