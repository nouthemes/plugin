<?php
/**
* 
*/
class Exist_Theme_Helpers_Shortcode_Block_Products
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		if ( empty( $atts ) ) {
			return '';
		}

		$atts = shortcode_atts( array(
			'title' => '',
			'type' => '',
			'ids' => '',
			'cat' => '',
			'number' => '',
			'order_by' => '',
			'url' => '',
		), $atts, 'nouexist_block_products' );

		$type = !empty($atts['type']) ? $atts['type'] : 'recent';
		$number = !empty($atts['number']) ? $atts['number'] : '3';

		if(!empty($atts['url'])){
			$url = $atts['url'];
		}else{
			$url = get_permalink(get_option('woocommerce_shop_page_id'));
		}
		$atts['number'] = $number;
		$products = self::get_products($atts);
		ob_start();
			if($products->have_posts()):
				?>
				<div class="ps-block--catalog">
					<div class="ps-block__header">
						<?php if(!empty($atts['title'])){?><h4><?php echo esc_html($atts['title']);?></h4><?php }?>
						<a href="<?php echo esc_url($url);?>"><?php esc_html_e('Shop all', 'exist-theme-helpers');?><i class="exist-rightarrow"></i></a>
					</div>
					<div class="ps-block__content">
						<?php
						while ($products->have_posts()) { $products->the_post();
							?>
							<div class="ps-product--catalog">
			                    <div class="ps-product__thumbnail">
			                    	<a class="ps-product__overlay" href="<?php the_permalink();?>"></a>
			                    	<?php the_post_thumbnail('nouexist_100x100');?>
			                    </div>
			                    <div class="ps-product__content">
			                    	<a class="ps-product__title" href="<?php the_permalink();?>"><?php the_title();?></a>
			                    	<?php woocommerce_template_loop_rating();?>
			                        <p><?php woocommerce_template_loop_price();?></p>
			                    </div>
		                    </div>
							<?php
						}
						?>
					</div>
				</div>
				<?php
			endif;wp_reset_postdata();
		return ob_get_clean();
		
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		vc_map( array(
	      	"name" => esc_html__( "Exist - Block Products", 'exist-theme-helpers' ),
	      	"base" => "nouexist_block_products",
	      	"class" => "",
	      	"category" => esc_html__( "Exist Theme", 'exist-theme-helpers'),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "heading" => esc_html__( "Title", 'exist-theme-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textfield",
		            "heading" => esc_html__( "Shop all URL", 'exist-theme-helpers' ),
		            "param_name" => "url",
		        ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "holder" => "div",
		            "heading" => esc_html__( "Type of products show", 'exist-theme-helpers' ),
		            "param_name" => "type",
		            "value" => array(esc_html__('--Select type--', 'exist-theme-helpers') => '', esc_html__('Recent', 'exist-theme-helpers') => 'recent', esc_html__('Featured', 'exist-theme-helpers') => 'featured', esc_html__('Sale', 'exist-theme-helpers') => 'onsale', esc_html__('Best sale', 'exist-theme-helpers') => 'bestsale'), 
		            'group' => esc_html__('Display', 'exist-theme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "IDs posts, EX: 21,22,23", 'exist-theme-helpers' ),
		            "param_name" => "ids",
		            'group' => esc_html__('Display', 'exist-theme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Category ID", 'exist-theme-helpers' ),
		            "param_name" => "cat",
		            'group' => esc_html__('Display', 'exist-theme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Number of posts show(default 3)", 'exist-theme-helpers' ),
		            "param_name" => "number",
		            'group' => esc_html__('Display', 'exist-theme-helpers'),
		        ),
	      	)
	    ) );
	}

	private static function get_products($atts){
		return nouexist_get_products($atts);
	}
}
?>