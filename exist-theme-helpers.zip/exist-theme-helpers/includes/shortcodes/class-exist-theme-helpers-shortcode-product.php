<?php
/**
* 
*/
class Exist_Theme_Helpers_Shortcode_Product
{
	
	public static function shortcode($atts, $content = ''){
		$atts = shortcode_atts( array(
			'id' => '',
			'number' => '1',
			'thumbnail_size' => '',
		), $atts, 'nouexist_product' );
		
		$id = !empty($atts['id']) ? $atts['id'] : '';
		$size = !empty($atts['thumbnail_size']) ? $atts['thumbnail_size'] : 'full';
		
		ob_start(); 
			if(!empty($id) && intval($id)):
				$products = nouexist_get_products($atts);
				if($products->have_posts()):
					$shop = nouexist_shop_style();
					while($products->have_posts()): $products->the_post();
						$product = wc_get_product(get_the_ID());
						if($product):
						?>
						<div <?php post_class('ps-product--1'); ?> data-id="<?php the_ID();?>" data-url="<?php the_permalink();?>" data-title="<?php the_title();?>" data-mh="product-item-simple">
		                    <div class="ps-product__thumbnail">
		                        <?php woocommerce_show_product_loop_sale_flash();?>
						        <a href="<?php the_permalink();?>">
						            <?php the_post_thumbnail($size);?>
						        </a>
						          
						        <?php if(!empty($shop['addtocart'])):?>
						            <?php woocommerce_template_loop_add_to_cart();?>
						        <?php endif;?>


						        <?php do_action( 'nouexist_shop_loop_item_social' );?>
		                    </div>
		                    <div class="ps-product__content">
		                      	<a class="ps-product__title" href="<?php the_permalink();?>"> <?php the_title();?></a>
		        				<?php woocommerce_template_loop_price();?>
		                    </div>
		                </div>
						<?php
						endif;
					endwhile;
				endif;wp_reset_postdata();	
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Exist - Product", 'exist-theme-helpers' ),
	      	"base" => "nouexist_product",
	      	"class" => "",
	      	"category" => esc_html__( "Exist Theme", 'exist-theme-helpers'),
    		'description' => __( 'Show a single product by ID or SKU', 'exist-theme-helpers' ),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => __( 'Product ID', 'exist-theme-helpers' ),
					'param_name' => 'id',
					'description' => __( 'Input product ID or product SKU or product title to see suggestions', 'exist-theme-helpers' ),
				),
			),
	    ) );
		endif;
	}
}
