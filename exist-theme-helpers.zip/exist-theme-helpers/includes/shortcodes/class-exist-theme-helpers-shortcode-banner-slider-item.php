<?php
/**
* 
*/
class Exist_Theme_Helpers_Shortcode_Banner_Slider_Item
{
	
	/**
	 * Brand slider item
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts ) {
		$atts = shortcode_atts( array(
			'title' => '',
			'desc' => '',
			'btn_text' => '',
			'img' => '',
			'url' => '',
			'color' => '',
		), $atts, 'nouexist_banner_slider_item' );

		$title = !empty($atts['title']) ? $atts['title'] : '';
		$desc = !empty($atts['desc']) ? $atts['desc'] : '';
		$btn_text = !empty($atts['btn_text']) ? $atts['btn_text'] : '';
		$url = !empty($atts['url']) ? $atts['url'] : '';
		$img = !empty($atts['img']) ? $atts['img'] : '';
		$color = !empty($atts['color']) ? $atts['color'] : '';

		ob_start();
			if(!empty($atts['img'])):
				$image = wp_get_attachment_image_src($atts['img'], 'full');
				if($image){
					?>
					<div class="ps-block--catalog-slider <?php echo esc_attr($color);?> bg--cover" data-background="<?php echo esc_attr($image[0]);?>">
						<img src="<?php echo esc_attr($image[0]);?>" alt="">
				        <div class="ps-block__content">
				          	<?php if(!empty($title)){?><?php echo wp_kses_post($title);?><?php }?>
				          	<?php if(!empty($desc)){?><?php echo wp_kses_post(wpautop($desc));?><?php }?>
				          	<?php if(!empty($btn_text)){?><a class="ps-btn" href="<?php echo esc_url($url);?>"><?php echo esc_html($btn_text);?></a><?php }?>
				        </div>
				    </div>
					<?php
				}
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand items.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Exist - Banner Slider Item", 'exist-theme-helpers' ),
	      	"base" => "nouexist_banner_slider_item",
	      	"class" => "",
	      	"category" => esc_html__( "Exist Theme", 'exist-theme-helpers'),
	      	"content_element" => true,
    		"as_child" => array('only' => 'nouexist_banner_slider'),
    		"params" => array(
		        
		        array(
		            "type" => "textarea",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", 'exist-theme-helpers' ),
		            "param_name" => "title",
		        ),

		        array(
		            "type" => "textarea",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Description", 'exist-theme-helpers' ),
		            "param_name" => "desc",
		        ),
		        array(
		            "type" => "attach_image",
		            "class" => "",
		            "heading" => esc_html__( "Image", 'exist-theme-helpers' ),
		            "param_name" => "img",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Button text", 'exist-theme-helpers' ),
		            "param_name" => "btn_text",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "URL", 'exist-theme-helpers' ),
		            "param_name" => "url",
		        ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "heading" => esc_html__( "Color", 'exist-theme-helpers' ),
		            "param_name" => "color",
		            "value" => array(
		            	esc_html__('Default', 'exist-theme-helpers') => '', 
		            	esc_html__('White', 'exist-theme-helpers') => 'white', 
		            	esc_html__('Black', 'exist-theme-helpers') => 'black', 
		            ),
		            'group' => esc_html__('Style', 'exist-theme-helpers')
		        ),
	      	)
	    ) );
		endif;
	}
}
?>