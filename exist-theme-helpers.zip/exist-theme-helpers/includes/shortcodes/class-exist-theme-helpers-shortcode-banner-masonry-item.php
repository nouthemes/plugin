<?php
/**
* 
*/
class Exist_Theme_Helpers_Shortcode_Banner_Masonry_Item
{
	
	/**
	 * Brand slider item
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts ) {
		$atts = shortcode_atts( array(
			'style' => '',
			'title' => '',
			'desc' => '',
			'btn_text' => '',
			'img' => '',
			'url' => '',
			'display' => '',
			'align' => '',
			'price' => '',
			'position' => '',
		), $atts, 'nouexist_banner_masonry_item' );

		$align = !empty($atts['align']) ? $atts['align'] : '';
		$position = !empty($atts['position']) ? $atts['position'] : '';
		$style = !empty($atts['style']) ? $atts['style'] : '1';

		ob_start();
			if(!empty($atts['img'])):
				switch ($style) {
					case '2':
						?>
						<div class="grid-item <?php if($atts['display']){echo esc_attr($atts['display']);}?>">
				            <div class="grid-item__content-wrapper">
				                <div class="ps-collection--5 <?php echo esc_attr($align);?> <?php echo esc_attr($position);?>">

				                	<?php
			                    	$image = wp_get_attachment_image_src($atts['img'], 'full');
									if($image){
			                    	?>
			                    	<img src="<?php echo esc_attr($image['0']);?>" alt="">
			                    	<?php }?>

					                <div class="ps-collection__content">

					                	<?php if(!empty($atts['title'])){?>
					                    	<h4><?php echo wp_kses_post($atts['title']);?></h4>
					                    <?php }?>

					                    <?php if(!empty($atts['desc'])){?>
					                    	<?php echo wp_kses_post(wpautop($atts['desc']));?>
					                    <?php }?>

					                    <?php if(!empty($atts['btn_text'])){?>
				                    	<a class="ps-btn--underline" href="<?php echo esc_attr($atts['url']);?>"><?php echo esc_html($atts['btn_text']);?></a>
				                    	<?php }?>

					                </div>
				                </div>
				            </div>
				        </div>
						<?php
						break;
					case '3':
						?>
						<div class="grid-item <?php if($atts['display']){echo esc_attr($atts['display']);}?>">
							<div class="grid-item__content-wrapper">
				                <div class="ps-collection--align <?php echo esc_attr($align);?> <?php echo esc_attr($position);?>">
				                	<?php
			                    	$image = wp_get_attachment_image_src($atts['img'], 'full');
									if($image){
			                    	?>
			                    	<img src="<?php echo esc_attr($image['0']);?>" alt="">
			                    	<?php }?>

				                  	<div class="ps-collection__content">
				                    	<?php if(!empty($atts['title'])){?>
					                    	<h3><?php echo wp_kses_post($atts['title']);?></h3>
					                    <?php }?>

					                    <?php if(!empty($atts['desc'])){?>
					                    	<?php echo wp_kses_post(wpautop($atts['desc']));?>
					                    <?php }?>
				                  	</div>
				                </div>
				            </div>
				        </div>
						<?php
						break;
					case '4':
						?>
						<div class="grid-item">
				            <div class="grid-item__content-wrapper">
				                <div class="ps-collection--4 wow zoomIn <?php if($atts['display']){echo esc_attr($atts['display']);}?>">
					                <div class="ps-collection__thumbnail">
					                  	<a class="ps-collection__overlay" href="<?php echo esc_attr($atts['url']);?>"></a>
					                  	<?php
				                    	$image = wp_get_attachment_image_src($atts['img'], 'full');
										if($image){
				                    	?>
				                    	<img src="<?php echo esc_attr($image['0']);?>" alt="">
				                    	<?php }?>
					                </div>
					                <?php if(!empty($atts['title'])){?>
				                    	<h3 class="ps-collection__name"><span></span><?php echo wp_kses_post($atts['title']);?></h3>
				                    <?php }?>
				                  	
				                  	<?php if(!empty($atts['btn_text'])){?>
			                    	<a class="ps-btn--underline" href="<?php echo esc_attr($atts['url']);?>"><?php echo esc_html($atts['btn_text']);?></a>
			                    	<?php }?>
				                </div>
				            </div>
				        </div>
						<?php
						break;
					case '5':
						?>
						<div class="grid-item <?php if($atts['display']){echo esc_attr($atts['display']);}?>">
							<div class="grid-item__content-wrapper">
				                <div class="ps-collection--5">
				                	<a href="<?php echo esc_attr($atts['url']);?>">
				                		<?php
				                    	$image = wp_get_attachment_image_src($atts['img'], 'full');
										if($image){
				                    	?>
				                    	<img src="<?php echo esc_attr($image['0']);?>" alt="">
				                    	<?php }?>
				                	</a>
				                </div>
				            </div>
				        </div>
						<?php
						break;
					case '6':
						?>
						<div class="grid-item <?php if($atts['display']){echo esc_attr($atts['display']);}?>">
							<div class="grid-item__content-wrapper">
								<div class="ps-collection--bottom">
									<?php
			                    	$image = wp_get_attachment_image_src($atts['img'], 'full');
									if($image){
			                    	?>
			                    	<img src="<?php echo esc_attr($image['0']);?>" alt="">
			                    	<?php }?>

									<?php if(!empty($atts['btn_text'])){?>
			                    	<a class="ps-btn ps-collection__morelink" href="<?php echo esc_attr($atts['url']);?>"><?php echo esc_html($atts['btn_text']);?></a>
			                    	<?php }?>
								</div>
				            </div>
				        </div>
						<?php
						break;
					case '7':
						?>
						<div class="grid-item">
				            <div class="grid-item__content-wrapper">
				              <div class="ps-product--inside">
				                <div class="ps-product__thumbnail">
				                	<?php
			                    	$image = wp_get_attachment_image_src($atts['img'], 'full');
									if($image){
			                    	?>
			                    	<img src="<?php echo esc_attr($image['0']);?>" alt="">
			                    	<?php }?>

				                	<a class="ps-product__overlay" href="<?php echo esc_attr($atts['url']);?>"></a>
				                </div>
				                <div class="ps-product__content">
				                	<a class="ps-product__title" href="<?php echo esc_attr($atts['url']);?>"><?php echo wp_kses_post($atts['title']);?></a>
				                  	<?php echo wp_kses_post(wpautop($atts['desc']));?>
				                  	<span><?php echo esc_html($atts['price']);?></span>
				                </div>
				              </div>
				            </div>
				        </div>
						<?php
						break;
					case '8':
						?>
						<div class="grid-item <?php if($atts['display']){echo esc_attr($atts['display']);}?>">
			              	<div class="grid-item__content-wrapper">
				                <div class="ps-collection--8">
				                	<?php
			                    	$image = wp_get_attachment_image_src($atts['img'], 'full');
									if($image){
			                    	?>
			                    	<img src="<?php echo esc_attr($image['0']);?>" alt="">
			                    	<?php }?>

					                <div class="ps-collection__content">
					                    <h3><?php echo wp_kses_post($atts['title']);?></h3>
					                    <?php echo wp_kses_post(wpautop($atts['desc']));?>
					                </div>
				                </div>
			              	</div>
			            </div>
						<?php
						break;
					case '9':
						?>
						<div class="grid-item">
			              	<div class="grid-item__content-wrapper">
				                <div class="ps-collection--special">
				                	<?php
			                    	$image = wp_get_attachment_image_src($atts['img'], 'full');
									if($image){
			                    	?>
			                    	<img src="<?php echo esc_attr($image['0']);?>" alt="">
			                    	<?php }?>
				                  	<div class="ps-collection__content">
				                    	<h4><?php echo wp_kses_post($atts['title']);?></h4>
				                    	<?php echo wp_kses_post(wpautop($atts['desc']));?>
				                    	
				                    	<?php if(!empty($atts['btn_text'])){?>
				                    	<a class="ps-btn--underline" href="<?php echo esc_attr($atts['url']);?>"><?php echo esc_html($atts['btn_text']);?></a>
				                    	<?php }?>
				                  	</div>
				                </div>
			              	</div>
			            </div>
						<?php
						break;
					case '10':
						?>
						<div class="grid-item">
			              	<div class="grid-item__content-wrapper">
				                <div class="ps-video ps-video--sm">
				                  	<div class="ps-video__thumbnail">
				                  		<?php
				                    	$image = wp_get_attachment_image_src($atts['img'], 'full');
										if($image){
				                    	?>
				                    	<img src="<?php echo esc_attr($image['0']);?>" alt="">
				                    	<?php }?>

				                  		<a class="video-popup ps-video__play" href="<?php echo esc_attr($atts['url']);?>"><i class="exist-play"></i></a>
				                  	</div>
				                </div>
			              	</div>
			            </div>
						<?php
						break;
					case '11':
						?>
						<div class="grid-item <?php if($atts['display']){echo esc_attr($atts['display']);}?>">
			              	<div class="grid-item__content-wrapper">
				                <div class="ps-collection--11 <?php echo esc_attr($align);?>">
				                	<?php
			                    	$image = wp_get_attachment_image_src($atts['img'], 'full');
									if($image){
			                    	?>
			                    	<img src="<?php echo esc_attr($image['0']);?>" alt="">
			                    	<?php }?>
				                  	<div class="ps-collection__content">
				                    	<h4><?php echo wp_kses_post($atts['title']);?></h4>
				                    	
				                    	<?php if(!empty($atts['btn_text'])){?>
				                    	<a class="ps-btn--underline" href="<?php echo esc_attr($atts['url']);?>"><?php echo esc_html($atts['btn_text']);?></a>
				                    	<?php }?>
				                  	</div>
				                </div>
			              	</div>
			            </div>
						<?php
						break;
					default:
						?>
						<div class="grid-item <?php if($atts['display']){echo esc_attr($atts['display']);}?>">
			              	<div class="grid-item__content-wrapper">
			                	<div class="ps-collection <?php echo esc_attr($align);?> <?php echo esc_attr($position);?>">

			                		<?php if(!empty($atts['btn_text'])){?>
			                    	<a class="ps-collection__morelink" href="<?php echo esc_attr($atts['url']);?>"><?php echo esc_html($atts['btn_text']);?></a>
			                    	<?php }?>

			                    	<?php
			                    	$image = wp_get_attachment_image_src($atts['img'], 'full');
									if($image){
			                    	?>
			                    	<img class="ps-fullwidth" src="<?php echo esc_attr($image['0']);?>" alt="">
			                    	<?php }?>
			                    </div>
			              	</div>
			            </div>
						<?php
						break;
				}
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand items.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Exist - Banner Masonry Item", 'exist-theme-helpers' ),
	      	"base" => "nouexist_banner_masonry_item",
	      	"class" => "",
	      	"category" => esc_html__( "Exist Theme", 'exist-theme-helpers'),
	      	"content_element" => true,
    		"as_child" => array('only' => 'nouexist_banner_masonry'),
    		"params" => array(
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "heading" => esc_html__( "Type of item show", 'exist-theme-helpers' ),
		            "param_name" => "style",
		            "value" => array(
		            	esc_html__('Style #1', 'exist-theme-helpers') => '1', 
		            	esc_html__('Style #2', 'exist-theme-helpers') => '2',
		            	esc_html__('Style #3', 'exist-theme-helpers') => '3',
		            	esc_html__('Style #4', 'exist-theme-helpers') => '4',
		            	esc_html__('Style #5', 'exist-theme-helpers') => '5',
		            	esc_html__('Style #6', 'exist-theme-helpers') => '6',
		            	esc_html__('Style #7', 'exist-theme-helpers') => '7',
		            	esc_html__('Style #8', 'exist-theme-helpers') => '8',
		            	esc_html__('Style #9', 'exist-theme-helpers') => '9',
		            	esc_html__('Style #10', 'exist-theme-helpers') => '11',
		            	esc_html__('Video Youtube', 'exist-theme-helpers') => '10',
		            ),
		        ),
		        array(
		            "type" => "textarea",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", 'exist-theme-helpers' ),
		            "param_name" => "title",
		        ),

		        array(
		            "type" => "textarea",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Description", 'exist-theme-helpers' ),
		            "param_name" => "desc",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Price", 'exist-theme-helpers' ),
		            "param_name" => "price",
		            'dependency' => array(
						'element' => 'style',
						'value' => array('7'),
					),
		        ),
		        array(
		            "type" => "attach_image",
		            "class" => "",
		            "heading" => esc_html__( "Image", 'exist-theme-helpers' ),
		            "param_name" => "img",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Button text", 'exist-theme-helpers' ),
		            "param_name" => "btn_text",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "URL", 'exist-theme-helpers' ),
		            "param_name" => "url",
		        ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "heading" => esc_html__( "Text align", 'exist-theme-helpers' ),
		            "param_name" => "align",
		            "value" => array(
		            	esc_html__('Default', 'exist-theme-helpers') => '', 
		            	esc_html__('Center', 'exist-theme-helpers') => 'center', 
		            	esc_html__('Left', 'exist-theme-helpers') => 'left', 
		            	esc_html__('Right', 'exist-theme-helpers') => 'right',
		            ),
		            'group' => esc_html__('Style', 'exist-theme-helpers')
		        ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "heading" => esc_html__( "Text position", 'exist-theme-helpers' ),
		            "param_name" => "position",
		            "value" => array(
		            	esc_html__('Default', 'exist-theme-helpers') => '', 
		            	esc_html__('Top', 'exist-theme-helpers') => 'top', 
		            	esc_html__('Bottom', 'exist-theme-helpers') => 'bottom', 
		            ),
		            'group' => esc_html__('Style', 'exist-theme-helpers')
		        ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "heading" => esc_html__( "Size of item show", 'exist-theme-helpers' ),
		            "param_name" => "display",
		            "value" => array(
		            	esc_html__('Default', 'exist-theme-helpers') => '', 
		            	esc_html__('Large', 'exist-theme-helpers') => 'large', 
		            	esc_html__('High', 'exist-theme-helpers') => 'high',
		            	esc_html__('Wide', 'exist-theme-helpers') => 'wide',
		            ),
		            'group' => esc_html__('Style', 'exist-theme-helpers')
		        ),
	      	)
	    ) );
		endif;
	}
}
?>