<?php
/**
* 
*/
class Exist_Theme_Helpers_Shortcode_Products
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		if ( empty( $atts ) ) {
			return '';
		}

		$atts = shortcode_atts( array(
			'title' => '',
			'desc' => '',
			'style' => '',
			'type' => '',
			'ids' => '',
			'cat' => '',
			'number' => '',
			'order_by' => '',
			'col' => '',
			'autoplay' => '',
			'item' => '',
			'lg_col' => '',
			'md_col' => '',
			'sm_col' => '',
			'xs_col' => '',
			'gap' => '',
			'dot' => '',
			'nav' => '',
			'container' => '',
		), $atts, 'nouexist_products' );
		$shortcode_id = uniqid('nouexist_products');
		$type = !empty($atts['type']) ? $atts['type'] : 'recent';
		$style = !empty($atts['style']) ? $atts['style'] : 'grid';
		$number = !empty($atts['number']) ? $atts['number'] : get_option('posts_per_page');
		$col = !empty($atts['col']) ? $atts['col'] : '';

		$item = !empty($atts['lg_col']) ? $atts['lg_col']: '4';
		$lg_col = !empty($atts['lg_col']) ? $atts['lg_col']: '4';
		$md_col = !empty($atts['md_col']) ? $atts['md_col']: '3';
		$sm_col = !empty($atts['sm_col']) ? $atts['sm_col']: '2';
		$xs_col = !empty($atts['xs_col']) ? $atts['xs_col']: '1';
		$gap = !empty($atts['gap']) ? $atts['gap']: '30';
		$nav = !empty($atts['nav']) ? 'true': 'false';
		$dot = !empty($atts['dot']) ? 'true': 'false';
		$autoplay = !empty($atts['autoplay']) ? 'true': 'false';
		$container = !empty($atts['container']) ? $atts['container']: 'container';
	
		$products = self::get_products($atts);
		ob_start();
			if($products->have_posts()):
				
				$shop = nouexist_shop_style();

				if($style == 'slider'){
					?>
					<div class="ps-home11-featured-products">
					    <div class="ps-container-fluid">
					        <div class="ps-section__header text-center">
					          <?php if(!empty($atts['title'])){?>
			                    	<h3 class="ps-heading"><?php echo esc_html($atts['title']);?></h3>
			                    <?php }?>
					          	<?php if(!empty($atts['desc'])){echo wp_kses_post(wpautop($atts['desc']));}?>
					        </div>
					        <div id="slider_<?php echo esc_attr($shortcode_id);?>" class="ps-slider--product-list owl-slider products <?php echo esc_attr(($dot == 'true') ? 'ps-slider--dot-bottom' : '');?>" data-owl-auto="<?php echo esc_attr($autoplay);?>" data-owl-dots="<?php echo esc_attr($dot);?>" data-owl-loop="<?php echo esc_attr($autoplay);?>" data-owl-speed="5000" data-owl-gap="<?php echo esc_attr($gap);?>" data-owl-nav="<?php echo esc_attr($nav);?>" data-owl-dots="true" data-owl-item="<?php echo esc_attr($item);?>" data-owl-item-xs="<?php echo esc_attr($xs_col);?>" data-owl-item-sm="<?php echo esc_attr($sm_col);?>" data-owl-item-md="<?php echo esc_attr($md_col);?>" data-owl-item-lg="<?php echo esc_attr($lg_col);?>" data-owl-duration="1000" data-owl-mousedrag="on">
				            	<?php while($products->have_posts()): $products->the_post();?>
					            	<div <?php post_class('ps-product--1'); ?> data-id="<?php the_ID();?>" data-url="<?php the_permalink();?>" data-title="<?php the_title();?>" data-mh="product-item-<?php echo esc_attr($shortcode_id);?>">
					            		<?php do_action( 'woocommerce_before_shop_loop_item' );?>
						                <div class="ps-product__thumbnail">
						                	<?php woocommerce_show_product_loop_sale_flash();?>
									        <a href="<?php the_permalink();?>">
									            <?php the_post_thumbnail('nouexist_256x326');?>
									        </a>
									          
									        <?php if(!empty($shop['addtocart'])):?>
									            <?php woocommerce_template_loop_add_to_cart();?>
									        <?php endif;?>


									        <?php do_action( 'nouexist_shop_loop_item_social' );?>
						                </div>
						                <div class="ps-product__content">
						                	<?php do_action( 'woocommerce_before_shop_loop_item_title' );?>
									        	<a class="ps-product__title" href="<?php the_permalink();?>"> <?php do_action( 'woocommerce_shop_loop_item_title' );?></a>
									        <?php do_action( 'woocommerce_after_shop_loop_item_title' );?>
        									<?php woocommerce_template_loop_price();?>
						                </div>
						                <?php do_action( 'woocommerce_after_shop_loop_item' );?>
						            </div>
						        <?php endwhile;?>
					        </div>
					    </div>
				    </div>
					<?php
				}elseif($style == 'slider_full'){
					?>
					<div class="ps-section--products-slider_full <?php echo esc_attr(($dot == 'true') ? 'ps-slider--dot-bottom' : '');?>">
					    <div class="<?php echo esc_attr($container);?>">
					        <div id="slider_<?php echo esc_attr($shortcode_id);?>" class="owl-slider" data-owl-auto="<?php echo esc_attr($autoplay);?>" data-owl-loop="<?php echo esc_attr($autoplay);?>" data-owl-speed="5000" data-owl-gap="<?php echo esc_attr($gap);?>" data-owl-nav="<?php echo esc_attr($nav);?>" data-owl-dots="<?php echo esc_attr($dot);?>" data-owl-item="<?php echo esc_attr($item);?>" data-owl-item-xs="<?php echo esc_attr($xs_col);?>" data-owl-item-sm="<?php echo esc_attr($sm_col);?>" data-owl-item-md="<?php echo esc_attr($md_col);?>" data-owl-item-lg="<?php echo esc_attr($lg_col);?>" data-owl-duration="1000" data-owl-mousedrag="on">
				            	<?php while($products->have_posts()): $products->the_post();?>
					            	<div <?php post_class('ps-product--1'); ?> data-id="<?php the_ID();?>" data-url="<?php the_permalink();?>" data-title="<?php the_title();?>" data-mh="product-item-<?php echo esc_attr($shortcode_id);?>">
					            		<?php do_action( 'woocommerce_before_shop_loop_item' );?>
						                <div class="ps-product__thumbnail">
						                	<?php woocommerce_show_product_loop_sale_flash();?>
									        <a href="<?php the_permalink();?>">
									            <?php the_post_thumbnail('nouexist_256x326');?>
									        </a>
									          
									        <?php if(!empty($shop['addtocart'])):?>
									            <?php woocommerce_template_loop_add_to_cart();?>
									        <?php endif;?>


									        <?php do_action( 'nouexist_shop_loop_item_social' );?>
						                </div>
						                <div class="ps-product__content">
						                	<?php do_action( 'woocommerce_before_shop_loop_item_title' );?>
									        	<a class="ps-product__title" href="<?php the_permalink();?>"> <?php do_action( 'woocommerce_shop_loop_item_title' );?></a>
									          <?php do_action( 'woocommerce_after_shop_loop_item_title' );?>
        									<?php woocommerce_template_loop_price();?>
						                </div>
						                <?php do_action( 'woocommerce_after_shop_loop_item' );?>
						            </div>
						        <?php endwhile;?>
					        </div>
					    </div>
				    </div>
					<?php
				}elseif($style == 'masonry'){
					?>
					<div class="nouexist-products ps-section--home-6-features-product woocommerce">
					    <div class="ps-container-fluid">
					        <div class="ps-section__header text-center">
					        	<?php if(!empty($atts['title'])){?>
			                    	<h3 class="ps-heading"><?php echo esc_html($atts['title']);?></h3>
			                    <?php }?>
					          	<?php if(!empty($atts['desc'])){echo wp_kses_post(wpautop($atts['desc']));}?>
					        </div>
					        <div class="masonry-wrapper" data-col-md="4" data-col-sm="3" data-col-xs="1" data-gap="20" data-radio="4:3">
					          <div class="ps-masonry products">
					            <div class="grid-sizer"></div>
					            
					            <?php $i = 0;
					            while($products->have_posts()): $products->the_post();
					            	
					            	$custom_item = '';
									if( $i == '1' ){
										$custom_item = ' large';
									}else{
										if($i != 0 && $i % 10 == 0){
											$custom_item = ' large';
										}
									}
										
					            ?>
					            <div <?php post_class('grid-item '.$custom_item);?> data-id="<?php the_ID();?>" data-url="<?php the_permalink();?>" data-title="<?php the_title();?>">
					            	<?php do_action( 'woocommerce_before_shop_loop_item' );?>
					              	<div class="grid-item__content-wrapper">
					                    <div class="ps-product--metro">
					                      <div class="ps-product__thumbnail">

					                      	<?php woocommerce_show_product_loop_sale_flash();?>

							            	<a href="<?php the_permalink();?>">
									            <?php 
									            if(!empty($custom_item)){
									            	$size = 'nouexist_546x694';
									            }else{
									            	$size = 'nouexist_263x336';
									            }
									            the_post_thumbnail($size);
									            ?>
									        </a>

							            	<?php if(!empty($shop['addtocart'])):?>                    
								              	<?php woocommerce_template_loop_add_to_cart();?>
								          	<?php endif;?>

								            <?php do_action( 'nouexist_shop_loop_item_social' );?>
					                      </div>
					                      <div class="ps-product__content">
					                      		<?php do_action( 'woocommerce_before_shop_loop_item_title' );?>
										        	<a class="ps-product__title" href="<?php the_permalink();?>"> <?php do_action( 'woocommerce_shop_loop_item_title' );?></a>
										        <?php do_action( 'woocommerce_after_shop_loop_item_title' );?>
        										<?php woocommerce_template_loop_price();?>
					                      </div>
					                    </div>
					              	</div>
					              	<?php do_action( 'woocommerce_after_shop_loop_item' );?>
					            </div>
					            <?php $i++;endwhile;?>
					            

					          </div>
					        </div>
					        
					        <?php if ( $products->max_num_pages > 1 ) {?>
					        	<div class="ps-shop__morelink text-center mt-30">
					        		<a 
									  class="ps-btn ps-btn--black btn-loadmore shortcode" 
									  data-nextpage="<?php echo esc_attr(intval(max( 1, get_query_var( 'paged' ) ) + 1));?>" 
									  href="#" 
									  data-maxpage="<?php echo esc_attr($products->max_num_pages);?>"  
									  data-posts="<?php echo esc_attr($products->found_posts);?>"
									  data-col="4"
									  data-shortcode="nouexist_products"
									  data-query="<?php echo esc_attr($type);?>"
									  data-ids="<?php echo esc_attr(!empty($atts['ids']) ? $atts['ids'] : '');?>" 
									  data-cat="<?php echo esc_attr(!empty($atts['cat']) ? $atts['cat'] : '');?>" 
									  data-orderby="<?php echo esc_attr(!empty($atts['order_by']) ? $atts['order_by'] : '');?>" 
									  data-template="products_tmp_<?php echo esc_attr($shortcode_id);?>"  
									  data-shortcodeid="<?php echo esc_attr($shortcode_id);?>" 
									  data-perpage="<?php echo esc_attr($number);?>" 
									  data-style="<?php echo esc_attr($style);?>"><?php esc_html_e('Load more', 'exist-theme-helpers');?></a>
									  <div id="products_tmp_<?php echo esc_attr($shortcode_id);?>" class="hidden"></div>
					        	</div>
				        	<?php }?>
					    </div>
				    </div>
					<?php
				}elseif($style == 'grid_filter'){
					if(empty($col) || isset($_GET['shop_column'])){
						$col = nouexist_get_shop_column();
					}
					
					$categories = nouexist_theme_option('nouexist_woo_archive_heading_cat');
					$shop = nouexist_shop_style();
					$catalog_orderby_options = apply_filters( 'woocommerce_catalog_orderby', array(
							'menu_order' => __( 'Default sorting', 'exist-theme-helpers' ),
							'popularity' => __( 'Sort by popularity', 'exist-theme-helpers' ),
							'rating'     => __( 'Sort by average rating', 'exist-theme-helpers' ),
							'date'       => __( 'Sort by newness', 'exist-theme-helpers' ),
							'price'      => __( 'Sort by price: low to high', 'exist-theme-helpers' ),
							'price-desc' => __( 'Sort by price: high to low', 'exist-theme-helpers' ),
						) );
					$orderby                 = isset( $_GET['orderby'] ) ? wc_clean( wp_unslash( $_GET['orderby'] ) ) : apply_filters( 'woocommerce_default_catalog_orderby', get_option( 'woocommerce_default_catalog_orderby' ) );
					?>
					<div class="ps-section--feature-products-1 woocommerce nouexist-products">
						<div class="ps-container-fluid">
							<div class="ps-section__header text-center">
					          	<?php if(!empty($atts['title'])){?>
			                    	<h3 class="ps-heading"><?php echo esc_html($atts['title']);?></h3>
			                    <?php }?>
					          	<?php if(!empty($atts['desc'])){echo wp_kses_post(wpautop($atts['desc']));}?>
					        </div>
					        <div class="ps-section__content ps-tab-filter">
					        	<div class="ps-filter">
								    <div class="ps-filter__center">
								      <?php 
							            $all_terms = array();
						                while($products->have_posts()){ $products->the_post();
							                $terms = get_the_terms ( get_the_ID(), 'product_cat' );
											foreach ( $terms as $term ) {
											    if(!in_array($term->term_id, $all_terms)){
											    	$all_terms[] = $term->term_id;
											    }
											}
										}
								        if(!empty($all_terms)):
								          $linkall = get_permalink(get_option('woocommerce_shop_page_id'));
								          $active = '';
								          ?>
								          <ul class="ps-filter__categories">
								            <li class="all <?php echo esc_attr(!is_tax() ? 'current' : '');?>">
								              <a href="<?php echo esc_url($linkall);?>"><?php esc_html_e('All', 'exist-theme-helpers');?></a>
								            </li>


								            <?php foreach ($all_terms as $term_id) {
								              $term = get_term( $term_id, 'product_cat' );
								              if($term){
								                $queried_object = get_queried_object();
								                if(is_tax()){
								                  $current_tax = $queried_object->term_id;
								                  if($current_tax == $term->term_id){
								                    $active = 'current';
								                  }else{
								                    $active = '';
								                  }
								                }

								            ?>
								            <li class="product_cat-<?php echo esc_attr($term->slug);?> <?php echo esc_attr($active);?>">
								              <a href="<?php echo esc_url(get_term_link( $term ));?>"><?php echo esc_html($term->name);?></a>
								            </li>
								            <?php }}?>
								          </ul>
								          <?php
								        endif;
								      ?>
								    </div>
								</div>
								<div class="ps-product-grid products" data-items="5">
									<?php while($products->have_posts()): $products->the_post();?>	
										<div <?php post_class('ps-product-column'); ?> data-id="<?php the_ID();?>" data-url="<?php the_permalink();?>" data-title="<?php the_title();?>">
							                  <div class="ps-product--1" data-mh="product-item-<?php echo esc_attr($shortcode_id);?>">
							                  	<?php do_action( 'woocommerce_before_shop_loop_item' );?>
							                    <div class="ps-product__thumbnail">
							                    	<?php woocommerce_show_product_loop_sale_flash();?>
											        <a href="<?php the_permalink();?>">
											            <?php the_post_thumbnail('nouexist_198x254');?>
											        </a>
											          
											        <?php if(!empty($shop['addtocart'])):?>
											            <?php woocommerce_template_loop_add_to_cart();?>
											        <?php endif;?>


											        <?php do_action( 'nouexist_shop_loop_item_social' );?>
							                    </div>
							                    <div class="ps-product__content">
							                    	<?php do_action( 'woocommerce_before_shop_loop_item_title' );?>
										        	<a class="ps-product__title" href="<?php the_permalink();?>"> <?php do_action( 'woocommerce_shop_loop_item_title' );?></a>
										          <?php do_action( 'woocommerce_after_shop_loop_item_title' );?>
        											<?php woocommerce_template_loop_price();?>
							                    </div>
							                    <?php do_action( 'woocommerce_after_shop_loop_item' );?>
							                  </div>
							            </div>
							        <?php endwhile;?> 
								</div>
								<?php if ( $products->max_num_pages > 1 ) {?>
						        	<div class="text-center mt-30">
						        		<a 
										  class="ps-btn ps-btn--black btn-loadmore shortcode" 
										  data-nextpage="<?php echo esc_attr(intval(max( 1, get_query_var( 'paged' ) ) + 1));?>" 
										  href="#" 
										  data-maxpage="<?php echo esc_attr($products->max_num_pages);?>"  
										  data-posts="<?php echo esc_attr($products->found_posts);?>"
										  data-col="4"
										  data-shortcode="nouexist_products"
										  data-query="<?php echo esc_attr($type);?>"
										  data-ids="<?php echo esc_attr(!empty($atts['ids']) ? $atts['ids'] : '');?>" 
										  data-cat="<?php echo esc_attr(!empty($atts['cat']) ? $atts['cat'] : '');?>" 
										  data-orderby="<?php echo esc_attr(!empty($atts['order_by']) ? $atts['order_by'] : '');?>" data-template="products_tmp_<?php echo esc_attr($shortcode_id);?>" 
									  data-shortcodeid="<?php echo esc_attr($shortcode_id);?> 
										  data-perpage="<?php echo esc_attr($number);?>" 
										  data-style="<?php echo esc_attr($style);?>"><?php esc_html_e('Load more', 'exist-theme-helpers');?></a>
									  <div id="products_tmp_<?php echo esc_attr($shortcode_id);?>" class="hidden"></div>
						        	</div>
					        	<?php }?>
					        </div>
						</div>
					</div>
					<?php
				}else{
					?>
					<div class="nouexist-products ps-section--feature-products-1 woocommerce">
					    <div class="ps-container-fluid">
					        <div class="ps-section__header text-center">
					          	<?php if(!empty($atts['title'])){?>
			                    	<h3 class="ps-heading"><?php echo esc_html($atts['title']);?></h3>
			                    <?php }?>
					          	<?php if(!empty($atts['desc'])){echo wp_kses_post(wpautop($atts['desc']));}?>
					        </div>
					        <div class="ps-section__content">
						        <div class="row products">
						            <?php while($products->have_posts()): $products->the_post();?>
						            	<div <?php post_class('col-lg-3 col-md-4 col-sm-6 col-xs-12'); ?> data-id="<?php the_ID();?>" data-url="<?php the_permalink();?>" data-title="<?php the_title();?>">
						                      <div class="ps-product--1" data-mh="product-item-<?php echo esc_attr($shortcode_id);?>">
						                      	<?php do_action( 'woocommerce_before_shop_loop_item' );?>
						                        <div class="ps-product__thumbnail">
						                        	<?php woocommerce_show_product_loop_sale_flash();?>
											        <a href="<?php the_permalink();?>">
											            <?php the_post_thumbnail('nouexist_256x326');?>
											        </a>
											          
											        <?php if(!empty($shop['addtocart'])):?>
											            <?php woocommerce_template_loop_add_to_cart();?>
											        <?php endif;?>


											        <?php do_action( 'nouexist_shop_loop_item_social' );?>
						                        </div>
						                        <div class="ps-product__content">
						                        	<?php do_action( 'woocommerce_before_shop_loop_item_title' );?>
										        	<a class="ps-product__title" href="<?php the_permalink();?>"> <?php do_action( 'woocommerce_shop_loop_item_title' );?></a>
										          <?php do_action( 'woocommerce_after_shop_loop_item_title' );?>
        											<?php woocommerce_template_loop_price();?>
						                        </div>
						                        <?php do_action( 'woocommerce_after_shop_loop_item' );?>
						                      </div>
						                </div>
						            <?php endwhile;?>   
						        </div>

						        <?php if ( $products->max_num_pages > 1 ) {?>
						        	<div class="text-center mt-30">
						        		<a 
										  class="ps-btn ps-btn--black btn-loadmore shortcode" 
										  data-nextpage="<?php echo esc_attr(intval(max( 1, get_query_var( 'paged' ) ) + 1));?>" 
										  href="#" 
										  data-maxpage="<?php echo esc_attr($products->max_num_pages);?>"  
										  data-posts="<?php echo esc_attr($products->found_posts);?>"
										  data-col="4"
										  data-shortcode="nouexist_products"
										  data-query="<?php echo esc_attr($type);?>"
										  data-ids="<?php echo esc_attr(!empty($atts['ids']) ? $atts['ids'] : '');?>" 
										  data-cat="<?php echo esc_attr(!empty($atts['cat']) ? $atts['cat'] : '');?>" 
										  data-orderby="<?php echo esc_attr(!empty($atts['order_by']) ? $atts['order_by'] : '');?>" data-template="products_tmp_<?php echo esc_attr($shortcode_id);?>" 
									  data-shortcodeid="<?php echo esc_attr($shortcode_id);?> 
										  data-perpage="<?php echo esc_attr($number);?>" 
										  data-style="<?php echo esc_attr($style);?>"><?php esc_html_e('Load more', 'exist-theme-helpers');?></a>
									  <div id="products_tmp_<?php echo esc_attr($shortcode_id);?>" class="hidden"></div>
						        	</div>
					        	<?php }?>

					        </div>
					   </div>
					</div>
					<?php
				}

			endif;wp_reset_postdata();
		return ob_get_clean();
		
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		vc_map( array(
	      	"name" => esc_html__( "Exist - Products", 'exist-theme-helpers' ),
	      	"base" => "nouexist_products",
	      	"class" => "",
	      	"category" => esc_html__( "Exist Theme", 'exist-theme-helpers'),
	      	'description' => esc_html__('Products display type Slider or Grid', 'exist-theme-helpers'),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "heading" => esc_html__( "Title", 'exist-theme-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "heading" => esc_html__( "Description", 'exist-theme-helpers' ),
		            "param_name" => "desc",
		        ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "holder" => "div",
		            "heading" => esc_html__( "Type of section show", 'exist-theme-helpers' ),
		            "param_name" => "style",
		            "value" => array(
		            	esc_html__('Grid', 'exist-theme-helpers') => 'grid', 
		            	esc_html__('Grid with filter', 'exist-theme-helpers') => 'grid_filter', 
		            	esc_html__('Slider', 'exist-theme-helpers') => 'slider',
		            	esc_html__('Slider fullwidth', 'exist-theme-helpers') => 'slider_full',
		            	esc_html__('Masonry', 'exist-theme-helpers') => 'masonry',
		            ), 
		            'group' => esc_html__('Display', 'exist-theme-helpers'),
		        ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "heading" => esc_html__( "Type of section show", 'exist-theme-helpers' ),
		            "param_name" => "container",
		            "value" => array(
		            	esc_html__('Container', 'exist-theme-helpers') => 'container', 
		            	esc_html__('Fullwidth', 'exist-theme-helpers') => 'container-fullwidth', 
		            ), 
		            'group' => esc_html__('Display', 'exist-theme-helpers'),
		            'dependency' => array(
						'element' => 'style',
						'value' => array('slider_full'),
					),
		        ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "holder" => "div",
		            "heading" => esc_html__( "Columns of products show", 'exist-theme-helpers' ),
		            "param_name" => "col",
		            "value" => array(
		            	esc_html__('--Select Column--', 'exist-theme-helpers') => '',
		            	esc_html__('3', 'exist-theme-helpers') => '3', 
		            	esc_html__('4', 'exist-theme-helpers') => '4', 
		            	esc_html__('5', 'exist-theme-helpers') => '5', 
		            	esc_html__('6', 'exist-theme-helpers') => '6'), 
		            'group' => esc_html__('Display', 'exist-theme-helpers'),
		        ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "holder" => "div",
		            "heading" => esc_html__( "Type of products show", 'exist-theme-helpers' ),
		            "param_name" => "type",
		            "value" => array(esc_html__('--Select type--', 'exist-theme-helpers') => '', esc_html__('Recent', 'exist-theme-helpers') => 'recent', esc_html__('Featured', 'exist-theme-helpers') => 'featured', esc_html__('Sale', 'exist-theme-helpers') => 'onsale', esc_html__('Best sale', 'exist-theme-helpers') => 'bestsale'), 
		            'group' => esc_html__('Display', 'exist-theme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "IDs posts, EX: 21,22,23", 'exist-theme-helpers' ),
		            "param_name" => "ids",
		            'group' => esc_html__('Display', 'exist-theme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Category ID", 'exist-theme-helpers' ),
		            "param_name" => "cat",
		            'group' => esc_html__('Display', 'exist-theme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Number of posts show(default 8)", 'exist-theme-helpers' ),
		            "param_name" => "number",
		            'group' => esc_html__('Display', 'exist-theme-helpers'),
		        ),
		        array(
		            "type" => "checkbox",
		            "class" => "",
		            "heading" => esc_html__( "Auto play", 'exist-theme-helpers' ),
		            "param_name" => "autoplay",
		            'default' => true,
		            "group" => esc_html__('Attributes', 'exist-theme-helpers'),
		            'dependency' => array(
						'element' => 'style',
						'value' => array('slider', 'slider_full'),
					),
		        ),
		        array(
		            "type" => "checkbox",
		            "class" => "",
		            "heading" => esc_html__( "Display navigation", 'exist-theme-helpers' ),
		            "param_name" => "nav",
		            'default' => true,
		            "group" => esc_html__('Attributes', 'exist-theme-helpers'),
		            'dependency' => array(
						'element' => 'style',
						'value' => array('slider', 'slider_full'),
					),
		        ),
		        array(
		            "type" => "checkbox",
		            "class" => "",
		            "heading" => esc_html__( "Display dot", 'exist-theme-helpers' ),
		            "param_name" => "dot",
		            'default' => true,
		            "group" => esc_html__('Attributes', 'exist-theme-helpers'),
		            'dependency' => array(
						'element' => 'style',
						'value' => array('slider', 'slider_full'),
					),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Number of item show on desktop", 'exist-theme-helpers' ),
		            "param_name" => "item",
		            'default' => '4',
		            "group" => esc_html__('Attributes', 'exist-theme-helpers'),
		            'dependency' => array(
						'element' => 'style',
						'value' => array('slider', 'slider_full'),
					),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Number of item show on phones screen", 'exist-theme-helpers' ),
		            "param_name" => "xs_col",
		            'default' => '1',
		            "group" => esc_html__('Attributes', 'exist-theme-helpers'),
		            'dependency' => array(
						'element' => 'style',
						'value' => array('slider', 'slider_full'),
					),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Number of item show on tablets screen", 'exist-theme-helpers' ),
		            "param_name" => "sm_col",
		            'default' => '2',
		            "group" => esc_html__('Attributes', 'exist-theme-helpers'),
		            'dependency' => array(
						'element' => 'style',
						'value' => array('slider', 'slider_full'),
					),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Number of item show on desktop", 'exist-theme-helpers' ),
		            "param_name" => "md_col",
		            'default' => '3',
		            "group" => esc_html__('Attributes', 'exist-theme-helpers'),
		            'dependency' => array(
						'element' => 'style',
						'value' => array('slider', 'slider_full'),
					),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Number of item show on big desktop", 'exist-theme-helpers' ),
		            "param_name" => "lg_col",
		            'default' => '4',
		            "group" => esc_html__('Attributes', 'exist-theme-helpers'),
		            'dependency' => array(
						'element' => 'style',
						'value' => array('slider', 'slider_full'),
					),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Data Gap", 'exist-theme-helpers' ),
		            "param_name" => "gap",
		            'default' => '30',
		            "group" => esc_html__('Attributes', 'exist-theme-helpers'),
		            'dependency' => array(
						'element' => 'style',
						'value' => array('slider', 'slider_full'),
					),
		        ),
	      	)
	    ) );
	}

	private static function get_products($atts){
		return nouexist_get_products($atts);
	}
}
?>