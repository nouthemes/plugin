<?php
/**
* 
*/
class Exist_Theme_Helpers_Shortcode_Brand
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		$atts = shortcode_atts( array(
		), $atts, 'nouexist_brand' );
		
		ob_start();
			if(!empty($content)):
			?>
			<div class="ps-home8-partner">
			    <div class="container">
			        <div class="owl-slider" data-owl-auto="true" data-owl-loop="true" data-owl-speed="5000" data-owl-gap="30" data-owl-nav="false" data-owl-dots="false" data-owl-item="5" data-owl-item-xs="2" data-owl-item-sm="3" data-owl-item-md="4" data-owl-item-lg="5" data-owl-duration="1000" data-owl-mousedrag="on">
			        	<?php echo do_shortcode($content);?>
			        </div>
			    </div>
		    </div>
			<?php	
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Exist - Brand Carousel", 'exist-theme-helpers' ),
	      	"base" => "nouexist_brand",
	      	"class" => "",
	      	"category" => esc_html__( "Exist Theme", 'exist-theme-helpers'),
	      	"params" => array(),
	      	"as_parent" => array('only' => 'nouexist_brand_item'),
	      	"content_element" => true,
		    "show_settings_on_create" => false,
		    "is_container" => true,
		    "js_view" => 'VcColumnView'
	    ) );
		endif;
	}
}
?>