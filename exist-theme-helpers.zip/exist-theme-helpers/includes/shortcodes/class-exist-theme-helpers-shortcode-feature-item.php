<?php
/**
* 
*/
class Exist_Theme_Helpers_Shortcode_Feature_Item
{
	
	/**
	 * Brand slider item
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts ) {
		$atts = shortcode_atts( array(
			'title' => '',
			'desc' => '',
			'css' => '',
			'attributes' => '',
		), $atts, 'nouexist_feature_item' );
		
		$title = !empty($atts['title']) ? $atts['title'] : '';
		$desc = !empty($atts['desc']) ? $atts['desc'] : '';

		$css = !empty($atts['css']) ? $atts['css'] : '';

		$attributes = !empty($atts['attributes']) ? $atts['attributes'] : '';
		$attributes = str_replace('``', '"', $attributes);

		ob_start(); 
			if(!empty($desc)):
			?>
			<?php if(!empty($css)){echo '<div class="'.esc_attr($css).'">';}?>
				<div class="ps-block--about" <?php echo Exist_Theme_Helpers_Unicode_Replace_Entities::UTF8entities(join(' ', explode(',', $attributes)));?>>
	                <?php if(!empty($title)){?><h3 class="ps-heading"><?php echo esc_html($title);?></h3><?php }?>
	                <?php echo wp_kses_post(wpautop($desc));?>
	            </div>
	        <?php if(!empty($css)){echo '</div>';}?>
			<?php
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand items.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Exist - Feature Item", 'exist-theme-helpers' ),
	      	"base" => "nouexist_feature_item",
	      	"class" => "",
	      	"category" => esc_html__( "Exist Theme", 'exist-theme-helpers'),
	      	"content_element" => true,
    		"as_child" => array('only' => 'nouexist_features'),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", 'exist-theme-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textarea",
		            "class" => "",
		            "heading" => esc_html__( "Description", 'exist-theme-helpers' ),
		            "param_name" => "desc",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Custom class CSS", 'exist-theme-helpers' ),
		            "param_name" => "css",
		            'group' => esc_html__('Attributes', 'exist-theme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Custom attribute", 'exist-theme-helpers' ),
		            'description' => esc_html__('Add custom attribute separated by commas, EX: data-mh="contact-1",data-mh="contact-2"', 'exist-theme-helpers'),
		            "param_name" => "attributes",
		            'group' => esc_html__('Attributes', 'exist-theme-helpers'),
		        ),
	      	)
	    ) );
		endif;
	}
}
?>