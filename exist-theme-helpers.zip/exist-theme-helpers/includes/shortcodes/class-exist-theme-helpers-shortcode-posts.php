<?php
/**
* 
*/
class Exist_Theme_Helpers_Shortcode_Posts
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		if(empty($atts)){
			return '';
		}

		$atts = shortcode_atts( array(
			'title' => '',
			'desc' => '',
			'ids' => '',
			'cat' => '',
			'number' => '',
		), $atts, 'nouexist_posts' );
		
		$per_page = !empty($atts['number']) ? intval($atts['number']) : '3';
		$args = array(
			'post_type' => 'post', 
			'post_status' => 'publish',
			'ignore_sticky_posts' => true,
			'posts_per_page' => $per_page
			);

		if(!empty($atts['ids'])){
			$args['post__in'] = explode(',', $atts['ids']);
		}else{
			if(!empty($atts['cat'])){
				$args['tax_query'] = array(
					array(
						'taxonomy' => 'category',
						'field'    => 'term_id',
						'terms'    => $atts['cat'],
					),
				);
			}
		}

		$query = new WP_Query($args);
		ob_start();
			if($query->have_posts()):

				$link = home_url('/');
				$show_on_front = get_option('show_on_front');
				if($show_on_front == 'page'){
					$link = get_permalink(get_option('page_for_posts'));
				}
				?>
				<div class="ps-home8-blog">
        			<div class="container">
		                <div class="ps-section__header">
		                    <?php if(!empty($atts['title'])){?>
		                    	<h3><?php echo esc_html($atts['title']);?></h3>
		                    <?php }?>
		                    <?php if(!empty($atts['desc'])){?>
		                    	<?php echo wp_kses_post(wpautop($atts['desc']));?>
		                    <?php }?>
		                </div>
	                    <div class="row">
	                        <?php while($query->have_posts()): $query->the_post();?>
		                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
		                            <article id="post-<?php the_ID(); ?>" <?php post_class('ps-post--vertical'); ?>>
									    <?php nouexist_post_thumbnail('nouexist_370x250');?>
									    <div class="ps-post__content">
									      <h4 class="ps-post__title">
									        <?php
									            if ( is_sticky() && is_home() ) :
									              nouexist_sticky_post_icon();
									            endif;
									        ?>
									        <a href="<?php the_permalink();?>"><?php the_title();?></a>
									      </h4>
									      <?php if('gallery' != get_post_format()):?>
									          <?php the_excerpt();?>
									      <?php endif;?>
									      <a class="ps-btn--underline ps-post__morelink" href="<?php the_permalink();?>"><?php esc_html_e('Read more', 'exist-theme-helpers');?></a>
									    </div>
									</article>
		                        </div>
	                        <?php endwhile;?>
	                    </div>
		            </div>
		        </div>
				<?php
			endif;wp_reset_postdata();
		return ob_get_clean();
	}

	/**
	 * Map shortcode Post items.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Exist - Posts", 'exist-theme-helpers' ),
	      	"base" => "nouexist_posts",
	      	"class" => "",
	      	"category" => esc_html__( "Exist Theme", 'exist-theme-helpers'),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", 'exist-theme-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Description", 'exist-theme-helpers' ),
		            "param_name" => "desc",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "IDs posts, EX: 21,22,23", 'exist-theme-helpers' ),
		            "param_name" => "ids",
		            'group' => esc_html__('Display', 'exist-theme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Category ID", 'exist-theme-helpers' ),
		            "param_name" => "cat",
		            'group' => esc_html__('Display', 'exist-theme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Number of posts show(default 3)", 'exist-theme-helpers' ),
		            "param_name" => "number",
		            'group' => esc_html__('Display', 'exist-theme-helpers'),
		        ),
	      	)
	    ) );
		endif;
	}
}
?>