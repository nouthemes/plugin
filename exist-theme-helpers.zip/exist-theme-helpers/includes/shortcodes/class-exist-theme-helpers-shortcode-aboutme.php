<?php
/**
* 
*/
class Exist_Theme_Helpers_Shortcode_Aboutme
{
	
	public static function shortcode($atts, $content = ''){
		$atts = shortcode_atts( array(
			'name' => '',
			'bg' => '',
			'facebook' => '',
			'twitter' => '',
			'instagram' => '',
			'pinterest' => '',
		), $atts, 'nouexist_aboutme' );
		
		$name = !empty($atts['name']) ? $atts['name'] : '';
		$facebook = !empty($atts['facebook']) ? $atts['facebook'] : '';
		$twitter = !empty($atts['twitter']) ? $atts['twitter'] : '';
		$instagram = !empty($atts['instagram']) ? $atts['instagram'] : '';
		$pinterest = !empty($atts['pinterest']) ? $atts['pinterest'] : '';

		$bg = !empty($atts['bg']) ? $atts['bg'] : '';
		$bg_img = '';

		if(!empty($bg)){
			$image = wp_get_attachment_image_src($bg, 'full');
			if($image){
				$bg_img = $image[0];
			}
		}

		
		ob_start(); 
			?>
			<div class="ps-about-me bg--cover" data-background="<?php echo esc_attr($bg_img);?>">
			    <div class="container">
			        <div class="ps-about-me__info">
			          	<h3><?php echo esc_html($name);?></h3>
			        	<?php echo wp_kses_post(wpautop($content));?>
				        <ul class="ps-list--social-2 mt-20">
				            <?php if(!empty($facebook)){?><li><a href="<?php echo esc_url($facebook);?>" target="_blank"><i class="fa fa-facebook"></i></a></li><?php }?>
				            <?php if(!empty($twitter)){?><li><a href="<?php echo esc_url($twitter);?>" target="_blank"><i class="fa fa-twitter"></i></a></li><?php }?>
				            <?php if(!empty($instagram)){?><li><a href="<?php echo esc_url($instagram);?>" target="_blank"><i class="fa fa-instagram"></i></a></li><?php }?>
				            <?php if(!empty($pinterest)){?><li><a href="<?php echo esc_url($pinterest);?>" target="_blank"><i class="fa fa-pinterest"></i></a></li><?php }?>
				        </ul>
			        </div>
			    </div>
		    </div>
			<?php
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Exist - About Me", 'exist-theme-helpers' ),
	      	"base" => "nouexist_aboutme",
	      	"class" => "",
	      	"category" => esc_html__( "Exist Theme", 'exist-theme-helpers'),
    		"params" => array(
		     
		        
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "heading" => esc_html__( "Name", 'exist-theme-helpers' ),
		            "param_name" => "name",
		        ),
		        
		        array(
		            "type" => "attach_image",
		            "class" => "",
		            "heading" => esc_html__( "Avatar", 'exist-theme-helpers' ),
		            "param_name" => "bg",
		        ),
		        
		        array(
		            "type" => "textarea_html",
		            "class" => "",
		            "heading" => esc_html__( "About me", 'exist-theme-helpers' ),
		            "param_name" => "content",
		        ),

		        array(
		            "type" => "textfield",
		            "heading" => esc_html__( "Facebook", 'exist-theme-helpers' ),
		            "param_name" => "facebook",
		            "group" => esc_html__( "Social", 'exist-theme-helpers' ),
		        ),
		        array(
		            "type" => "textfield",
		            "heading" => esc_html__( "Twitter", 'exist-theme-helpers' ),
		            "param_name" => "twitter",
		            "group" => esc_html__( "Social", 'exist-theme-helpers' ),
		        ),
		        array(
		            "type" => "textfield",
		            "heading" => esc_html__( "Istagram", 'exist-theme-helpers' ),
		            "param_name" => "instagram",
		            "group" => esc_html__( "Social", 'exist-theme-helpers' ),
		        ),
		        array(
		            "type" => "textfield",
		            "heading" => esc_html__( "Pinterest", 'exist-theme-helpers' ),
		            "param_name" => "pinterest",
		            "group" => esc_html__( "Social", 'exist-theme-helpers' ),
		        ),
	      	)
	    ) );
		endif;
	}
}
