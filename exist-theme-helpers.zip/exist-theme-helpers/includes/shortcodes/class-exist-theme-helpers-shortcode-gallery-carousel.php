<?php
/**
* 
*/
class Exist_Theme_Helpers_Shortcode_Gallery_Carousel
{
	
	public static function shortcode($atts, $content = ''){
		$atts = shortcode_atts( array(
			'title' => '',
			'ids' => '',
		), $atts, 'nouexist_gallery_carousel' );
		
		$title = !empty($atts['title']) ? $atts['title'] : '';
		$ids = !empty($atts['ids']) ? explode(',', $atts['ids']) : array();
		
		ob_start(); 
			if(!empty($ids)):
			?>
			<div class="ps-about-gallery">
			    <div class="container">
			        <div class="ps-section__header text-center">
			          <?php if(!empty($title)){?><h3 class="ps-heading"><?php echo esc_html($title);?></h3><?php }?>
			        </div>
			        <div class="ps-slider--dot-bottom owl-slider" data-owl-auto="true" data-owl-loop="true" data-owl-speed="5000" data-owl-gap="30" data-owl-nav="false" data-owl-dots="true" data-owl-item="3" data-owl-item-xs="2" data-owl-item-sm="2" data-owl-item-md="3" data-owl-item-lg="3" data-owl-duration="1000" data-owl-mousedrag="on">
			        	<?php 
			        	foreach($ids as $id):
			        		$image = wp_get_attachment_image_src($id, 'nouexist_370x290');
							if($image){
			        		?>
			        		<img src="<?php echo esc_attr($image[0]);?>" alt="">
			        	<?php }endforeach;?>
			        </div>
			    </div>
			</div>
			<?php
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Exist - Galleries Carousel", 'exist-theme-helpers' ),
	      	"base" => "nouexist_gallery_carousel",
	      	"class" => "",
	      	"category" => esc_html__( "Exist Theme", 'exist-theme-helpers'),
    		"params" => array(
		     
		        
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "heading" => esc_html__( "Title", 'exist-theme-helpers' ),
		            "param_name" => "title",
		        ),
		        
		        array(
		            "type" => "attach_images",
		            "class" => "",
		            "heading" => esc_html__( "Galleries", 'exist-theme-helpers' ),
		            "param_name" => "ids",
		        ),
	      	)
	    ) );
		endif;
	}
}
