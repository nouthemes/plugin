<?php
/**
* 
*/
class Exist_Theme_Helpers_Shortcode_Brand_Item
{
	
	/**
	 * Brand slider item
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts ) {
		$atts = shortcode_atts( array(
			'img' => '',
			'url' => '',
		), $atts, 'nouexist_brand_item' );
		
		ob_start();
			if(!empty($atts['img'])):
			?>
			<a href="<?php echo esc_attr($atts['url']);?>" target="_blank">
	           	<?php echo nouexist_helpers_get_image_by_id($atts['img'], 'nouexist_210x104');?>
	        </a>
			<?php
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand items.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Exist - Brand Item", 'exist-theme-helpers' ),
	      	"base" => "nouexist_brand_item",
	      	"class" => "",
	      	"category" => esc_html__( "Exist Theme", 'exist-theme-helpers'),
	      	"content_element" => true,
    		"as_child" => array('only' => 'nouexist_brand'),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", 'exist-theme-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "attach_image",
		            "class" => "",
		            "heading" => esc_html__( "Image", 'exist-theme-helpers' ),
		            "param_name" => "img",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "URL", 'exist-theme-helpers' ),
		            "param_name" => "url",
		        )
	      	)
	    ) );
		endif;
	}
}
?>