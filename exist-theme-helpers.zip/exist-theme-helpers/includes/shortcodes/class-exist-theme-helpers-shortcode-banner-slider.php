<?php
/**
* 
*/
class Exist_Theme_Helpers_Shortcode_Banner_Slider
{
	
	public static function shortcode($atts, $content = ''){
		$atts = shortcode_atts( array(
		), $atts, 'nouexist_banner_slider' );
		
		ob_start(); 
			if(!empty($content)):
			?>
			<div class="ps-slider--dot-left owl-slider" data-owl-auto="true" data-owl-loop="true" data-owl-speed="6000" data-owl-gap="0" data-owl-nav="false" data-owl-dots="true" data-owl-item="1" data-owl-item-xs="1" data-owl-item-sm="1" data-owl-item-md="1" data-owl-item-lg="1" data-owl-duration="1000" data-owl-mousedrag="off" data-owl-animate-in="fadeInUp" data-owl-animate-out="fadeOutDown">
		    	<?php echo do_shortcode($content);?>
		    </div>
			<?php
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Exist - Banner Slider", 'exist-theme-helpers' ),
	      	"base" => "nouexist_banner_slider",
	      	"class" => "",
	      	"category" => esc_html__( "Exist Theme", 'exist-theme-helpers'),
    		"params" => array(),
    		"as_parent" => array('only' => 'nouexist_banner_slider_item'),
	      	"content_element" => true,
		    "show_settings_on_create" => false,
		    "is_container" => true,
		    "js_view" => 'VcColumnView'
	    ) );
		endif;
	}
}
