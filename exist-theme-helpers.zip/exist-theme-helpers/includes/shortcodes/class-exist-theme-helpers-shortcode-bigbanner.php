<?php
/**
* 
*/
class Exist_Theme_Helpers_Shortcode_Bigbanner
{
	
	public static function shortcode($atts, $content = ''){
		$atts = shortcode_atts( array(
			'title1' => '',
			'btn_text1' => '',
			'btn_url1' => '',
			'title2' => '',
			'btn_text2' => '',
			'btn_url2' => '',
			'img' => ''
		), $atts, 'nouexist_bigbanner' );
		
		$title1 = !empty($atts['title1']) ? $atts['title1'] : '';
		$btn_text1 = !empty($atts['btn_text1']) ? $atts['btn_text1'] : '';
		$btn_url1 = !empty($atts['btn_url1']) ? $atts['btn_url1'] : '';

		$title2 = !empty($atts['title2']) ? $atts['title2'] : '';
		$btn_text2 = !empty($atts['btn_text2']) ? $atts['btn_text2'] : '';
		$btn_url2 = !empty($atts['btn_url2']) ? $atts['btn_url2'] : '';

		$img = !empty($atts['img']) ? $atts['img'] : '';

		ob_start(); 
			if(!empty($img)):
			?>
			<div class="ps-section--big-collection">
			    <div class="ps-container-fluid">
			        <div class="ps-collection--big">
			        	<?php echo nouexist_helpers_get_image_by_id($img, 'full');?>
			          	
			          	<?php if(!empty($title1)){?>
				        <div class="ps-collection__content left">
				            <h4><?php echo wp_kses_post($title1);?></h4>
				            <?php if(!empty($btn_text1)){echo '<a class="ps-btn ps-btn--outline" href="'.esc_url($btn_url1).'">'.esc_html($btn_text1).'</a>';}?>
				        </div>
				        <?php }?>

				        <?php if(!empty($title2)){?>
				        <div class="ps-collection__content right">
				            <h4><?php echo wp_kses_post($title2);?></h4>
				            <?php if(!empty($btn_text2)){echo '<a class="ps-btn ps-btn--outline" href="'.esc_url($btn_url2).'">'.esc_html($btn_text2).'</a>';}?>
				        </div>
				        <?php }?>

			        </div>
			    </div>
			</div>
			<?php
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Exist - Big Banner", 'exist-theme-helpers' ),
	      	"base" => "nouexist_bigbanner",
	      	"class" => "",
	      	"category" => esc_html__( "Exist Theme", 'exist-theme-helpers'),
    		"params" => array(
		     
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "heading" => esc_html__( "Title", 'exist-theme-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "attach_image",
		            "class" => "",
		            "heading" => esc_html__( "Image", 'exist-theme-helpers' ),
		            "param_name" => "img",
		        ),

		        array(
		            "type" => "textarea",
		            "holder" => "div",
		            "heading" => esc_html__( "Title", 'exist-theme-helpers' ),
		            "param_name" => "title1",
		            'group' => esc_html__('Block content #1'),
		        ),
		        array(
		            "type" => "textfield",
		            "heading" => esc_html__( "Button text", 'exist-theme-helpers' ),
		            "param_name" => "btn_text1",
		            'group' => esc_html__('Block content #1'),
		        ),
		        array(
		            "type" => "textfield",
		            "heading" => esc_html__( "Button URL", 'exist-theme-helpers' ),
		            "param_name" => "btn_url1",
		            'group' => esc_html__('Block content #1'),
		        ),

		        array(
		            "type" => "textarea",
		            "holder" => "div",
		            "heading" => esc_html__( "Title", 'exist-theme-helpers' ),
		            "param_name" => "title2",
		            'group' => esc_html__('Block content #2'),
		        ),
		        array(
		            "type" => "textfield",
		            "heading" => esc_html__( "Button text", 'exist-theme-helpers' ),
		            "param_name" => "btn_text2",
		            'group' => esc_html__('Block content #2'),
		        ),
		        array(
		            "type" => "textfield",
		            "heading" => esc_html__( "Button URL", 'exist-theme-helpers' ),
		            "param_name" => "btn_url2",
		            'group' => esc_html__('Block content #2'),
		        ),
	      	)
	    ) );
		endif;
	}
}
