<?php 
defined( 'ABSPATH' ) OR exit;

/**
* Class widget about
*
* @author nouthemes [nouthemes@gmail.com] 
* @since 1.0
* @Code Nam
*/

class Exist_Theme_Helpers_Widget_Instagram extends WP_Widget {

	public function __construct() {
		$widget_ops = array(
			'classname' => 'widget_instagram',
			'description' => esc_html__( 'Instagram gallery from account', 'exist-theme-helpers' ),
			'customize_selective_refresh' => true,
		);
		parent::__construct('Exist_Theme_Helpers_Widget_Instagram', esc_html__('* Exist - Instagram gallery', 'exist-theme-helpers'), $widget_ops);
	}

	/**
	 * @param array $args
	 * @param array $instance
	 */
	// Creating widget front-end
	// This is where the action happens
	public function widget( $args, $instance ) {

		$title = ( isset($instance['title']) && !empty($instance['title']) ) ? $instance['title'] : '';
		$account = ( isset($instance['account']) && !empty($instance['account']) ) ? $instance['account'] : '';
		$number = ( isset($instance['number']) && !empty($instance['number']) ) ? $instance['number'] : '6';
		
		if(function_exists('nouexist_scrape_instagram')){
		$data = nouexist_scrape_instagram($account, $number);
			if ( !is_wp_error( $data ) && is_array($data)) {
				echo $args['before_widget'];
					if(!empty($title)){ echo $args['before_title'].$title.$args['after_title']; }
					
					?>
					<ul>
						<?php
						$i = 1;
						foreach ($data as $item) {
							if($i <= $number){
								echo '<li>
										<a href="'.esc_url( $item['link'] ).'" target="_blank">
											<img src="'.esc_attr( $item['url_thumbnail'] ).'" alt="">
										</a>
									</li>';
							}
							$i++;	
						}
						?>
		            </ul>
					<?php
				echo $args['after_widget'];
			}
		}		

	}
		
	// Widget Backend 
	public function form( $instance ) {

		$instance = wp_parse_args( 
			(array) $instance, array(
									 'title' => '', 
									 'account' => '',
									 'number' => '6',
									 ) 
		);
		$title 				= strip_tags($instance['title']);
		$account            = sanitize_text_field( $instance['account'] );
		$number     		= sanitize_text_field( $instance['number'] );
		?>

		<p><label for="<?php echo esc_attr( $this->get_field_id('title') ); ?>"><?php esc_html_e('Title:', 'exist-theme-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('title') ); ?>" name="<?php echo esc_attr( $this->get_field_name('title') ); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>

		
		<p><label for="<?php echo esc_attr( $this->get_field_id('coount') ); ?>"><?php esc_html_e('Instagram account:', 'exist-theme-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('account') ); ?>" name="<?php echo esc_attr( $this->get_field_name('account') ); ?>" type="text" value="<?php echo esc_attr($account); ?>" /></p>

		<p><label for="<?php echo esc_attr( $this->get_field_id('number') ); ?>"><?php esc_html_e('Number of image show:', 'exist-theme-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('number') ); ?>" name="<?php echo esc_attr( $this->get_field_name('number') ); ?>" type="number" value="<?php echo esc_attr($number); ?>" /></p>
		<?php
	}

	
	
	// Updating widget replacing old instances with new
	public function update( $new_instance, $old_instance ) {
		
		$instance = $old_instance;

		$instance['title'] 				= strip_tags($new_instance['title']);
		$instance['account']            = sanitize_text_field( $new_instance['account'] );
		$instance['number']     		= sanitize_text_field( $new_instance['number'] );

		return $instance;
	}

}

?>