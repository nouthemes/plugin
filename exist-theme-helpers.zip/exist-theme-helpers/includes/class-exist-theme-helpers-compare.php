<?php
/**
* Compare class
*
* @package classes
* @author nouthemes [nouthemes@gmail.com]
* @since 1.0
*/
defined( 'ABSPATH' ) OR exit;

class Exist_Theme_Helpers_Compare{

	public static function add( $product_id ){
		if(!self::is_product_in_compare( $product_id )){
			if( !empty($product_id) && intval($product_id) ) {		
				$compare = $_SESSION['nouexist_cp_products'];
				array_push($compare, $product_id);		
				$_SESSION['nouexist_cp_products'] = $compare;
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}

	public static function delete( $product_id ){
		if(self::is_product_in_compare( $product_id )){
			$compare = $_SESSION['nouexist_cp_products'];
		    if(($key = array_search($product_id, $compare)) !== false) {
			    unset($compare[$key]);
			    $_SESSION['nouexist_cp_products'] = $compare;
			    return true;
			}
		}else{
			return false;
		}
	}

	/**
     * Check if the product exists in the compare.
     *
     * @param int $product_id Product id to check
     * @return bool
     * @since 1.0
     */
    public static function is_product_in_compare( $product_id ) {
	    $exists = false;
	    $compare = $_SESSION['nouexist_cp_products'];
	    if( $compare && is_array( $compare ) ) {
		    foreach ( $compare as $item ) {
			    if ( $item == $product_id ) {
				    $exists = true;
			    }
		    }
	    }

	    return apply_filters( 'nouexist_is_product_in_compare', $exists, $product_id );
    }

    public static function get_products_in_compare(){
    	$compare = $_SESSION['nouexist_cp_products'];
    	if(empty($compare)){
    		return array();
    	}

	    return self::format_array(array_unique($compare));
    }

    public static function get_remove_url($product_id){
    	$permalink = get_permalink(exist_helpers_option('nouexist_shop_compare_page_id'));
    	return esc_url(add_query_arg( 'remove_item_compare', $product_id, $permalink ));
    }

    private static function format_array($array){
    	$reset_array_keys = array();
		foreach($array as $value) {
		    $reset_array_keys[] = $value;
		}
		return $reset_array_keys;
    }
	
}
