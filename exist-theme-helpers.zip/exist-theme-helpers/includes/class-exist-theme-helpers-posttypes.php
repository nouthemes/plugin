<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://themeforest.net/user/nouthemes/portfolio
 * @since      1.0.0
 *
 * @package    Exist_Theme_Helpers
 * @subpackage Exist_Theme_Helpers/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Exist_Theme_Helpers
 * @subpackage Exist_Theme_Helpers/admin
 * @author     Noutheme <nouthemes@gmail.com>
 */
class Exist_Theme_Helpers_Posttypes {

	/**
	 * Register core taxonomies.
	 */
	public static function register_taxonomies() {

		do_action( 'nouexist_register_taxonomy' );

		
		register_taxonomy( 'nouexist_portfolio_tag',
			array( 'nouexist_portfolio' ),
			array(
				'hierarchical'          => false,
				'label'                 => __( 'Tags', 'exist-theme-helpers' ),
				'labels'                => array(
						'name'                       => __( 'Tags', 'exist-theme-helpers' ),
						'singular_name'              => __( 'Tag', 'exist-theme-helpers' ),
						'menu_name'                  => _x( 'Tags', 'Admin menu name', 'exist-theme-helpers' ),
						'search_items'               => __( 'Search Tags', 'exist-theme-helpers' ),
						'all_items'                  => __( 'All Tags', 'exist-theme-helpers' ),
						'edit_item'                  => __( 'Edit Tag', 'exist-theme-helpers' ),
						'update_item'                => __( 'Update Tag', 'exist-theme-helpers' ),
						'add_new_item'               => __( 'Add New Tag', 'exist-theme-helpers' ),
						'new_item_name'              => __( 'New Tag Name', 'exist-theme-helpers' ),
						'popular_items'              => __( 'Popular Tags', 'exist-theme-helpers' ),
						'separate_items_with_commas' => __( 'Separate Tags with commas', 'exist-theme-helpers'  ),
						'add_or_remove_items'        => __( 'Add or remove Tags', 'exist-theme-helpers' ),
						'choose_from_most_used'      => __( 'Choose from the most used Tags', 'exist-theme-helpers' ),
						'not_found'                  => __( 'No Tags found', 'exist-theme-helpers' ),
					),
				'show_ui'               => true,
				'query_var'             => true,
				'rewrite'               => array(
					'slug'       => 'portfolio-tag',
					'with_front' => true
				),
			)
		);

		register_taxonomy( 'nouexist_portfolio_cat',
			array( 'nouexist_portfolio' ),
			array(
				'hierarchical'          => true,
				'label'                 => __( 'Categories', 'exist-theme-helpers' ),
				'labels'                => array(
						'name'                       => __( 'Categories', 'exist-theme-helpers' ),
						'singular_name'              => __( 'Category', 'exist-theme-helpers' ),
						'menu_name'                  => _x( 'Categories', 'Admin menu name', 'exist-theme-helpers' ),
						'search_items'               => __( 'Search Categories', 'exist-theme-helpers' ),
						'all_items'                  => __( 'All Categories', 'exist-theme-helpers' ),
						'edit_item'                  => __( 'Edit Category', 'exist-theme-helpers' ),
						'update_item'                => __( 'Update Category', 'exist-theme-helpers' ),
						'add_new_item'               => __( 'Add New Category', 'exist-theme-helpers' ),
						'new_item_name'              => __( 'New Category Name', 'exist-theme-helpers' ),
						'popular_items'              => __( 'Popular Categories', 'exist-theme-helpers' ),
						'separate_items_with_commas' => __( 'Separate Categories with commas', 'exist-theme-helpers'  ),
						'add_or_remove_items'        => __( 'Add or remove Categories', 'exist-theme-helpers' ),
						'choose_from_most_used'      => __( 'Choose from the most used Categories', 'exist-theme-helpers' ),
						'not_found'                  => __( 'No Categories found', 'exist-theme-helpers' ),
					),
				'show_ui'               => true,
				'query_var'             => true,
				'rewrite'               => array(
					'slug'       => 'portfolio-category',
					'with_front' => true
				),
			)
		);

		do_action( 'nouexist_after_register_taxonomy' );
	}

	public static function register_post_types(){
		
		/**
		 * Register course post Tag
		 *
		 * @since 1.0
		 */
		$portfolio_labels = array(

			'name'               => esc_html__( 'Portfolios', 'exist-theme-helpers' ),
			'singular_name'      => esc_html__( 'Portfolios', 'exist-theme-helpers' ),
			'menu_name'          => _x( 'Portfolios', 'Admin menu name', 'exist-theme-helpers' ),
			'add_new'            => esc_html__( 'Add Portfolio', 'exist-theme-helpers' ),
			'add_new_item'       => esc_html__( 'Add Portfolio', 'exist-theme-helpers' ),
			'edit'               => esc_html__( 'Edit Portfolio', 'exist-theme-helpers' ),
			'edit_item'          => esc_html__( 'Edit Portfolio', 'exist-theme-helpers' ),
			'new_item'           => esc_html__( 'Add Portfolio', 'exist-theme-helpers' ),
			'view'               => esc_html__( 'View Portfolio', 'exist-theme-helpers' ),
			'view_item'          => esc_html__( 'View Portfolio', 'exist-theme-helpers' ),
			'search_items'       => esc_html__( 'Search Portfolios', 'exist-theme-helpers' ),
			'not_found'          => esc_html__( 'Portfolios not found', 'exist-theme-helpers' ),
			'not_found_in_trash' => esc_html__( 'Portfolios not found', 'exist-theme-helpers' ),
		);

		$portfolio_args = array(
			'labels'             => $portfolio_labels,
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'hierarchical'       => true,
			'has_archive'		 => false,
			'menu_icon'			 => 'dashicons-feedback',
			'rewrite'               => array(
					'slug'       => 'portfolio',
					'with_front' => true
				),
			'supports'           => array( 'title', 'thumbnail' )
		);
		register_post_type( 'nouexist_portfolio', $portfolio_args );

	}
}
