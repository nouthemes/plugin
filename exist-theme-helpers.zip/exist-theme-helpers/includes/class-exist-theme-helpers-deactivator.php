<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://themeforest.net/user/nouthemes/portfolio
 * @since      1.0.0
 *
 * @package    Exist_Theme_Helpers
 * @subpackage Exist_Theme_Helpers/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Exist_Theme_Helpers
 * @subpackage Exist_Theme_Helpers/includes
 * @author     Noutheme <nouthemes@gmail.com>
 */
class Exist_Theme_Helpers_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
