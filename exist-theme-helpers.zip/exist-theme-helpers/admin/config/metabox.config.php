<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// METABOX OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options      = array();

// -----------------------------------------
// Page Metabox Options                    -
// -----------------------------------------
$options[]    = array(
  'id'        => '_product_video',
  'title'     => esc_html__('Video Youtube Only', 'exist-theme-helpers'),
  'post_type' => 'product',
  'context'   => 'side',
  'priority'  => 'default',
  'sections'  => array(

    array(
      'name'   => 'section_1',
      'fields' => array(
        array(
          'id'            => 'url',
          'title'     => esc_html__('URL', 'exist-theme-helpers'),
          'type'          => 'text',
          'desc'    => esc_html__('EX: https://www.youtube.com/watch?v=4ZighUyrsRU', 'exist-theme-helpers'),
        ),
      ),
    ),

  ),
);

$options[]    = array(
  'id'        => '_portfolio_page',
  'title'     => esc_html__('Portfolio', 'exist-theme-helpers'),
  'post_type' => 'page',
  'context'   => 'side',
  'priority'  => 'default',
  'sections'  => array(

    array(
      'name'   => 'section_1',
      'fields' => array(
        
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Items per page', 'exist-theme-helpers'),
        ),
        array(
          'id'    => 'posts_per_page',
          'type'  => 'number',
        ),
      ),
    ),

  ),
);
$options[]    = array(
  'id'        => 'nouexist_layout_settings',
  'title'     => esc_html__('Settings', 'exist-theme-helpers'),
  'post_type' => 'nouexist_portfolio',
  'context'   => 'normal',
  'priority'  => 'default',
  'sections'  => array(

    array(
      'name'   => 'section_1',
      'icon'  => 'fa fa-briefcase',
      'title' => esc_html__('Information', 'exist-theme-helpers'),
      'fields' => array(
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Logo', 'exist-theme-helpers'),
        ),
        array(
          'id'        => 'logo_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Logo', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Custom logo', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'logo_custom',
          'type'  => 'upload',
          'title' => esc_html__('Upload Custom Logo', 'exist-theme-helpers'),
          'dependency'   => array( 'logo_type', '==', '1' )
        ),
        
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Header', 'exist-theme-helpers'),
        ),
        array(
          'id'        => 'header_style',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Header style', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Style #1', 'exist-theme-helpers'),
            '2' => esc_html__('Style #2', 'exist-theme-helpers'),
            '3' => esc_html__('Style #3', 'exist-theme-helpers'),
            '4' => esc_html__('Style #4', 'exist-theme-helpers'),
            '5' => esc_html__('Style #5', 'exist-theme-helpers'),
            '6' => esc_html__('Style #6', 'exist-theme-helpers'),
            '7' => esc_html__('Style #7', 'exist-theme-helpers'),
            '8' => esc_html__('Style #8', 'exist-theme-helpers'),
            '9' => esc_html__('Style #9', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Layout', 'exist-theme-helpers'),
        ),
        array(
          'id'        => 'layout',
          'type'      => 'image_select',
          'default'   => '',
          'radio'     => true,
          'options'   => array(
            '1'  => NOUEXIZT_IMG. '/layout/portfolio/1.png',//grid
            '2'  => NOUEXIZT_IMG. '/layout/portfolio/2.png',//metro 1
            '3'  => NOUEXIZT_IMG. '/layout/portfolio/3.png',//metro 2
          ),
        ),

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Info', 'exist-theme-helpers'),
        ),
        array(
          'id'    => 'client',
          'type'  => 'text',
          'title' => esc_html__('Client', 'exist-theme-helpers'),
        ),
        array(
          'id'    => 'info',
          'type'  => 'textarea',
          'title' => esc_html__('Project info', 'exist-theme-helpers'),
        ),
        array(
          'id'    => 'desc',
          'type'  => 'textarea',
          'title' => esc_html__('Description', 'exist-theme-helpers'),
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Call to action', 'exist-theme-helpers'),
        ),
        array(
          'id'    => 'btn_text',
          'type'  => 'text',
          'default' => esc_html__('Buy this product', 'exist-theme-helpers'),
          'title' => esc_html__('Button text', 'exist-theme-helpers'),
        ),
        array(
          'id'    => 'btn_url',
          'type'  => 'text',
          'title' => esc_html__('Button URL', 'exist-theme-helpers'),
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Banner', 'exist-theme-helpers'),
          'dependency'   => array( 'layout_2', '==', 'true' ),
        ),
        array(
          'id'    => 'banner',
          'type'  => 'upload',
          'dependency'   => array( 'layout_2', '==', 'true' ),
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Gallery', 'exist-theme-helpers'),
        ),
        array(
          'id'    => 'gallery',
          'type'  => 'gallery',
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Content', 'exist-theme-helpers'),
        ),
        array(
          'id'    => 'content',
          'type'  => 'wysiwyg',
        ),
      ),
    ),
    // begin: a section
    array(
      'name'  => 'footer',
      'title' => esc_html__('Footer', 'exist-theme-helpers'),
      'icon'  => 'fa fa-cog',
      'fields' => array(

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Footer', 'exist-theme-helpers'),
        ),
        array(
          'id'        => 'footer_style',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Footer Layout', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Style #1', 'exist-theme-helpers'),
            '2' => esc_html__('Style #2', 'exist-theme-helpers'),
            '3' => esc_html__('Style #3', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        
        
        
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Footer Top', 'exist-theme-helpers'),
        ),
        array(
          'id'        => 'footer_top',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Display section', 'exist-theme-helpers'),
          'options'   => array(
            '0'     => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Show', 'exist-theme-helpers'),
            '2' => esc_html__('Hide', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer1_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Column of Widget Footer #1', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer2_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Column of Widget Footer #2', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer3_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Column of Widget Footer #3', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer4_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Column of Widget Footer #4', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer5_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Column of Widget Footer #5', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer6_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Column of Widget Footer #6', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),


        array(
          'type'    => 'subheading',
          'content' => esc_html__('Footer Bottom', 'exist-theme-helpers'),
        ),
        array(
          'id'        => 'footer_bottom',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Display section', 'exist-theme-helpers'),
          'options'   => array(
            '0'     => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Show', 'exist-theme-helpers'),
            '2' => esc_html__('Hide', 'exist-theme-helpers'),
          ),
        ),

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Color', 'exist-theme-helpers'),
        ),
        array(
          'id'        => 'footer_bg_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Background color', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Custom', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'footer_bg',
          'type'  => 'color_picker',
          'default' => '',
          'title'     => esc_html__('Background custome color', 'exist-theme-helpers'),
          'dependency'   => array( 'footer_bg_type', '==', '1' ),
        ),
        array(
          'id'        => 'footer_title_color_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Title color', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Custom', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'footer_title_color',
          'type'  => 'color_picker',
          'default' => '',
          'title'     => esc_html__('Title custome color', 'exist-theme-helpers'),
          'dependency'   => array( 'footer_title_color_type', '==', '1' ),
        ),
        array(
          'id'        => 'footer_text_color_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Text color', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Custom', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'footer_text_color',
          'type'  => 'color_picker',
          'default' => '',
          'title'     => esc_html__('Text custome color', 'exist-theme-helpers'),
          'dependency'   => array( 'footer_text_color_type', '==', '1' ),
        ),
        array(
          'id'        => 'footer_text_hover_color_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Text hover color', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Custom', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'footer_text_hover_color',
          'type'  => 'color_picker',
          'default' => '',
          'title'     => esc_html__('Text hover custome color', 'exist-theme-helpers'),
          'dependency'   => array( 'footer_text_hover_color_type', '==', '1' ),
        ),

      ),
    ),
    // end: a section
    // begin: a section
    array(
      'name'  => 'advanced',
      'title' => esc_html__('Advanced', 'exist-theme-helpers'),
      'icon'  => 'fa fa-share-alt',
      'fields' => array(

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Social', 'exist-theme-helpers'),
        ),
        array(
          'id'        => 'facebook',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Facebook share button', 'exist-theme-helpers'),
          'options'   => array(
            '0'     => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Show', 'exist-theme-helpers'),
            '2' => esc_html__('Hide', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'google',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Google+ share button', 'exist-theme-helpers'),
          'options'   => array(
            '0'     => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Show', 'exist-theme-helpers'),
            '2' => esc_html__('Hide', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'twitter',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Twitter share button', 'exist-theme-helpers'),
          'options'   => array(
            '0'     => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Show', 'exist-theme-helpers'),
            '2' => esc_html__('Hide', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'pinterest',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Pinterest share button', 'exist-theme-helpers'),
          'options'   => array(
            '0'     => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Show', 'exist-theme-helpers'),
            '2' => esc_html__('Hide', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'linkedin',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Linkedin share button', 'exist-theme-helpers'),
          'options'   => array(
            '0'     => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Show', 'exist-theme-helpers'),
            '2' => esc_html__('Hide', 'exist-theme-helpers'),
          ),
        ),
        
        

      ),
    ),
    // end: a section

  ),
);

$options[]    = array(
  'id'        => 'nouexist_layout_settings',
  'title'     => esc_html__('Layout Settings', 'exist-theme-helpers'),
  'post_type' => array('page','post'),
  'context'   => 'normal',
  'priority'  => 'default',
  'sections'  => array(

    // begin: a section
    array(
      'name'  => 'general',
      'title' => esc_html__('General', 'exist-theme-helpers'),
      'icon'  => 'fa fa-cog',
      'fields' => array(

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Logo', 'exist-theme-helpers'),
        ),
        array(
          'id'        => 'logo_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Logo', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Custom logo', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'logo_custom',
          'type'  => 'upload',
          'title' => esc_html__('Upload Custom Logo', 'exist-theme-helpers'),
          'dependency'   => array( 'logo_type', '==', '1' )
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Header', 'exist-theme-helpers'),
        ),
        array(
          'id'        => 'header_style',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Header style', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Style #1', 'exist-theme-helpers'),
            '2' => esc_html__('Style #2', 'exist-theme-helpers'),
            '3' => esc_html__('Style #3', 'exist-theme-helpers'),
            '4' => esc_html__('Style #4', 'exist-theme-helpers'),
            '5' => esc_html__('Style #5', 'exist-theme-helpers'),
            '6' => esc_html__('Style #6', 'exist-theme-helpers'),
            '7' => esc_html__('Style #7', 'exist-theme-helpers'),
            '8' => esc_html__('Style #8', 'exist-theme-helpers'),
            '9' => esc_html__('Style #9', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Banner Heading', 'exist-theme-helpers'),
        ),
        array(
          'id'        => 'banner_heading_enable',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Enable Banner Heading', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Show', 'exist-theme-helpers'),
            '2' => esc_html__('Hide', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'        => 'banner_heading_style',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Banner Heading Style', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Fullwidth', 'exist-theme-helpers'),
            '2' => esc_html__('Normal', 'exist-theme-helpers'),
          ),
          'default' => '0',
          'dependency'   => array( 'banner_heading_enable', '==', '1' )
        ),
        array(
          'id'    => 'banner_heading',
          'type'  => 'upload',
          'title' => esc_html__('Upload Banner', 'exist-theme-helpers'),
          'dependency'   => array( 'banner_heading_enable', '==', '1' )
        ),

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Single thumbnail image', 'exist-theme-helpers'),
        ),
        array(
          'id'        => 'single_thumbnail',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Enable Thumbnail', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Show', 'exist-theme-helpers'),
            '2' => esc_html__('Hide', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        
      
      ),
    ),
    // end: a section

    // begin: a section
    array(
      'name'  => 'sidebar',
      'title' => esc_html__('Sidebar', 'exist-theme-helpers'),
      'icon'  => 'fa fa-tint',
      'fields' => array(

        array(
          'id'        => 'sidebar',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Sidebar style', 'exist-theme-helpers'),
          'options'   => array(
            '0'     => esc_html__('Default', 'exist-theme-helpers'),
            'right' => esc_html__('Right', 'exist-theme-helpers'),
            'left' => esc_html__('Left', 'exist-theme-helpers'),
            'hide' => esc_html__('No sidebar', 'exist-theme-helpers'),
          ),
        ),

        

      ),
    ),
    // end: a section
    // begin: a section
    array(
      'name'  => 'footer',
      'title' => esc_html__('Footer', 'exist-theme-helpers'),
      'icon'  => 'fa fa-cog',
      'fields' => array(

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Footer', 'exist-theme-helpers'),
        ),
        array(
          'id'        => 'footer_style',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Footer Layout', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Style #1', 'exist-theme-helpers'),
            '2' => esc_html__('Style #2', 'exist-theme-helpers'),
            '3' => esc_html__('Style #3', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        
        
        
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Footer Top', 'exist-theme-helpers'),
        ),
        array(
          'id'        => 'footer_top',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Display section', 'exist-theme-helpers'),
          'options'   => array(
            '0'     => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Show', 'exist-theme-helpers'),
            '2' => esc_html__('Hide', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer1_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Column of Widget Footer #1', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer2_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Column of Widget Footer #2', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer3_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Column of Widget Footer #3', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer4_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Column of Widget Footer #4', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer5_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Column of Widget Footer #5', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer6_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Column of Widget Footer #6', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),


        array(
          'type'    => 'subheading',
          'content' => esc_html__('Footer Bottom', 'exist-theme-helpers'),
        ),
        array(
          'id'        => 'footer_bottom',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Display section', 'exist-theme-helpers'),
          'options'   => array(
            '0'     => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Show', 'exist-theme-helpers'),
            '2' => esc_html__('Hide', 'exist-theme-helpers'),
          ),
        ),

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Color', 'exist-theme-helpers'),
        ),
        array(
          'id'        => 'footer_bg_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Background color', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Custom', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'footer_bg',
          'type'  => 'color_picker',
          'default' => '',
          'title'     => esc_html__('Background custome color', 'exist-theme-helpers'),
          'dependency'   => array( 'footer_bg_type', '==', '1' ),
        ),
        array(
          'id'        => 'footer_title_color_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Title color', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Custom', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'footer_title_color',
          'type'  => 'color_picker',
          'default' => '',
          'title'     => esc_html__('Title custome color', 'exist-theme-helpers'),
          'dependency'   => array( 'footer_title_color_type', '==', '1' ),
        ),
        array(
          'id'        => 'footer_text_color_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Text color', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Custom', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'footer_text_color',
          'type'  => 'color_picker',
          'default' => '',
          'title'     => esc_html__('Text custome color', 'exist-theme-helpers'),
          'dependency'   => array( 'footer_text_color_type', '==', '1' ),
        ),
        array(
          'id'        => 'footer_text_hover_color_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Text hover color', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Custom', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'footer_text_hover_color',
          'type'  => 'color_picker',
          'default' => '',
          'title'     => esc_html__('Text hover custome color', 'exist-theme-helpers'),
          'dependency'   => array( 'footer_text_hover_color_type', '==', '1' ),
        ),

      ),
    ),
    // end: a section

  ),
);

$options[]    = array(
  'id'        => '_exist_creative_content',
  'title'     => esc_html__('Creative content', 'exist-theme-helpers'),
  'post_type' => 'product',
  'context'   => 'normal',
  'priority'  => 'default',
  'sections'  => array(

    array(
      'name'   => 'section_creative_content',
      'fields' => array(
        array(
          'id'            => 'creative_content',
          'type'          => 'wysiwyg',
        ),
      ),
    ),

  ),
);
$options[]    = array(
  'id'        => 'nouexist_layout_settings',
  'title'     => esc_html__('Single Settings', 'exist-theme-helpers'),
  'post_type' => array('product'),
  'context'   => 'normal',
  'priority'  => 'default',
  'sections'  => array(

    // begin: a section
    array(
      'name'  => 'sidebar',
      'title' => esc_html__('General', 'exist-theme-helpers'),
      'icon'  => 'fa fa-tint',
      'fields' => array(

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Logo', 'exist-theme-helpers'),
        ),
        array(
          'id'        => 'logo_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Logo', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Custom logo', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'logo_custom',
          'type'  => 'upload',
          'title' => esc_html__('Upload Custom Logo', 'exist-theme-helpers'),
          'dependency'   => array( 'logo_type', '==', '1' )
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Header', 'exist-theme-helpers'),
        ),
        array(
          'id'        => 'header_style',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Header style', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Style #1', 'exist-theme-helpers'),
            '2' => esc_html__('Style #2', 'exist-theme-helpers'),
            '3' => esc_html__('Style #3', 'exist-theme-helpers'),
            '4' => esc_html__('Style #4', 'exist-theme-helpers'),
            '5' => esc_html__('Style #5', 'exist-theme-helpers'),
            '6' => esc_html__('Style #6', 'exist-theme-helpers'),
            '7' => esc_html__('Style #7', 'exist-theme-helpers'),
            '8' => esc_html__('Style #8', 'exist-theme-helpers'),
            '9' => esc_html__('Style #9', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Sidebar', 'exist-theme-helpers'),
        ),
        array(
          'id'        => 'sidebar',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Sidebar', 'exist-theme-helpers'),
          'options'   => array(
            '0'     => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Show sidebar', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide sidebar', 'exist-theme-helpers'),
          ),
        ),

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Gallery', 'exist-theme-helpers'),
        ),
        array(
          'id'        => 'gallery_type',
          'type'      => 'select',
          'default'   => '',
          'title'     => esc_html__('Gallery style', 'exist-theme-helpers'),
          'radio'     => true,
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Style #1', 'exist-theme-helpers'),
            '2' => esc_html__('Style #2', 'exist-theme-helpers'),
            '3' => esc_html__('Style #3', 'exist-theme-helpers'),
            '4' => esc_html__('Style #4', 'exist-theme-helpers'),
            '5' => esc_html__('Style #5', 'exist-theme-helpers'),
            '6' => esc_html__('Style #6', 'exist-theme-helpers'),
            '7' => esc_html__('Style #7', 'exist-theme-helpers'),
            '8' => esc_html__('Style #8', 'exist-theme-helpers'),
          ),
          'class' => 'chosen'
        ),
        array(
          'id'        => 'sticky_gallery',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Sticky gallery', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('On', 'exist-theme-helpers'),
            '2' => esc_html__('Off', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Content', 'exist-theme-helpers'),
        ),
        array(
          'id'        => 'tab_position',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Tab content style', 'exist-theme-helpers'),
          'options'   => array(
            '0'     => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Fullwidth', 'exist-theme-helpers'),
            '2' => esc_html__('Left', 'exist-theme-helpers'),
            '3' => esc_html__('Right', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'sticky_info',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Sticky content', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('On', 'exist-theme-helpers'),
            '2' => esc_html__('Off', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
      ),
    ),
    // end: a section
    // begin: a section
    array(
      'name'  => 'layout_col',
      'title' => esc_html__('Layout columns', 'exist-theme-helpers'),
      'icon'  => 'fa fa-cog',
      'fields' => array(

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Layout', 'exist-theme-helpers'),
        ),
        array(
          'id'        => 'content1_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Column of Gallery', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
          'default' => 6
        ),
        array(
          'id'        => 'content2_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Column of content', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
          'default' => 6
        ),
        array(
          'id'        => 'content3_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Column of sidebar', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        

      ),
    ),
    // end: a section
    // begin: a section
    array(
      'name'  => 'bottom',
      'title' => esc_html__('Related products', 'exist-theme-helpers'),
      'icon'  => 'fa fa-link',
      'fields' => array(

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Related products', 'exist-theme-helpers'),
        ),
        array(
          'id'        => 'product_related_type',
          'type'      => 'select',
          'title'     => esc_html__('Related type', 'exist-theme-helpers'),
          'class'     => 'chosen',
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            'related' => esc_html__('Related products', 'exist-theme-helpers'),
            'bestsale' => esc_html__('Best seller', 'exist-theme-helpers'),
            'featured' => esc_html__('Featured products', 'exist-theme-helpers'),
            'sale' => esc_html__('On sale', 'exist-theme-helpers'),
          ),
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Description', 'exist-theme-helpers'),
        ),
        array(
          'id'      => 'shop_related_desc',
          'type'    => 'text',
          'title'   => esc_html__('Description', 'exist-theme-helpers'),
        ),
        array(
          'id'      => 'shop_related_title',
          'type'    => 'text',
          'title'   => esc_html__('Title', 'exist-theme-helpers'),
        ),
      
      ),
    ),
    // end: a section
    // begin: a section
    array(
      'name'  => 'footer',
      'title' => esc_html__('Footer', 'exist-theme-helpers'),
      'icon'  => 'fa fa-cog',
      'fields' => array(

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Layout', 'exist-theme-helpers'),
        ),
        array(
          'id'        => 'footer_style',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Footer Layout', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Style #1', 'exist-theme-helpers'),
            '2' => esc_html__('Style #2', 'exist-theme-helpers'),
            '3' => esc_html__('Style #3', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Footer Top', 'exist-theme-helpers'),
        ),
        array(
          'id'        => 'footer_top',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Display section', 'exist-theme-helpers'),
          'options'   => array(
            '0'     => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Show', 'exist-theme-helpers'),
            '2' => esc_html__('Hide', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer1_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Column of Widget Footer #1', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer2_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Column of Widget Footer #2', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer3_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Column of Widget Footer #3', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer4_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Column of Widget Footer #4', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer5_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Column of Widget Footer #5', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer6_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Column of Widget Footer #6', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),


        array(
          'type'    => 'subheading',
          'content' => esc_html__('Footer Bottom', 'exist-theme-helpers'),
        ),
        array(
          'id'        => 'footer_bottom',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Display section', 'exist-theme-helpers'),
          'options'   => array(
            '0'     => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Show', 'exist-theme-helpers'),
            '2' => esc_html__('Hide', 'exist-theme-helpers'),
          ),
        ),

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Color', 'exist-theme-helpers'),
        ),
        array(
          'id'        => 'footer_bg_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Background color', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Custom', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'footer_bg',
          'type'  => 'color_picker',
          'default' => '',
          'title'     => esc_html__('Background custome color', 'exist-theme-helpers'),
          'dependency'   => array( 'footer_bg_type', '==', '1' ),
        ),
        array(
          'id'        => 'footer_title_color_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Title color', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Custom', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'footer_title_color',
          'type'  => 'color_picker',
          'default' => '',
          'title'     => esc_html__('Title custome color', 'exist-theme-helpers'),
          'dependency'   => array( 'footer_title_color_type', '==', '1' ),
        ),
        array(
          'id'        => 'footer_text_color_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Text color', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Custom', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'footer_text_color',
          'type'  => 'color_picker',
          'default' => '',
          'title'     => esc_html__('Text custome color', 'exist-theme-helpers'),
          'dependency'   => array( 'footer_text_color_type', '==', '1' ),
        ),
        array(
          'id'        => 'footer_text_hover_color_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Text hover color', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Custom', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'footer_text_hover_color',
          'type'  => 'color_picker',
          'default' => '',
          'title'     => esc_html__('Text hover custome color', 'exist-theme-helpers'),
          'dependency'   => array( 'footer_text_hover_color_type', '==', '1' ),
        ),
        

      ),
    ),
    // end: a section
    // begin: a section
    array(
      'name'  => 'advanced',
      'title' => esc_html__('Advanced', 'exist-theme-helpers'),
      'icon'  => 'fa fa-share-alt',
      'fields' => array(

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Social', 'exist-theme-helpers'),
        ),
        array(
          'id'        => 'facebook',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Facebook share button', 'exist-theme-helpers'),
          'options'   => array(
            '0'     => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Show', 'exist-theme-helpers'),
            '2' => esc_html__('Hide', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'google',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Google+ share button', 'exist-theme-helpers'),
          'options'   => array(
            '0'     => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Show', 'exist-theme-helpers'),
            '2' => esc_html__('Hide', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'twitter',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Twitter share button', 'exist-theme-helpers'),
          'options'   => array(
            '0'     => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Show', 'exist-theme-helpers'),
            '2' => esc_html__('Hide', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'pinterest',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Pinterest share button', 'exist-theme-helpers'),
          'options'   => array(
            '0'     => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Show', 'exist-theme-helpers'),
            '2' => esc_html__('Hide', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'linkedin',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Linkedin share button', 'exist-theme-helpers'),
          'options'   => array(
            '0'     => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Show', 'exist-theme-helpers'),
            '2' => esc_html__('Hide', 'exist-theme-helpers'),
          ),
        ),
        
        

      ),
    ),
    // end: a section



  ),
);

Exist_Helpers_CSFramework_Metabox::instance( $options );
