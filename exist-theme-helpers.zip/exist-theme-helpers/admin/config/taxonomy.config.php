<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// TAXONOMY OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options     = array();

// -----------------------------------------
// Taxonomy Options                        -
// -----------------------------------------
$options[]   = array(
  'id'       => 'nouexist_layout_settings',
  'taxonomy' => 'post_tag', // category, post_tag or your custom taxonomy name
  'fields'   => array(

    array(
      'type'    => 'subheading',
      'content' => esc_html__('Logo', 'exist-theme-helpers'),
    ),
    array(
      'id'        => 'logo_type',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Logo', 'exist-theme-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'exist-theme-helpers'),
        '1' => esc_html__('Custom logo', 'exist-theme-helpers'),
      ),
      'default' => '0'
    ),
    array(
      'id'    => 'logo_custom',
      'type'  => 'upload',
      'title' => esc_html__('Upload Custom Logo', 'exist-theme-helpers'),
      'dependency'   => array( 'logo_type', '==', '1' )
    ),
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Heading', 'exist-theme-helpers'),
    ),
    array(
      'id'        => 'header_style',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Header style', 'exist-theme-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'exist-theme-helpers'),
        '1' => esc_html__('Style #1', 'exist-theme-helpers'),
        '2' => esc_html__('Style #2', 'exist-theme-helpers'),
        '3' => esc_html__('Style #3', 'exist-theme-helpers'),
        '4' => esc_html__('Style #4', 'exist-theme-helpers'),
        '5' => esc_html__('Style #5', 'exist-theme-helpers'),
        '6' => esc_html__('Style #6', 'exist-theme-helpers'),
        '7' => esc_html__('Style #7', 'exist-theme-helpers'),
        '8' => esc_html__('Style #8', 'exist-theme-helpers'),
        '9' => esc_html__('Style #9', 'exist-theme-helpers'),
      ),
      'default' => '0'
    ),
    array(
      'id'        => 'banner_heading_enable',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Enable Banner Heading', 'exist-theme-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'exist-theme-helpers'),
        '1' => esc_html__('Show', 'exist-theme-helpers'),
        '2' => esc_html__('Hide', 'exist-theme-helpers'),
      ),
      'default' => '0'
    ),

    array(
      'id'    => 'banner_heading',
      'type'  => 'upload',
      'title' => esc_html__('Banner heading', 'exist-theme-helpers'),
      'dependency'   => array( 'banner_heading_enable', '==', '1' )
    ),

    array(
      'id'    => 'banner_heading_style',
      'type'  => 'select',
      'title' => esc_html__('Banner heading style', 'exist-theme-helpers'),
      'options' => array(
        ''      => esc_html__('Default', 'exist-theme-helpers'),
        '1'     => esc_html__('Fullwidth', 'exist-theme-helpers'),
        '2'     => esc_html__('Normal', 'exist-theme-helpers'),
      ),
      'dependency'   => array( 'banner_heading_enable', '==', '1' )
    ),
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Footer', 'exist-theme-helpers'),
    ),
    array(
      'id'        => 'footer_style',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Footer Layout', 'exist-theme-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'exist-theme-helpers'),
        '1' => esc_html__('Style #1', 'exist-theme-helpers'),
        '2' => esc_html__('Style #2', 'exist-theme-helpers'),
        '3' => esc_html__('Style #3', 'exist-theme-helpers'),
      ),
      'default' => '0'
    ),
    array(
          'id'        => 'footer1_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Column of Widget Footer #1', 'exist-theme-helpers'),
          'default' => 'default',
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer2_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'default' => 'default',
          'title'     => esc_html__('Column of Widget Footer #2', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer3_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'default' => 'default',
          'title'     => esc_html__('Column of Widget Footer #3', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer4_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'default' => 'default',
          'title'     => esc_html__('Column of Widget Footer #4', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer5_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'default' => 'default',
          'title'     => esc_html__('Column of Widget Footer #5', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer6_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'default' => 'default',
          'title'     => esc_html__('Column of Widget Footer #6', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Footer Color', 'exist-theme-helpers'),
        ),
        array(
          'id'        => 'footer_bg_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Background color', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Custom', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'footer_bg',
          'type'  => 'color_picker',
          'default' => '',
          'title'     => esc_html__('Background custome color', 'exist-theme-helpers'),
          'dependency'   => array( 'footer_bg_type', '==', '1' ),
        ),
        array(
          'id'        => 'footer_title_color_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Title color', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Custom', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'footer_title_color',
          'type'  => 'color_picker',
          'default' => '',
          'title'     => esc_html__('Title custome color', 'exist-theme-helpers'),
          'dependency'   => array( 'footer_title_color_type', '==', '1' ),
        ),
        array(
          'id'        => 'footer_text_color_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Text color', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Custom', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'footer_text_color',
          'type'  => 'color_picker',
          'default' => '',
          'title'     => esc_html__('Text custome color', 'exist-theme-helpers'),
          'dependency'   => array( 'footer_text_color_type', '==', '1' ),
        ),
        array(
          'id'        => 'footer_text_hover_color_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Text hover color', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Custom', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'footer_text_hover_color',
          'type'  => 'color_picker',
          'default' => '',
          'title'     => esc_html__('Text hover custome color', 'exist-theme-helpers'),
          'dependency'   => array( 'footer_text_hover_color_type', '==', '1' ),
        ),

  ),
);
$options[]   = array(
  'id'       => 'nouexist_layout_settings',
  'taxonomy' => 'category', // category, post_tag or your custom taxonomy name
  'fields'   => array(

    array(
      'type'    => 'subheading',
      'content' => esc_html__('Logo', 'exist-theme-helpers'),
    ),
    array(
      'id'        => 'logo_type',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Logo', 'exist-theme-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'exist-theme-helpers'),
        '1' => esc_html__('Custom logo', 'exist-theme-helpers'),
      ),
      'default' => '0'
    ),
    array(
      'id'    => 'logo_custom',
      'type'  => 'upload',
      'title' => esc_html__('Upload Custom Logo', 'exist-theme-helpers'),
      'dependency'   => array( 'logo_type', '==', '1' )
    ),
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Heading', 'exist-theme-helpers'),
    ),
    array(
      'id'        => 'header_style',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Header style', 'exist-theme-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'exist-theme-helpers'),
        '1' => esc_html__('Style #1', 'exist-theme-helpers'),
        '2' => esc_html__('Style #2', 'exist-theme-helpers'),
        '3' => esc_html__('Style #3', 'exist-theme-helpers'),
        '4' => esc_html__('Style #4', 'exist-theme-helpers'),
        '5' => esc_html__('Style #5', 'exist-theme-helpers'),
        '6' => esc_html__('Style #6', 'exist-theme-helpers'),
        '7' => esc_html__('Style #7', 'exist-theme-helpers'),
        '8' => esc_html__('Style #8', 'exist-theme-helpers'),
        '9' => esc_html__('Style #9', 'exist-theme-helpers'),
      ),
      'default' => '0'
    ),
    array(
      'id'        => 'banner_heading_enable',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Enable Banner Heading', 'exist-theme-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'exist-theme-helpers'),
        '1' => esc_html__('Show', 'exist-theme-helpers'),
        '2' => esc_html__('Hide', 'exist-theme-helpers'),
      ),
      'default' => '0'
    ),

    array(
      'id'    => 'banner_heading',
      'type'  => 'upload',
      'title' => esc_html__('Banner heading', 'exist-theme-helpers'),
      'dependency'   => array( 'banner_heading_enable', '==', '1' )
    ),

    array(
      'id'    => 'banner_heading_style',
      'type'  => 'select',
      'title' => esc_html__('Banner heading style', 'exist-theme-helpers'),
      'options' => array(
        ''      => esc_html__('Default', 'exist-theme-helpers'),
        '1'     => esc_html__('Fullwidth', 'exist-theme-helpers'),
        '2'     => esc_html__('Normal', 'exist-theme-helpers'),
      ),
      'dependency'   => array( 'banner_heading_enable', '==', '1' )
    ),
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Footer', 'exist-theme-helpers'),
    ),
    array(
      'id'        => 'footer_style',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Footer Layout', 'exist-theme-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'exist-theme-helpers'),
        '1' => esc_html__('Style #1', 'exist-theme-helpers'),
        '2' => esc_html__('Style #2', 'exist-theme-helpers'),
        '3' => esc_html__('Style #3', 'exist-theme-helpers'),
      ),
      'default' => '0'
    ),
    array(
          'id'        => 'footer1_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Column of Widget Footer #1', 'exist-theme-helpers'),
          'default' => 'default',
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer2_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'default' => 'default',
          'title'     => esc_html__('Column of Widget Footer #2', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer3_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'default' => 'default',
          'title'     => esc_html__('Column of Widget Footer #3', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer4_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'default' => 'default',
          'title'     => esc_html__('Column of Widget Footer #4', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer5_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'default' => 'default',
          'title'     => esc_html__('Column of Widget Footer #5', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer6_col',
          'type'      => 'select',
          'class'     => 'chosen',
          'default' => 'default',
          'title'     => esc_html__('Column of Widget Footer #6', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Footer Color', 'exist-theme-helpers'),
        ),
        array(
          'id'        => 'footer_bg_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Background color', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Custom', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'footer_bg',
          'type'  => 'color_picker',
          'default' => '',
          'title'     => esc_html__('Background custome color', 'exist-theme-helpers'),
          'dependency'   => array( 'footer_bg_type', '==', '1' ),
        ),
        array(
          'id'        => 'footer_title_color_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Title color', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Custom', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'footer_title_color',
          'type'  => 'color_picker',
          'default' => '',
          'title'     => esc_html__('Title custome color', 'exist-theme-helpers'),
          'dependency'   => array( 'footer_title_color_type', '==', '1' ),
        ),
        array(
          'id'        => 'footer_text_color_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Text color', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Custom', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'footer_text_color',
          'type'  => 'color_picker',
          'default' => '',
          'title'     => esc_html__('Text custome color', 'exist-theme-helpers'),
          'dependency'   => array( 'footer_text_color_type', '==', '1' ),
        ),
        array(
          'id'        => 'footer_text_hover_color_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Text hover color', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Custom', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'footer_text_hover_color',
          'type'  => 'color_picker',
          'default' => '',
          'title'     => esc_html__('Text hover custome color', 'exist-theme-helpers'),
          'dependency'   => array( 'footer_text_hover_color_type', '==', '1' ),
        ),

  ),
);

$options[]   = array(
  'id'       => 'nouexist_layout_settings',
  'taxonomy' => 'product_cat', // category, post_tag or your custom taxonomy name
  'fields'   => array(

    array(
      'type'    => 'subheading',
      'content' => esc_html__('Logo', 'exist-theme-helpers'),
    ),
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Logo', 'exist-theme-helpers'),
    ),
    array(
      'id'        => 'logo_type',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Logo', 'exist-theme-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'exist-theme-helpers'),
        '1' => esc_html__('Custom logo', 'exist-theme-helpers'),
      ),
      'default' => '0'
    ),
    array(
      'id'    => 'logo_custom',
      'type'  => 'upload',
      'title' => esc_html__('Upload Custom Logo', 'exist-theme-helpers'),
      'dependency'   => array( 'logo_type', '==', '1' )
    ),
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Heading', 'exist-theme-helpers'),
    ),
    array(
      'id'        => 'header_style',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Header style', 'exist-theme-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'exist-theme-helpers'),
        '1' => esc_html__('Style #1', 'exist-theme-helpers'),
        '2' => esc_html__('Style #2', 'exist-theme-helpers'),
        '3' => esc_html__('Style #3', 'exist-theme-helpers'),
        '4' => esc_html__('Style #4', 'exist-theme-helpers'),
        '5' => esc_html__('Style #5', 'exist-theme-helpers'),
        '6' => esc_html__('Style #6', 'exist-theme-helpers'),
        '7' => esc_html__('Style #7', 'exist-theme-helpers'),
        '8' => esc_html__('Style #8', 'exist-theme-helpers'),
        '9' => esc_html__('Style #9', 'exist-theme-helpers'),
      ),
      'default' => '0'
    ),
    array(
      'id'        => 'banner_heading_enable',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Enable Banner Heading', 'exist-theme-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'exist-theme-helpers'),
        '1' => esc_html__('Show', 'exist-theme-helpers'),
        '2' => esc_html__('Hide', 'exist-theme-helpers'),
      ),
      'default' => '0'
    ),

    array(
      'id'    => 'banner_heading',
      'type'  => 'upload',
      'title' => esc_html__('Banner heading', 'exist-theme-helpers'),
      'dependency'   => array( 'banner_heading_enable', '==', '1' )
    ),

    array(
      'id'    => 'banner_heading_style',
      'type'  => 'select',
      'title' => esc_html__('Banner heading style', 'exist-theme-helpers'),
      'options' => array(
        ''      => esc_html__('Default', 'exist-theme-helpers'),
        '1'     => esc_html__('Fullwidth', 'exist-theme-helpers'),
        '2'     => esc_html__('Normal', 'exist-theme-helpers'),
      ),
      'dependency'   => array( 'banner_heading_enable', '==', '1' )
    ),

    array(
      'type'    => 'subheading',
      'content' => esc_html__('Archive', 'exist-theme-helpers'),
    ),

    array(
      'id'    => 'layout',
      'type'  => 'select',
      'title' => esc_html__('Layout', 'exist-theme-helpers'),
      'options' => array(
        ''      => esc_html__('Default', 'exist-theme-helpers'),
        '1'     => esc_html__('Grid', 'exist-theme-helpers'),
        '2'     => esc_html__('Metro 1', 'exist-theme-helpers'),
        '3'     => esc_html__('Metro 2', 'exist-theme-helpers'),
        '4'     => esc_html__('Custom content', 'exist-theme-helpers'),
      ),
    ),
    array(
      'id'    => 'sidebar',
      'type'  => 'select',
      'title' => esc_html__('Sidebar', 'exist-theme-helpers'),
      'options' => array(
        ''      => esc_html__('Default', 'exist-theme-helpers'),
        'left'     => esc_html__('Left', 'exist-theme-helpers'),
        'right'     => esc_html__('Right', 'exist-theme-helpers'),
        'hide'     => esc_html__('Hide', 'exist-theme-helpers'),
      ),
    ),

    array(
      'id'    => 'pagination',
      'type'  => 'select',
      'title' => esc_html__('Pagination', 'exist-theme-helpers'),
      'options' => array(
        ''   => esc_html__('Default', 'exist-theme-helpers'),
        '1'  => esc_attr__('Number', 'exist-theme-helpers'),
        '2'  => esc_attr__('Load more', 'exist-theme-helpers'),
      ),
    ),
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Footer', 'exist-theme-helpers'),
    ),
    array(
      'id'        => 'footer_style',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Footer Layout', 'exist-theme-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'exist-theme-helpers'),
        '1' => esc_html__('Style #1', 'exist-theme-helpers'),
        '2' => esc_html__('Style #2', 'exist-theme-helpers'),
        '3' => esc_html__('Style #3', 'exist-theme-helpers'),
      ),
      'default' => '0'
    ),
    array(
          'id'        => 'footer1_col',
          'type'      => 'select',
          'class'     => 'chosen','default' => 'default',
          'title'     => esc_html__('Column of Widget Footer #1', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer2_col',
          'type'      => 'select',
          'class'     => 'chosen','default' => 'default',
          'title'     => esc_html__('Column of Widget Footer #2', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer3_col',
          'type'      => 'select',
          'class'     => 'chosen','default' => 'default',
          'title'     => esc_html__('Column of Widget Footer #3', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer4_col',
          'type'      => 'select',
          'class'     => 'chosen','default' => 'default',
          'title'     => esc_html__('Column of Widget Footer #4', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer5_col',
          'type'      => 'select',
          'class'     => 'chosen','default' => 'default',
          'title'     => esc_html__('Column of Widget Footer #5', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer6_col',
          'type'      => 'select',
          'class'     => 'chosen','default' => 'default',
          'title'     => esc_html__('Column of Widget Footer #6', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Footer Color', 'exist-theme-helpers'),
        ),
        array(
          'id'        => 'footer_bg_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Background color', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Custom', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'footer_bg',
          'type'  => 'color_picker',
          'default' => '',
          'title'     => esc_html__('Background custome color', 'exist-theme-helpers'),
          'dependency'   => array( 'footer_bg_type', '==', '1' ),
        ),
        array(
          'id'        => 'footer_title_color_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Title color', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Custom', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'footer_title_color',
          'type'  => 'color_picker',
          'default' => '',
          'title'     => esc_html__('Title custome color', 'exist-theme-helpers'),
          'dependency'   => array( 'footer_title_color_type', '==', '1' ),
        ),
        array(
          'id'        => 'footer_text_color_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Text color', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Custom', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'footer_text_color',
          'type'  => 'color_picker',
          'default' => '',
          'title'     => esc_html__('Text custome color', 'exist-theme-helpers'),
          'dependency'   => array( 'footer_text_color_type', '==', '1' ),
        ),
        array(
          'id'        => 'footer_text_hover_color_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Text hover color', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Custom', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'footer_text_hover_color',
          'type'  => 'color_picker',
          'default' => '',
          'title'     => esc_html__('Text hover custome color', 'exist-theme-helpers'),
          'dependency'   => array( 'footer_text_hover_color_type', '==', '1' ),
        ),

  ),
);

$options[]   = array(
  'id'       => 'nouexist_layout_settings',
  'taxonomy' => 'product_tag', // category, post_tag or your custom taxonomy name
  'fields'   => array(

    array(
      'type'    => 'subheading',
      'content' => esc_html__('Logo', 'exist-theme-helpers'),
    ),
    array(
      'id'        => 'logo_type',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Logo', 'exist-theme-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'exist-theme-helpers'),
        '1' => esc_html__('Custom logo', 'exist-theme-helpers'),
      ),
      'default' => '0'
    ),
    array(
      'id'    => 'logo_custom',
      'type'  => 'upload',
      'title' => esc_html__('Upload Custom Logo', 'exist-theme-helpers'),
      'dependency'   => array( 'logo_type', '==', '1' )
    ),
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Heading', 'exist-theme-helpers'),
    ),
    array(
      'id'        => 'header_style',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Header style', 'exist-theme-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'exist-theme-helpers'),
        '1' => esc_html__('Style #1', 'exist-theme-helpers'),
        '2' => esc_html__('Style #2', 'exist-theme-helpers'),
        '3' => esc_html__('Style #3', 'exist-theme-helpers'),
        '4' => esc_html__('Style #4', 'exist-theme-helpers'),
        '5' => esc_html__('Style #5', 'exist-theme-helpers'),
        '6' => esc_html__('Style #6', 'exist-theme-helpers'),
        '7' => esc_html__('Style #7', 'exist-theme-helpers'),
        '8' => esc_html__('Style #8', 'exist-theme-helpers'),
        '9' => esc_html__('Style #9', 'exist-theme-helpers'),
      ),
      'default' => '0'
    ),

    array(
      'id'        => 'banner_heading_enable',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Enable Banner Heading', 'exist-theme-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'exist-theme-helpers'),
        '1' => esc_html__('Show', 'exist-theme-helpers'),
        '2' => esc_html__('Hide', 'exist-theme-helpers'),
      ),
      'default' => '0'
    ),

    array(
      'id'    => 'banner_heading',
      'type'  => 'upload',
      'title' => esc_html__('Banner heading', 'exist-theme-helpers'),
      'dependency'   => array( 'banner_heading_enable', '==', '1' )
    ),

    array(
      'id'    => 'banner_heading_style',
      'type'  => 'select',
      'title' => esc_html__('Banner heading style', 'exist-theme-helpers'),
      'options' => array(
        ''      => esc_html__('Default', 'exist-theme-helpers'),
        '1'     => esc_html__('Fullwidth', 'exist-theme-helpers'),
        '2'     => esc_html__('Normal', 'exist-theme-helpers'),
      ),
      'dependency'   => array( 'banner_heading_enable', '==', '1' )
    ),

    array(
      'type'    => 'subheading',
      'content' => esc_html__('Archive', 'exist-theme-helpers'),
    ),
    array(
      'id'    => 'layout',
      'type'  => 'select',
      'title' => esc_html__('Layout', 'exist-theme-helpers'),
      'options' => array(
        ''      => esc_html__('Default', 'exist-theme-helpers'),
        '1'     => esc_html__('Grid', 'exist-theme-helpers'),
        '2'     => esc_html__('Metro 1', 'exist-theme-helpers'),
        '3'     => esc_html__('Metro 2', 'exist-theme-helpers'),
        '4'     => esc_html__('Custom content', 'exist-theme-helpers'),
      ),
    ),
    array(
      'id'    => 'sidebar',
      'type'  => 'select',
      'title' => esc_html__('Sidebar', 'exist-theme-helpers'),
      'options' => array(
        ''      => esc_html__('Default', 'exist-theme-helpers'),
        'left'     => esc_html__('Left', 'exist-theme-helpers'),
        'right'     => esc_html__('Right', 'exist-theme-helpers'),
        'hide'     => esc_html__('Hide', 'exist-theme-helpers'),
      ),
    ),
    array(
      'id'    => 'pagination',
      'type'  => 'select',
      'title' => esc_html__('Pagination', 'exist-theme-helpers'),
      'options' => array(
        ''   => esc_html__('Default', 'exist-theme-helpers'),
        '1'  => esc_attr__('Number', 'exist-theme-helpers'),
        '2'  => esc_attr__('Load more', 'exist-theme-helpers'),
      ),
    ),
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Footer', 'exist-theme-helpers'),
    ),
    array(
      'id'        => 'footer_style',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Footer Layout', 'exist-theme-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'exist-theme-helpers'),
        '1' => esc_html__('Style #1', 'exist-theme-helpers'),
        '2' => esc_html__('Style #2', 'exist-theme-helpers'),
        '3' => esc_html__('Style #3', 'exist-theme-helpers'),
      ),
      'default' => '0'
    ),
    array(
          'id'        => 'footer1_col',
          'type'      => 'select',
          'class'     => 'chosen','default' => 'default',
          'title'     => esc_html__('Column of Widget Footer #1', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer2_col',
          'type'      => 'select','default' => 'default',
          'class'     => 'chosen',
          'title'     => esc_html__('Column of Widget Footer #2', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer3_col',
          'type'      => 'select',
          'class'     => 'chosen','default' => 'default',
          'title'     => esc_html__('Column of Widget Footer #3', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer4_col',
          'type'      => 'select',
          'class'     => 'chosen','default' => 'default',
          'title'     => esc_html__('Column of Widget Footer #4', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer5_col',
          'type'      => 'select',
          'class'     => 'chosen','default' => 'default',
          'title'     => esc_html__('Column of Widget Footer #5', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'id'        => 'footer6_col',
          'type'      => 'select',
          'class'     => 'chosen','default' => 'default',
          'title'     => esc_html__('Column of Widget Footer #6', 'exist-theme-helpers'),
          'options'   => array(
            'default'     => esc_html__('Default', 'exist-theme-helpers'),
            'hide' => esc_html__('Hide', 'exist-theme-helpers'),
            '1' => esc_html__('1 Column', 'exist-theme-helpers'),
            '2' => esc_html__('2 Column', 'exist-theme-helpers'),
            '3' => esc_html__('3 Column', 'exist-theme-helpers'),
            '4' => esc_html__('4 Column', 'exist-theme-helpers'),
            '5' => esc_html__('5 Column', 'exist-theme-helpers'),
            '6' => esc_html__('6 Column', 'exist-theme-helpers'),
            '7' => esc_html__('7 Column', 'exist-theme-helpers'),
            '8' => esc_html__('8 Column', 'exist-theme-helpers'),
            '9' => esc_html__('9 Column', 'exist-theme-helpers'),
            '10' => esc_html__('10 Column', 'exist-theme-helpers'),
            '11' => esc_html__('11 Column', 'exist-theme-helpers'),
            '12' => esc_html__('12 Column', 'exist-theme-helpers'),
          ),
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Footer Color', 'exist-theme-helpers'),
        ),
        array(
          'id'        => 'footer_bg_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Background color', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Custom', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'footer_bg',
          'type'  => 'color_picker',
          'default' => '',
          'title'     => esc_html__('Background custome color', 'exist-theme-helpers'),
          'dependency'   => array( 'footer_bg_type', '==', '1' ),
        ),
        array(
          'id'        => 'footer_title_color_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Title color', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Custom', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'footer_title_color',
          'type'  => 'color_picker',
          'default' => '',
          'title'     => esc_html__('Title custome color', 'exist-theme-helpers'),
          'dependency'   => array( 'footer_title_color_type', '==', '1' ),
        ),
        array(
          'id'        => 'footer_text_color_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Text color', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Custom', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'footer_text_color',
          'type'  => 'color_picker',
          'default' => '',
          'title'     => esc_html__('Text custome color', 'exist-theme-helpers'),
          'dependency'   => array( 'footer_text_color_type', '==', '1' ),
        ),
        array(
          'id'        => 'footer_text_hover_color_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Text hover color', 'exist-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'exist-theme-helpers'),
            '1' => esc_html__('Custom', 'exist-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'footer_text_hover_color',
          'type'  => 'color_picker',
          'default' => '',
          'title'     => esc_html__('Text hover custome color', 'exist-theme-helpers'),
          'dependency'   => array( 'footer_text_hover_color_type', '==', '1' ),
        ),

  ),
);
Exist_Helpers_CSFramework_Taxonomy::instance( $options );
