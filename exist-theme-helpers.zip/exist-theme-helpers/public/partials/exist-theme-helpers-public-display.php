<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://themeforest.net/user/nouthemes/portfolio
 * @since      1.0.0
 *
 * @package    Exist_Theme_Helpers
 * @subpackage Exist_Theme_Helpers/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
