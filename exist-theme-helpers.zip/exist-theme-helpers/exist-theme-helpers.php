<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://themeforest.net/user/nouthemes/portfolio
 * @since             1.0.1
 * @package           Exist_Theme_Helpers
 *
 * @wordpress-plugin
 * Plugin Name:       Exist Theme Helpers
 * Plugin URI:        https://themeforest.net/user/nouthemes/portfolio
 * Description:       Shortcode for Exist theme
 * Version:           1.0.1
 * Author:            Noutheme
 * Author URI:        https://themeforest.net/user/nouthemes/portfolio
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       exist-theme-helpers
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

define( 'PLUGIN_NAME_VERSION', '1.0.1' );

if ( ! defined( 'EXIST_HELPERS_VER' ) ) {
	/**
	 *
	 */
	define( 'EXIST_HELPERS_VER', '1.0.1' );
}

if ( ! defined( 'EXIST_HELPERS_DIR' ) ) {
	/**
	 *
	 */
	define( 'EXIST_HELPERS_DIR', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'EXIST_HELPERS_URL' ) ) {
	/**
	 *
	 */
	define( 'EXIST_HELPERS_URL', plugin_dir_url( __FILE__ ) );
}

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-exist-theme-helpers-activator.php
 */
function activate_exist_theme_helpers() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-exist-theme-helpers-activator.php';
	Exist_Theme_Helpers_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-exist-theme-helpers-deactivator.php
 */
function deactivate_exist_theme_helpers() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-exist-theme-helpers-deactivator.php';
	Exist_Theme_Helpers_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_exist_theme_helpers' );
register_deactivation_hook( __FILE__, 'deactivate_exist_theme_helpers' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'exist-theme-helpers-functions.php';
require plugin_dir_path( __FILE__ ) . 'includes/class-exist-theme-helpers.php';

add_action('vc_before_init', 'exist_theme_helpers_shortcodes_container');
function exist_theme_helpers_shortcodes_container(){
	if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	    class WPBakeryShortCode_Nouexist_Features extends WPBakeryShortCodesContainer {
	    }
	    class WPBakeryShortCode_Nouexist_Brand extends WPBakeryShortCodesContainer {
	    }
	    class WPBakeryShortCode_Nouexist_Testimonial extends WPBakeryShortCodesContainer {
	    }
	    class WPBakeryShortCode_Nouexist_Banner_Masonry extends WPBakeryShortCodesContainer {
	    }
	    class WPBakeryShortCode_Nouexist_Banner_Slider extends WPBakeryShortCodesContainer {
	    }
	}
	if ( class_exists( 'WPBakeryShortCode' ) ) {
	    
	    class WPBakeryShortCode_Nouexist_Feature_Item extends WPBakeryShortCode {
	    }
	    class WPBakeryShortCode_Nouexist_Brand_Item extends WPBakeryShortCode {
	    }
	    class WPBakeryShortCode_Nouexist_Testimonial_Item extends WPBakeryShortCode {
	    }
	    class WPBakeryShortCode_Nouexist_Banner_Masonry_Item extends WPBakeryShortCode {
	    }
	    class WPBakeryShortCode_Nouexist_Banner_Slider_Item extends WPBakeryShortCode {
	    }
	    
	}
}
/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_exist_theme_helpers() {

	$plugin = new Exist_Theme_Helpers();
	$plugin->run();

}
run_exist_theme_helpers();
