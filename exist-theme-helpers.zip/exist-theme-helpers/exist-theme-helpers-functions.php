<?php 
if ( ! defined( 'WPINC' ) ) {
	die;
}

function exist_helper_get_taxonomies()
{
	global $wpdb;
	return $wpdb->get_results( "SELECT DISTINCT `taxonomy` FROM $wpdb->term_taxonomy" );
}

/**
* Sync from customizer vs theme options
* 
* @author nouthemes [nouthemes@gmail.com]
* @since 1.0
* @return url
* @code Nam
*/
if(!function_exists('exist_helpers_option')){
  function exist_helpers_option($setting, $default = '')
  { 
    $options = get_option( '_nouexist_options', array() );
    $value = $default;
    if ( isset( $options[ $setting ] ) ) {
        $value = $options[ $setting ];
    }
    return $value;
  }
}

/**
 *
 * Get option
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! function_exists( 'exist_helpers_cs_get_option' ) ) {
  function exist_helpers_cs_get_option( $option_name = '', $default = '' ) {

    $options = apply_filters( 'cs_get_option', get_option( EXIST_HELPERS_CS_OPTION ), $option_name, $default );

    if( ! empty( $option_name ) && ! empty( $options[$option_name] ) ) {
      return $options[$option_name];
    } else {
      return ( ! empty( $default ) ) ? $default : null;
    }

  }
}

function exist_helpers_get_current_id(){
	$object_id = get_queried_object_id();
    if ( ( get_option( 'show_on_front' ) && get_option( 'page_for_posts' ) && is_home() ) || ( get_option( 'page_for_posts' ) && is_archive() && ! is_post_type_archive() && ! is_tax() ) && ! ( is_tax( 'product_cat' ) || is_tax( 'product_tag' ) ) || ( get_option( 'page_for_posts' ) && is_search() ) ) {
        
        $page_ID = get_option( 'page_for_posts' );

    } else {

        if ( isset( $object_id ) ) {
            $page_ID = $object_id;
        }

        if ( ! is_singular() ) {
            $page_ID = false;
        }

    }

    return $page_ID;
}

function exist_helpers_single_product_settings(){
  	$related_type = exist_helpers_option('nouexist_product_related_type', 'related');
  	$title = exist_helpers_option('nouexist_shop_related_title');
  	$desc = exist_helpers_option('nouexist_shop_related_desc');

  	$facebook = exist_helpers_option('nouexist_single_share_facebook', 1);
	$google = exist_helpers_option('nouexist_single_share_google', 1);
	$twitter = exist_helpers_option('nouexist_single_share_twitter', 1);
	$pinterest = exist_helpers_option('nouexist_single_share_pinterest', 1);
	$linkedin = exist_helpers_option('nouexist_single_share_linkedin', 1);

  	$post_id = exist_helpers_get_current_id();
  	if($post_id){
    	$nouexist_meta = get_post_meta( $post_id, 'nouexist_layout_settings', true );
        if ( isset($nouexist_meta['product_related_type']) && !empty($nouexist_meta['product_related_type']) ) {
            $related_type = $nouexist_meta['product_related_type'];
        }
        if ( isset($nouexist_meta['shop_related_title']) && !empty($nouexist_meta['shop_related_title']) ) {
            $title = $nouexist_meta['shop_related_title'];
        }
        if ( isset($nouexist_meta['shop_related_desc']) && !empty($nouexist_meta['shop_related_desc']) ) {
            $desc = $nouexist_meta['shop_related_desc'];
        }

        if ( isset($nouexist_meta['facebook']) && !empty($nouexist_meta['facebook']) ) {
            $facebook = $nouexist_meta['facebook'];
            if($nouexist_meta['facebook'] == 2){
            	$facebook = '';
            }
        }
        if ( isset($nouexist_meta['google']) && !empty($nouexist_meta['google']) ) {
            $google = $nouexist_meta['google'];
            if($nouexist_meta['google'] == 2){
            	$google = '';
            }
        }
        if ( isset($nouexist_meta['twitter']) && !empty($nouexist_meta['twitter']) ) {
            $twitter = $nouexist_meta['twitter'];
            if($nouexist_meta['twitter'] == 2){
            	$twitter = '';
            }
        }
        if ( isset($nouexist_meta['pinterest']) && !empty($nouexist_meta['pinterest']) ) {
            $pinterest = $nouexist_meta['pinterest'];
            if($nouexist_meta['pinterest'] == 2){
            	$pinterest = '';
            }
        }
        if ( isset($nouexist_meta['linkedin']) && !empty($nouexist_meta['linkedin']) ) {
            $linkedin = $nouexist_meta['linkedin'];
            if($nouexist_meta['linkedin'] == 2){
            	$linkedin = '';
            }
        }
  	}

  	return apply_filters('nouexist_single_product_settings', 
  				array(
  					'related_type' => $related_type, 
  					'related_title' => $title, 
  					'related_desc' => $desc,
  					'facebook' => $facebook,
  					'google' => $google,
  					'twitter' => $twitter,
  					'pinterest' => $pinterest,
  					'linkedin' => $linkedin
  				), 
  				$post_id
  			);
}

/**
 * Get post like
 *
 * @package Masta
 * @since 1.0
 * @author nouthemes [nouthemes@gmail.com]
 */

if(!function_exists('exist_helpers_post_like')){
	function exist_helpers_post_like($id = null) 
	{
		$post_id = exist_helpers_get_current_id();
		if($id){
			$post_id = $id;
		}
		$meta = get_post_meta($post_id, '_post_like_count', true);

		if ( is_numeric( $meta ) && $meta > 0 ) { 
			$number = exist_helpers_format_count($meta);
		} else {
			$number = 0;
		}
			
	    return $number;
	}
}


/**
 * Format number with K, M, B
 *
 * @package Masta
 * @since 1.0
 * @author nouthemes [nouthemes@gmail.com]
 */
if(!function_exists('exist_helpers_format_count')){
	function exist_helpers_format_count( $number ) {
		$precision = 2;
		if ( $number >= 1000 && $number < 1000000 ) {
			$formatted = number_format( $number/1000, $precision ).'K';
		} else if ( $number >= 1000000 && $number < 1000000000 ) {
			$formatted = number_format( $number/1000000, $precision ).'M';
		} else if ( $number >= 1000000000 ) {
			$formatted = number_format( $number/1000000000, $precision ).'B';
		} else {
			$formatted = $number; // Number is less than 1000
		}
		$formatted = str_replace( '.00', '', $formatted );
		return $formatted;
	}
}


/**
 * Get current IP address
 *
 * @package Masta
 * @since 1.0
 * @author nouthemes [nouthemes@gmail.com]
 */
if(!function_exists('exist_helpers_get_ip')){
	function exist_helpers_get_ip() {
		if ( isset( $_SERVER['HTTP_CLIENT_IP'] ) && ! empty( $_SERVER['HTTP_CLIENT_IP'] ) ) {
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		} elseif ( isset( $_SERVER['HTTP_X_FORWARDED_FOR'] ) && ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} else {
			$ip = ( isset( $_SERVER['REMOTE_ADDR'] ) ) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
		}
		$ip = filter_var( $ip, FILTER_VALIDATE_IP );
		$ip = ( $ip === false ) ? '0.0.0.0' : $ip;
		return $ip;
	}
}


if(!function_exists('exist_helpers_already_liked')){
	function exist_helpers_already_liked( $post_id, $is_comment = null ) {
		
		$post_users = NULL;
		$user_id = NULL;

		if ( is_user_logged_in() ) { // user is logged in

			$user_id = get_current_user_id();
			$post_meta_users = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_liked" ) : get_post_meta( $post_id, "_user_liked" );
			
			if ( count( $post_meta_users ) != 0 ) {
				$post_users = $post_meta_users[0];
			}

		} else { // user is anonymous

			$user_id = exist_helpers_get_ip();
			$post_meta_users = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_IP" ) : get_post_meta( $post_id, "_user_IP" ); 
			
			if ( count( $post_meta_users ) != 0 ) { // meta exists, set up values
				$post_users = $post_meta_users[0];
			}
		}

		if ( is_array( $post_users ) && in_array( $user_id, $post_users ) ) {
			return true;
		} else {
			return false;
		}
	}
}

/**
 * Utility returns the button icon for "like" action
 * @since    1.0
 */
if(!function_exists('exist_helpers_get_liked_icon')){
	function exist_helpers_get_liked_icon() {
		$loved_icon = exist_helpers_option('exist_helpers_loved_icon', 'fa fa-heart');
		$icon = ' <i class="'.esc_attr( $loved_icon ).'"></i>';
		return $icon;
	}
}	

/**
 * Utility returns the button icon for "unlike" action
 * @since   1.0
 */
if(!function_exists('exist_helpers_get_unliked_icon')){
	function exist_helpers_get_unliked_icon() {
		$love_icon = exist_helpers_option('exist_helpers_love_icon', 'fa fa-heart-o');
		$icon = '<i class="'.esc_attr( $love_icon ).'"></i>';
		return $icon;
	}
}	

if(!function_exists('exist_helpers_button_like')){
	function exist_helpers_button_like($post_id, $class = '', $icon = '', $count = '', $title = '', $echo = true)
	{
		if(empty($title)){
			$title = esc_html__('Like', 'exist-theme-helpers');
		}

		if(empty($icon)){
			$icon = exist_helpers_get_unliked_icon();
		}

		$liked = exist_helpers_already_liked($post_id);
		if($liked){
			$class = esc_attr( 'liked', 'exist-theme-helpers' );
			$title = esc_html__( 'Unlike', 'exist-theme-helpers' );
			$icon = exist_helpers_get_liked_icon();
		}
		
		$output = '<span data-id="'.intval($post_id).'" class="post-like like '.esc_attr($class).'">'.wp_kses_post($icon).' ' . esc_attr( $title ) . '</span>';

		
		$display_button = exist_helpers_option('exist_helpers_post_like');
		$post_id = exist_helpers_get_current_id();
		if($post_id){
			$nouexist_meta = get_post_meta( $post_id, 'nouexist_layout_settings', true );
	        if ( !empty($nouexist_meta['social_like']) ) {
	          $display_button = $nouexist_meta['social_like'];
	        }
		}

		if(empty($display_button)){
			$output = '';
		}

		if($echo){
			echo $output;
		}else{
			return $output;
		}
	}
}

/**
* Single share post
*
*/
if(!function_exists('exist_helpers_share_post')){
	add_action('woocommerce_share', 'exist_helpers_share_post');
	function exist_helpers_share_post()
	{
		$settings = exist_helpers_single_product_settings();

		$facebook = $settings['facebook'];
		$google = $settings['google'];
		$twitter = $settings['twitter'];
		$pinterest = $settings['pinterest'];
		$linkedin = $settings['linkedin'];
		if( !empty($facebook) || !empty($google) || !empty($twitter) || !empty($pinterest) || !empty($linkedin) ):
		?>
			<p class="exist-share <?php if(is_singular('nouexist_portfolio')){echo 'ps-social';}else{echo 'ps-product__sharing';}?>" data-title="<?php the_title();?>" data-url="<?php the_permalink();?>">
				<?php if(is_singular('nouexist_portfolio')){
						echo '<strong>';esc_html_e('Share:', 'exist-theme-helpers');echo '</strong>';
					}else{
						esc_html_e('Share:', 'exist-theme-helpers');
					}?>
				<?php if(!empty($facebook)):?>
                <a href="#" class="share" data-type="facebook"><i class="fa fa-facebook"></i></a>
                <?php endif;?>

                <?php if(!empty($twitter)):?>
                <a href="#" class="share" data-type="twitter"><i class="fa fa-twitter"></i></a>
                <?php endif;?>

                <?php if(!empty($google)):?>
                <a href="#" class="share" data-type="google"><i class="fa fa-google-plus"></i></a>
                <?php endif;?>

                <?php if(!empty($pinterest)):?>
                <a href="#" class="share" data-type="pinterest"><i class="fa fa-pinterest"></i></a>
                <?php endif;?>

                <?php if(!empty($linkedin)):?>
                <a href="#" class="share" data-type="linkedin"><i class="fa fa-linkedin"></i></a>
                <?php endif;?>
			</p>
		<?php
		endif;
	}
}

function exist_helpers_post_user_likes( $user_id, $post_id, $is_comment ) {
	$post_users = '';
	$post_meta_users = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_liked" ) : get_post_meta( $post_id, "_user_liked" );
	if ( count( $post_meta_users ) != 0 ) {
		$post_users = $post_meta_users[0];
	}
	if ( !is_array( $post_users ) ) {
		$post_users = array();
	}
	if ( !in_array( $user_id, $post_users ) ) {
		$post_users['user-' . $user_id] = $user_id;
	}
	return $post_users;
} 

function exist_helpers_post_ip_likes( $user_ip, $post_id, $is_comment ) {
	$post_users = '';
	$post_meta_users = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_IP" ) : get_post_meta( $post_id, "_user_IP" );
	// Retrieve post information
	if ( count( $post_meta_users ) != 0 ) {
		$post_users = $post_meta_users[0];
	}
	if ( !is_array( $post_users ) ) {
		$post_users = array();
	}
	if ( !in_array( $user_ip, $post_users ) ) {
		$post_users['ip-' . $user_ip] = $user_ip;
	}
	return $post_users;
}

function exist_helpers_get_image_by_id($id, $size, $class = array()){
	$image_attributes = wp_get_attachment_image_src( $id, $size );
	if($image_attributes){
		echo '<img src="'.esc_attr($image_attributes[0]).'" alt="">';
	}
}

function exist_helpers_product_countdown($str){
	?>
	<ul class="ps-countdown" data-time="<?php echo esc_attr($str);?> 23:59:59">
        <li><span class="hours"></span>
            <p><?php esc_html_e('Hours', 'exist-theme-helpers');?></p>
        </li>
        <li class="divider">:</li>
        <li><span class="minutes"></span>
            <p><?php esc_html_e('Minutes', 'exist-theme-helpers');?></p>
        </li>
        <li class="divider">:</li>
        <li><span class="seconds"></span>
            <p><?php esc_html_e('Seconds', 'exist-theme-helpers');?></p>
        </li>
    </ul>
	<?php
}

function exist_helpers_product_proccess($product){
	if($product->get_manage_stock() && $product->get_stock_quantity() > 0):
		$total_sales = get_post_meta($product->get_id(), 'total_sales', true);
      	$total_sales = !empty($total_sales) ? $total_sales : '0';
      	$total_stock = $product->get_stock_quantity();
		?>
		<div class="ps-product__status">
            <div class="sold"><?php esc_html_e('Already sold', 'exist-theme-helpers');?>: <span><?php echo intval($total_sales)?></span></div>
            <div class="avaiable"><?php esc_html_e('avaiable', 'exist-theme-helpers');?>: <span><?php echo intval($total_stock)?></span></div>
        </div>
        <div class="progress">
            <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo intval($total_sales*100/$total_stock)?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo intval($total_sales*100/$total_stock)?>%;"></div>
        </div>
		<?php
	endif;
}

/**
 * Get Woo style
 *
 * @package Shoes
 * @since 1.0
 * @author nouthemes [nouthemes@gmail.com]
 */

if(!function_exists('nouexist_helpers_shop_style')){
  function nouexist_helpers_shop_style() 
  {
      $layout = exist_helpers_option('nouexist_woo_archive_layout', '1');
      $sidebar = exist_helpers_option('nouexist_woo_archive_sidebar', 'left');
      $wishlist = exist_helpers_option('nouexist_woo_archive_wishlist');
      $compare = exist_helpers_option('nouexist_woo_archive_compare');
      $quickview = exist_helpers_option('nouexist_woo_archive_quickview');
      $addtocart = exist_helpers_option('nouexist_woo_archive_addtocart', 1);
      $banner_heading = exist_helpers_option('nouexist_shop_banner_heading');
      $banner_heading_style = exist_helpers_option('nouexist_shop_banner_heading_style', '1');
      $pagination = exist_helpers_option('nouexist_woo_archive_pagination', '1');
      
      if(is_tax()){
        $queried_object = get_queried_object();
        $term_id = $queried_object->term_id;
        if($term_id){
            $nouexist_meta = get_term_meta( $term_id, 'nouexist_layout_settings', true );
            if ( isset($nouexist_meta['sidebar']) && !empty($nouexist_meta['sidebar']) ) {
                $sidebar = $nouexist_meta['sidebar'];
            }

            if ( isset($nouexist_meta['wishlist']) && !empty($nouexist_meta['wishlist']) ) {
                $wishlist = $nouexist_meta['wishlist'];
            }

            if ( isset($nouexist_meta['compare']) && !empty($nouexist_meta['compare']) ) {
                $compare = $nouexist_meta['compare'];
            }
            if ( !empty($nouexist_meta['banner_heading']) ) {
              $banner_heading = $nouexist_meta['banner_heading'];
            }
            if ( !empty($nouexist_meta['quickview']) ) {
              $quickview = $nouexist_meta['quickview'];
            }
            if ( !empty($nouexist_meta['pagination']) ) {
              $pagination = $nouexist_meta['pagination'];
            }
            if ( isset($nouexist_meta['banner_heading_style']) && !empty($nouexist_meta['banner_heading_style']) ) {
                $banner_heading_style = $nouexist_meta['banner_heading_style'];
            }
            if ( isset($nouexist_meta['layout']) && !empty($nouexist_meta['layout']) ) {
                $layout = $nouexist_meta['layout'];
            }
        }
    } 

    $post_id = exist_helpers_get_current_id();
    if($post_id){
      $nouexist_meta = get_post_meta( $post_id, 'nouexist_layout_settings', true );
      if ( !empty($nouexist_meta['sidebar']) ) {
        $sidebar = $nouexist_meta['sidebar'];
      }
      if ( !empty($nouexist_meta['banner_heading']) ) {
        $banner_heading = $nouexist_meta['banner_heading'];
      }
      if ( isset($nouexist_meta['banner_heading_style']) && !empty($nouexist_meta['banner_heading_style']) ) {
          $banner_heading_style = $nouexist_meta['banner_heading_style'];
      }
    }  

    if( !is_active_sidebar('shop-sidebar') ){
      $sidebar = 'hide';
    } 

    if(isset($_GET['shop_layout']) && !empty($_GET['shop_layout']) && intval($_GET['shop_layout'])){
      $layout = intval($_GET['shop_layout']);
    }

    return array('layout' => $layout, 'addtocart' => $addtocart, 'wishlist' => $wishlist, 'compare' => $compare, 'sidebar' => $sidebar, 'banner_heading' => $banner_heading, 'quickview' => $quickview, 'banner_heading_style' => $banner_heading_style, 'pagination' => $pagination);
  }
}

function nouexist_helpers_get_image_by_id($id, $size, $class = array()){
	$image_attributes = wp_get_attachment_image_src( $id, $size );
	if($image_attributes){
		echo '<img src="'.esc_attr($image_attributes[0]).'" alt="">';
	}
}

function nouexist_helpers_get_portfolios(){
	$per_page = get_option('posts_per_page');
	if(is_page()){
		$settings = get_post_meta(get_the_ID(), '_portfolio_page', true);
		if(!empty($settings['posts_per_page'])){
			$per_page = $settings['posts_per_page'];
		}
	}
	$args = array('post_type' => 'nouexist_portfolio', 'post_status' => 'publish', 'posts_per_page' => $per_page);
	return new WP_Query($args);
}

function nouexist_get_products($atts){
	$per_page = !empty($atts['number']) ? intval($atts['number']) : '8';
	$args = array(
		'post_type' => 'product', 
		'post_status' => 'publish',
		'posts_per_page' => $per_page
		);

	if(!empty($atts['id']) && intval($atts['id'])){
		$args['p'] = $atts['id'];
	}

	if(!empty($atts['paged'])){
		$args['paged'] = intval($atts['paged']);
	}

	if(!empty($atts['ids'])){
		$args['post__in'] = explode(',', $atts['ids']);
	}else{
		if(!empty($atts['cat'])){
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'product_cat',
					'field'    => 'term_id',
					'terms'    => $atts['cat'],
				),
			);
		}
	}
	if(!empty($atts['type'])){
		switch ( $atts['type'] ) {
			case 'featured' :
				$meta_query  = WC()->query->get_meta_query();
				$tax_query   = WC()->query->get_tax_query();
				$tax_query[] = array(
					'taxonomy' => 'product_visibility',
					'field'    => 'name',
					'terms'    => 'featured',
					'operator' => 'IN',
				);
				$args['meta_query'] = $meta_query;
				$args['tax_query']  = $tax_query;
				break;
			case 'onsale' :
				$product_ids_on_sale    = wc_get_product_ids_on_sale();
				$product_ids_on_sale[]  = 0;
				$args['post__in'] = $product_ids_on_sale;
				break;	
			case 'bestsale' :
				$args['meta_key'] = 'total_sales';
				$args['orderby']  = 'meta_value_num';
		}
	}


	$transient_name = 'nouexist_wc_loop' . substr( md5( wp_json_encode( $args ) . 'products' ), 28 ) . WC_Cache_Helper::get_transient_version( 'product_query' );
	$products            = get_transient( $transient_name );

	if ( false === $products ) {
		$products = new WP_Query( $args );
		set_transient( $transient_name, $products, DAY_IN_SECONDS * 30 );
	}
	
	return $products;
}
?>