<?php
/**
* 
*/
class Xuper_Theme_Helpers_Shortcode_Info
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		$atts = shortcode_atts( array(
		), $atts, 'nouxuper_info' );
		
		ob_start();
			if(!empty($content)):
			?>
			<div class="header__services">
            	<div class="container">
                	<div class="ps-slider--services ps-slider--center owl-slider" data-owl-auto="true" data-owl-loop="true" data-owl-speed="7000" data-owl-gap="0" data-owl-nav="true" data-owl-dots="false" data-owl-item="1" data-owl-item-xs="1" data-owl-item-sm="1" data-owl-item-md="1" data-owl-item-lg="1" data-owl-duration="1000" data-owl-mousedrag="on">
			        	<?php echo do_shortcode($content);?>
			        </div>
			    </div>
		    </div>
			<?php	
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Xuper - Info Carousel", 'xuper-theme-helpers' ),
	      	"base" => "nouxuper_info",
	      	"class" => "",
	      	"category" => esc_html__( "Xuper Theme", 'xuper-theme-helpers'),
	      	"params" => array(),
	      	"as_parent" => array('only' => 'nouxuper_info_item'),
	      	"content_element" => true,
		    "show_settings_on_create" => false,
		    "is_container" => true,
		    "js_view" => 'VcColumnView'
	    ) );
		endif;
	}
}
?>