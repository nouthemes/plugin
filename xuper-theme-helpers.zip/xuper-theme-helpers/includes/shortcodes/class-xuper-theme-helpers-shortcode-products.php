<?php
/**
* 
*/
class Xuper_Theme_Helpers_Shortcode_Products
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		if ( empty( $atts ) ) {
			return '';
		}

		$atts = shortcode_atts( array(
			'css' => '',
			'title' => '',
			'desc' => '',
			'style' => '',
			'type' => '',
			'ids' => '',
			'cat' => '',
			'number' => '',
			'order_by' => '',
			'item_style' => '',
		), $atts, 'nouxuper_products' );

		$shortcode_id = uniqid('nouxuper_products');

		$css = !empty($atts['css']) ? $atts['css'] : '';
		$title = !empty($atts['title']) ? $atts['title'] : '';
		$desc = !empty($atts['desc']) ? $atts['desc'] : '';
		$type = !empty($atts['type']) ? $atts['type'] : 'recent';
		$style = !empty($atts['style']) ? $atts['style'] : 'grid';
		$number = !empty($atts['number']) ? $atts['number'] : get_option('posts_per_page');
		$item_style = !empty($atts['item_style']) ? $atts['item_style']: 'default';
		
		$products = self::get_products($atts);
		ob_start();
			if($products->have_posts()):
				$shop = nouxuper_shop_style();
				?>
				<div class="xuper-section-products <?php echo esc_attr($css);?>">
					<?php if(!empty($title)){?>
			            <div class="ps-section__header text-center">
			                <h2 class="ps-section__title"><?php echo esc_html($title);?></h2>
			                <?php if(!empty($desc)){echo wp_kses_post(wpautop($desc));}?>

			                <?php if($style == 'grid' && $item_style == 'flat'):?>

			                <?php
			                //get term
			                if(!is_page_template('page-templates/home-left.php')){
				                $all_terms = array();
				                while($products->have_posts()){ $products->the_post();
					                $terms = get_the_terms ( get_the_ID(), 'product_cat' );
									foreach ( $terms as $term ) {
									    if(!isset($all_terms[$term->slug])){$all_terms[$term->slug] = $term->name;}
									}
								}

								if(!empty($all_terms)){
				                ?>

						        <ul class="ps-masonry__filter">
				                    <li class="current"><a href="#" data-filter="*"><?php esc_html_e('All', 'xuper-theme-helpers');?></a></li>
				                    <?php foreach($all_terms as $k => $v){?>
				                    <li><a href="#" data-filter=".product_cat-<?php echo esc_attr($k);?>"><?php echo esc_html($v);?></a></li>
				                    <?php }?>
				                </ul>
				                <?php }}endif;?>

			            </div>
			        <?php }?>

			        <?php if($style == 'grid'):?>
				        <?php if($item_style == 'default'):?>
					        <div class="ps-section__content">
		            			<div class="row products">
		            				<?php 
		            				while($products->have_posts()): $products->the_post();
		            					$product = wc_get_product(get_the_ID());
		            					?>
		            					<div <?php post_class('col-lg-3 col-md-3 col-sm-6 col-xs-12'); ?> data-id="<?php the_ID();?>" data-url="<?php the_permalink();?>" data-title="<?php the_title();?>">
		            						<?php self::product_item_simple($product);?>
		            					</div>
		            				<?php endwhile;?>
		            			</div>
		            		</div>	
	            		<?php else:?>
		            		<div class="ps-section__content">
				                <div class="masonry-wrapper" data-col-md="4" data-col-sm="2" data-col-xs="1" data-gap="30" data-radio="100%">
				                    <div class="ps-masonry">
				                        <div class="grid-sizer"></div>
				                        <?php 
		                				while($products->have_posts()): $products->the_post();
		                					$product = wc_get_product(get_the_ID());
		                					?>
		                					<div <?php post_class('grid-item bracelets'); ?> data-id="<?php the_ID();?>" data-url="<?php the_permalink();?>" data-title="<?php the_title();?>">
		                						<?php self::product_item_flat($product);?>
		                					</div>
		                					<?php
		                				endwhile;?>   
				                    </div>
				                </div>
				            </div>            
	            		<?php endif;?>
	            	<?php else:?>
	            		<?php if($item_style == 'default'):?>
					        <div class="ps-section__content">
                				<div class="ps-slider--center owl-slider" data-owl-auto="true" data-owl-loop="true" data-owl-speed="5000" data-owl-gap="30" data-owl-nav="true" data-owl-dots="false" data-owl-item="4" data-owl-item-xs="1" data-owl-item-sm="2" data-owl-item-md="3" data-owl-item-lg="4" data-owl-duration="1000" data-owl-mousedrag="on" data-owl-nav-left="&lt;i class='ps-icon-arrow-left'&gt;&lt;/i&gt;" data-owl-nav-right="&lt;i class='ps-icon-arrow-right'&gt;&lt;/i&gt;">
		            				<?php 
		            				while($products->have_posts()): $products->the_post();
		            					$product = wc_get_product(get_the_ID());
		            					?>
		            					<div <?php post_class(); ?> data-id="<?php the_ID();?>" data-url="<?php the_permalink();?>" data-title="<?php the_title();?>">
		            					<?php self::product_item_simple($product);?>
		            					</div>
		            				<?php endwhile;?>
		            			</div>
		            		</div>	
	            		<?php else:?>
		            		<div class="ps-section__content">
                				<div class="ps-slider--center owl-slider" data-owl-auto="true" data-owl-loop="true" data-owl-speed="5000" data-owl-gap="30" data-owl-nav="true" data-owl-dots="false" data-owl-item="4" data-owl-item-xs="1" data-owl-item-sm="3" data-owl-item-md="4" data-owl-item-lg="4" data-owl-duration="1000" data-owl-mousedrag="on" data-owl-nav-left="&lt;i class='ps-icon-arrow-left'&gt;&lt;/i&gt;" data-owl-nav-right="&lt;i class='ps-icon-arrow-right'&gt;&lt;/i&gt;">
			                        <?php 
	                				while($products->have_posts()): $products->the_post();
	                					$product = wc_get_product(get_the_ID());
	                					?>
		            					<div <?php post_class(); ?> data-id="<?php the_ID();?>" data-url="<?php the_permalink();?>" data-title="<?php the_title();?>">
		            					<?php self::product_item_flat($product);?>
		            					</div>
		            				<?php endwhile;?> 
				                </div>
				            </div>            
	            		<?php endif;?>	
	            	<?php endif;?>
				</div>
				<?php
			endif;wp_reset_postdata();
		return ob_get_clean();
		
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		vc_map( array(
	      	"name" => esc_html__( "Xuper - Products", 'xuper-theme-helpers' ),
	      	"base" => "nouxuper_products",
	      	"class" => "",
	      	"category" => esc_html__( "Xuper Theme", 'xuper-theme-helpers'),
	      	'description' => esc_html__('Products display type Slider or Grid', 'xuper-theme-helpers'),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "heading" => esc_html__( "Title", 'xuper-theme-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "heading" => esc_html__( "Description", 'xuper-theme-helpers' ),
		            "param_name" => "desc",
		        ),
		        array(
		            "type" => "textfield",
		            "heading" => esc_html__( "Custom class CSS", 'xuper-theme-helpers' ),
		            "param_name" => "css",
		        ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "holder" => "div",
		            "heading" => esc_html__( "Type of section show", 'xuper-theme-helpers' ),
		            "param_name" => "style",
		            "value" => array(
		            	esc_html__('Grid', 'xuper-theme-helpers') => 'grid', 
		            	esc_html__('Slider', 'xuper-theme-helpers') => 'slider',
		            ), 
		            'group' => esc_html__('Display', 'xuper-theme-helpers'),
		        ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "heading" => esc_html__( "Type of item show", 'xuper-theme-helpers' ),
		            "param_name" => "item_style",
		            "value" => array(
		            	esc_html__('Default', 'xuper-theme-helpers') => 'default', 
		            	esc_html__('Flat', 'xuper-theme-helpers') => 'flat', 
		            ), 
		            'group' => esc_html__('Display', 'xuper-theme-helpers'),
		        ),
		        
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "heading" => esc_html__( "Type of products show", 'xuper-theme-helpers' ),
		            "param_name" => "type",
		            "value" => array(esc_html__('--Select type--', 'xuper-theme-helpers') => '', esc_html__('Recent', 'xuper-theme-helpers') => 'recent', esc_html__('Featured', 'xuper-theme-helpers') => 'featured', esc_html__('Sale', 'xuper-theme-helpers') => 'onsale', esc_html__('Best sale', 'xuper-theme-helpers') => 'bestsale'), 
		            'group' => esc_html__('Display', 'xuper-theme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "IDs posts, EX: 21,22,23", 'xuper-theme-helpers' ),
		            "param_name" => "ids",
		            'group' => esc_html__('Display', 'xuper-theme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Category ID", 'xuper-theme-helpers' ),
		            "param_name" => "cat",
		            'group' => esc_html__('Display', 'xuper-theme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Number of posts show(default 8)", 'xuper-theme-helpers' ),
		            "param_name" => "number",
		            'group' => esc_html__('Display', 'xuper-theme-helpers'),
		        ),
	      	)
	    ) );
	}

	private static function get_products($atts){
		return nouxuper_get_products($atts);
	}

	private static function product_item_simple($product){
		$shop = nouxuper_shop_style();
		?>
            <div class="ps-product--fashion">
                <div class="ps-product__thumbnail">
                	<a class="ps-product__overlay" href="<?php the_permalink();?>"></a>
					<?php woocommerce_show_product_loop_sale_flash();?>
					<?php woocommerce_template_loop_product_thumbnail();?>
		            
		            <ul class="ps-product__actions">
		                <?php if(!empty($shop['quickview'])):?>
		                <li><a href="#quickview" data-product_id="<?php the_ID();?>" class="quickview" title="<?php esc_html_e('Quick View', 'xuper-theme-helpers');?>"><i class="ps-icon-eye"></i></a></li>
		                <?php endif;?>

		                <?php if(!empty($shop['compare'])):?>
		                <li><a href="#" data-product_id="<?php the_ID();?>" class="compare" title="<?php esc_html_e('Compare', 'xuper-theme-helpers');?>"><i class="ps-icon-compare"></i></a></li>
		                <?php endif;?>

		                <?php if(!empty($shop['wishlist'])):?>
		                <li><a href="#" data-product_id="<?php the_ID();?>" class="wishlist" title="<?php esc_html_e('Wishlist', 'xuper-theme-helpers');?>"><i class="ps-icon-heart"></i></a></li>
		                <?php endif;?>
		            </ul>
                </div>
                <div class="ps-product__content">
                	<a class="ps-product__title" href="<?php the_permalink();?>"><?php the_title();?></a>
		            <?php woocommerce_template_loop_price();?>

		            <?php if(!empty($shop['addtocart'])){woocommerce_template_loop_add_to_cart();}?>
                </div>
            </div>
		<?php
	}

	private static function product_item_flat($product){
		$shop = nouxuper_shop_style();
		$average = $product->get_average_rating();
        $class = implode( ' ', array_filter( array(
            'button',
            'product_type_' . $product->get_type(),
            $product->is_purchasable() && $product->is_in_stock() ? 'add_to_cart_button' : '',
            $product->supports( 'ajax_add_to_cart' ) ? 'ajax_add_to_cart' : '',
        ) ) );
        ?>
        	
            <div class="grid-item__content-wrapper">
                <div class="ps-product--yewelry">
                    <div class="ps-product__thumbnail">
                    	<a class="ps-product__overlay" href="<?php the_permalink();?>"></a>
						<?php woocommerce_show_product_loop_sale_flash();?>
						<?php woocommerce_template_loop_product_thumbnail();?>
                        
                        <ul class="ps-product__actions">
                            <?php if(!empty($shop['quickview'])):?>
			                <li><a href="#quickview" data-product_id="<?php the_ID();?>" class="quickview" title="<?php esc_html_e('Quick View', 'xuper-theme-helpers');?>"><i class="ps-icon-eye"></i></a></li>
			                <?php endif;?>

			                <?php if(!empty($shop['wishlist'])):?>
			                <li><a href="#" data-product_id="<?php the_ID();?>" class="wishlist" title="<?php esc_html_e('Wishlist', 'xuper-theme-helpers');?>"><i class="ps-icon-heart"></i></a></li>
			                <?php endif;?>

			                <?php if(!empty($shop['addtocart'])):?>
			                <li>
			                	<?php
	                        	echo apply_filters( 'woocommerce_loop_add_to_cart_link_shortcode',
									sprintf( '<a href="%s" data-quantity="%s" data-product_id="%s" data-product_sku="%s" class="%s">%s</a>',
										esc_url( $product->add_to_cart_url() ),
										esc_attr( 1 ),
										esc_attr( $product->get_id() ),
										esc_attr( $product->get_sku() ),
										esc_attr( isset( $class ) ? $class : 'button' ),
										'<i class="ps-icon-cart-2"></i>'
									),
								$product );
	                        	?>
			                </li>
			                <?php endif;?>
                        </ul>
                    </div>
                    <div class="ps-product__content">
                        <?php nouxuper_rating_dropdown( $average ); ?>
                        <a class="ps-product__title" href="<?php the_permalink();?>"><?php the_title();?></a>
	            		<?php woocommerce_template_loop_price();?>
                    </div>
                </div>
            </div>
        <?php
	}
}
?>