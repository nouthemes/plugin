<?php
/**
* 
*/
class Xuper_Theme_Helpers_Shortcode_Map
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		
		$atts = shortcode_atts( array(
			'title' => '',
		), $atts, 'nouxuper_map' );
		
		ob_start();
			?>
			<div id="contact-map" data-type="<?php echo esc_attr(nouxuper_theme_option('nouxuper_map_type', 'address'));?>" data-address="<?php echo esc_attr(nouxuper_theme_option('nouxuper_map_address'));?>" data-lng="<?php echo esc_attr(nouxuper_theme_option('nouxuper_map_longitude'));?>" data-lat="<?php echo esc_attr(nouxuper_theme_option('nouxuper_map_latitude'));?>" data-zoom="<?php echo esc_attr(nouxuper_theme_option('nouxuper_map_zoom', 17));?>" data-icon="<?php echo esc_attr(nouxuper_theme_option('nouxuper_map_marker', NOUXUPER_IMG.'/marker.png'));?>" data-title="<?php echo esc_attr(nouxuper_theme_option('nouxuper_map_address'));?>"></div>
			<?php
		return ob_get_clean();
	}

	/**
	 * Map shortcode Post items.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Xuper - Google Map", 'xuper-theme-helpers' ),
	      	"base" => "nouxuper_map",
	      	"class" => "",
	      	"category" => esc_html__( "Xuper Theme", 'xuper-theme-helpers'),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", 'xuper-theme-helpers' ),
		            "param_name" => "title",
		        ),
	      	)
	    ) );
		endif;
	}
}
?>