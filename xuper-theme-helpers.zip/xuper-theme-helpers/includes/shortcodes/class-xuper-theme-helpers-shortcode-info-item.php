<?php
/**
* 
*/
class Xuper_Theme_Helpers_Shortcode_Info_Item
{
	
	/**
	 * Brand slider item
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts ) {
		$atts = shortcode_atts( array(
			'title' => '',
		), $atts, 'nouxuper_info_item' );
		
		ob_start();
			if(!empty($atts['title'])):
				$html = $atts['title'];
				$html = str_replace('``', '"', $html);
				$html = str_replace('``', '"', $html);
				
				echo wp_kses_post(wpautop($html));
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand items.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Xuper - Info Item", 'xuper-theme-helpers' ),
	      	"base" => "nouxuper_info_item",
	      	"class" => "",
	      	"category" => esc_html__( "Xuper Theme", 'xuper-theme-helpers'),
	      	"content_element" => true,
    		"as_child" => array('only' => 'nouxuper_info'),
    		"params" => array(
		        array(
		            "type" => "textarea",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Content", 'xuper-theme-helpers' ),
		            "param_name" => "title",
		        ),
		     
	      	)
	    ) );
		endif;
	}
}
?>