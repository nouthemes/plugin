<?php
/**
* 
*/
class Xuper_Theme_Helpers_Shortcode_Banner_Masonry_Item
{
	
	/**
	 * Brand slider item
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts ) {
		$atts = shortcode_atts( array(
			'title' => '',
			'img' => '',
			'url' => '',
			'css' => '',
			'display' => '',
		), $atts, 'nouxuper_banner_masonry_item' );

		ob_start();
			if(!empty($atts['img'])):
				
				?>
				<div class="grid-item <?php if($atts['display']){echo esc_attr($atts['display']);}?> <?php if($atts['css']){echo esc_attr($atts['css']);}?>">
                    <div class="grid-item__content-wrapper">
                    	<a class="ps-collection" href="<?php echo esc_attr($atts['url']);?>">
                    		<?php
	                    	$image = wp_get_attachment_image_src($atts['img'], 'full');
							if($image){
	                    	?>
	                    	<img src="<?php echo esc_attr($image['0']);?>" alt="">
	                    	<?php }?>
                    	</a>
                    </div>
                </div>
				<?php
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand items.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Xuper - Banner Masonry Item", 'xuper-theme-helpers' ),
	      	"base" => "nouxuper_banner_masonry_item",
	      	"class" => "",
	      	"category" => esc_html__( "Xuper Theme", 'xuper-theme-helpers'),
	      	"content_element" => true,
    		"as_child" => array('only' => 'nouxuper_banner_masonry'),
    		"params" => array(
		        array(
		            "type" => "textarea",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", 'xuper-theme-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "attach_image",
		            "class" => "",
		            "heading" => esc_html__( "Image", 'xuper-theme-helpers' ),
		            "param_name" => "img",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "URL", 'xuper-theme-helpers' ),
		            "param_name" => "url",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "CSS class", 'xuper-theme-helpers' ),
		            "param_name" => "css",
		        ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "heading" => esc_html__( "Size of item show", 'xuper-theme-helpers' ),
		            "param_name" => "display",
		            "value" => array(
		            	esc_html__('Default', 'xuper-theme-helpers') => '', 
		            	esc_html__('Large', 'xuper-theme-helpers') => 'large', 
		            	esc_html__('High', 'xuper-theme-helpers') => 'high',
		            	esc_html__('Wide', 'xuper-theme-helpers') => 'wide',
		            ),
		    
		        ),
	      	)
	    ) );
		endif;
	}
}
?>