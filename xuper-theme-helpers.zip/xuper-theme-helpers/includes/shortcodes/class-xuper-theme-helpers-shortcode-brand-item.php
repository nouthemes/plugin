<?php
/**
* 
*/
class Xuper_Theme_Helpers_Shortcode_Brand_Item
{
	
	/**
	 * Brand slider item
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts ) {
		$atts = shortcode_atts( array(
			'img' => '',
			'url' => '',
		), $atts, 'nouxuper_brand_item' );
		
		ob_start();
			if(!empty($atts['img'])):
			?>
			<a href="<?php echo esc_attr($atts['url']);?>" target="_blank">
	           	<?php echo nouxuper_helpers_get_image_by_id($atts['img'], 'nouxuper_300x150');?>
	        </a>
			<?php
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand items.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Xuper - Brand Item", 'xuper-theme-helpers' ),
	      	"base" => "nouxuper_brand_item",
	      	"class" => "",
	      	"category" => esc_html__( "Xuper Theme", 'xuper-theme-helpers'),
	      	"content_element" => true,
    		"as_child" => array('only' => 'nouxuper_brand'),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", 'xuper-theme-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "attach_image",
		            "class" => "",
		            "heading" => esc_html__( "Image", 'xuper-theme-helpers' ),
		            "param_name" => "img",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "URL", 'xuper-theme-helpers' ),
		            "param_name" => "url",
		        )
	      	)
	    ) );
		endif;
	}
}
?>