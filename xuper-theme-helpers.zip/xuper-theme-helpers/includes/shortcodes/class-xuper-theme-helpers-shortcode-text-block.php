<?php
/**
* 
*/
class Xuper_Theme_Helpers_Shortcode_Text_Block
{
	
	public static function shortcode($atts, $content = ''){
		$atts = shortcode_atts( array(
			'title' => '',
			'desc' => '',
			'css' => '',
			'style' => 'icon',
			'icon' => '',
			'attributes' => '',
		), $atts, 'nouxuper_text_block' );
		
		$style = !empty($atts['style']) ? $atts['style'] : 'icon';
		$icon = !empty($atts['icon']) ? $atts['icon'] : '';
		$title = !empty($atts['title']) ? $atts['title'] : '';
		$desc = !empty($atts['desc']) ? $atts['desc'] : '';

		$css = !empty($atts['css']) ? $atts['css'] : '';

		$attributes = !empty($atts['attributes']) ? $atts['attributes'] : '';
		$attributes = str_replace('``', '"', $attributes);

		ob_start(); 
			if(!empty($desc)):
				switch ($style) {
					case 'icon':
						?>
		                <div class="ps-iconbox" <?php echo Xuper_Theme_Helpers_Unicode_Replace_Entities::UTF8entities(join(' ', explode(',', $attributes)));?>>
	                        <header><?php if(!empty($icon)){?><i class="<?php echo esc_attr($icon);?>"></i><?php }?>
	                            <?php echo wp_kses_post(wpautop($title));?>
	                        </header>
	                        <?php echo wp_kses_post(wpautop($desc));?>
	                    </div>
						<?php
						break;
					
					default:
						?>
						<?php if(!empty($css)){echo '<div class="'.esc_attr($css).'">';}?>
							<div class="ps-block--about" <?php echo Xuper_Theme_Helpers_Unicode_Replace_Entities::UTF8entities(join(' ', explode(',', $attributes)));?>>
				                <?php if(!empty($title)){?><h3 class="ps-heading"><?php echo esc_html($title);?></h3><?php }?>
				                <?php echo wp_kses_post(wpautop($desc));?>
				            </div>
				        <?php if(!empty($css)){echo '</div>';}?>
						<?php
						break;
				}
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Xuper - Text block", 'xuper-theme-helpers' ),
	      	"base" => "nouxuper_text_block",
	      	"class" => "",
	      	"category" => esc_html__( "Xuper Theme", 'xuper-theme-helpers'),
    		"params" => array(
		     
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "heading" => esc_html__( "Style", 'xuper-theme-helpers' ),
		            "param_name" => "style",
		            "value" => array(
		            	//esc_html__('Default', 'xuper-theme-helpers') => '', 
		            	esc_html__('With icon', 'xuper-theme-helpers') => 'icon', 
		            ),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Icon class", 'xuper-theme-helpers' ),
		            "description" => esc_html__( "Get icon from website fontawesome.io", 'xuper-theme-helpers' ),
		            "param_name" => "icon",
		            'dependency' => array(
						'element' => 'style',
						'value' => array('icon'),
					),
		        ),
		        array(
		            "type" => "textarea",
		            "holder" => "div",
		            "heading" => esc_html__( "Title", 'xuper-theme-helpers' ),
		            "param_name" => "title",
		        ),
		        
		        array(
		            "type" => "textarea",
		            "class" => "",
		            "heading" => esc_html__( "Description", 'xuper-theme-helpers' ),
		            "param_name" => "desc",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Custom class CSS", 'xuper-theme-helpers' ),
		            "param_name" => "css",
		            'group' => esc_html__('Attributes', 'xuper-theme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Custom attribute", 'xuper-theme-helpers' ),
		            'description' => esc_html__('Add custom attribute separated by commas, EX: data-mh="contact-1",data-mh="contact-2"', 'xuper-theme-helpers'),
		            "param_name" => "attributes",
		            'group' => esc_html__('Attributes', 'xuper-theme-helpers'),
		        ),
	      	)
	    ) );
		endif;
	}
}
