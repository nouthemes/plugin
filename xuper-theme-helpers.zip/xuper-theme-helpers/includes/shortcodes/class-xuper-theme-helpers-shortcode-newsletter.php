<?php
/**
* 
*/
class Xuper_Theme_Helpers_Shortcode_Newsletter
{
	
	public static function shortcode($atts, $content = ''){
		$atts = shortcode_atts( array(
			'title' => '',
			'desc' => '',
			'form' => '',
		), $atts, 'nouxuper_newsletter' );

		$form = '';
		if(!empty($atts['form'])){
			$form = $atts['form'];
			$form = str_replace('```}`', '"]', $form);
			$form = str_replace('`{`', '[', $form);
			$form = str_replace('``', '"', $form);
		}

		$title = '';
		if(!empty($atts['title'])){
			$title = $atts['title'];
		}

		$desc = '';
		if(!empty($atts['desc'])){
			$desc = $atts['desc'];
		}

		ob_start(); 
			?>
			<?php 
			if(!empty($form)):
				?>
				<div class="nouexist-subscribe ps-subscribe">
					<div class="nouexist-subscribe-message"></div>
	                <div class="row">
	                    <div class="col-md-6 col-sm-12 col-md-push-6">
	                        <div class="ps-subscribe__content"><i class="ps-icon-notify"></i>
	                            <?php if(!empty($title)){echo '<h3>'.esc_html($title).'</h3>';}?>
							    <?php echo wpautop($desc);?>
	                        </div>
	                    </div>
	                    <div class="col-md-6 col-sm-12 col-md-pull-6">
	                    	<div class="hidden"><?php if(!empty($form)){echo do_shortcode($form);}?></div>
	                        <form class="nouexist-subscribe-form ps-form--subscribe" method="post">
	                            <div class="form-group">
	                                <div class="form-group__icon"><i class="fa fa-envelope"></i></div>
	                                <input class="form-control" name="your_email" type="email" placeholder="<?php esc_html_e('Your Email Address', 'xuper-theme-helpers');?>">
	                            </div>
	                            <button class="btn-fake-subscribe"><i class="ps-icon-arrow-right"></i></button>
	                        </form>
	                    </div>
	                </div>
	            </div>
				<?php	
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Xuper - Newsletter", 'xuper-theme-helpers' ),
	      	"base" => "nouxuper_newsletter",
	      	"class" => "",
	      	"category" => esc_html__( "Xuper Theme", 'xuper-theme-helpers'),
    		"params" => array(
    			array(
		            "type" => "textfield",
		            "heading" => esc_html__( "Shortcode form MailChimp for WordPress", 'xuper-theme-helpers' ),
		            "param_name" => "form",
		        ),
    			array(
		            "type" => "textfield",
		            "holder" => "div",
		            "heading" => esc_html__( "Title", 'xuper-theme-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textarea",
		            "class" => "",
		            "heading" => esc_html__( "Description", 'xuper-theme-helpers' ),
		            "param_name" => "desc",
		        ),
    			
	      	)
	    ) );
		endif;
	}
}
