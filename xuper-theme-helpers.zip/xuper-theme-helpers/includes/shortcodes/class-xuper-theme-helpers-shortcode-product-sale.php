<?php
/**
* 
*/
class Xuper_Theme_Helpers_Shortcode_Product_Sale
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		if ( empty( $atts ) ) {
			return '';
		}

		$atts = shortcode_atts( array(
			'id' => '',
			'img' => '',
			'title' => '',
			'class' => '',
			'style' => '',
		), $atts, 'nouxuper_product_sale' );
		$style = !empty($atts['style']) ? $atts['style'] : '1';
		$html = '';

		if(!empty($atts['id'])):
		ob_start();
			$args = array(
				'post_type' => 'product', 
				'post_status' => 'publish',
				'p' => $atts['id']
			);
			$products = new WP_Query($args);
			if($products->have_posts()):
				while($products->have_posts()): $products->the_post();
					$product = wc_get_product(get_the_ID());
					if($product){
						$title = $product->get_name();
						if(!empty($atts['title'])){
							$title = $atts['title'];
						}
						$sales_price_to = get_post_meta($atts['id'], '_sale_price_dates_to', true);
						$image_id = $product->get_image_id();
						if(!empty($atts['img'])){
							$image_id = $atts['img'];
						}

						$images = wp_get_attachment_image_src($image_id, 'full');

						$class = implode( ' ', array_filter( array(
									            'button',
									            'product_type_' . $product->get_type(),
									            $product->is_purchasable() && $product->is_in_stock() ? 'add_to_cart_button' : '',
									            $product->supports( 'ajax_add_to_cart' ) ? 'ajax_add_to_cart' : '',
									        ) ) );
						?>
						<div class="product <?php echo esc_attr(!empty($atts['class']) ? $atts['class'] : '');?>"  data-id="<?php the_ID();?>" data-url="<?php the_permalink();?>" data-title="<?php the_title();?>">
							<?php
							switch ($style) {
								case '2':
									?>
									<div class="ps-section ps-section--offer-2">
								        <div class="ps-container">
								            <div class="ps-block--offer">
								                <div class="ps-block__left bg--cover" data-background="<?php echo esc_attr($images['0']);?>"></div>
								                <div class="ps-block__right">
								                    <?php echo wp_kses_post(wpautop($title));?>

								                    <?php if(!empty($sales_price_to)):?>
								                    <ul class="ps-countdown" data-time="<?php echo esc_attr(date("F d, Y", $sales_price_to));?> 23:59:59">
								                        <li><span class="days"></span>
								                            <p><?php esc_html_e('Days', 'xuper-theme-helpers');?></p>
								                        </li>
								                        <li class="divider">:</li>
								                        <li><span class="hours"></span>
								                            <p><?php esc_html_e('Hours', 'xuper-theme-helpers');?></p>
								                        </li>
								                        <li class="divider">:</li>
								                        <li><span class="minutes"></span>
								                            <p><?php esc_html_e('minutes', 'xuper-theme-helpers');?></p>
								                        </li>
								                        <li class="divider">:</li>
								                        <li><span class="seconds"></span>
								                            <p><?php esc_html_e('Seconds', 'xuper-theme-helpers');?></p>
								                        </li>
								                    </ul>
								                    <?php endif;?>

								                    <?php
											      	echo apply_filters( 'xuper_shortcode_sale_product_add_to_cart_link',
														sprintf( '<a rel="nofollow" href="%s" data-quantity="%s" data-product_id="%s" data-product_sku="%s" class="ps-btn ps-btn--yellow product-item-cart %s">%s</a>',
															esc_url( $product->add_to_cart_url() ),
															esc_attr( isset( $quantity ) ? $quantity : 1 ),
															esc_attr( $product->get_id() ),
															esc_attr( $product->get_sku() ),
															esc_attr( isset( $class ) ? $class : 'button' ),
															esc_html( 'Order Now', 'xuper-theme-helpers' )
														),
													$product );
											      	?>
								                </div>
								            </div>
								        </div>
								    </div>
									<?php
									break;
								case '3':
									?>
									<div class="ps-section--offer-3 bg--cover" data-background="<?php echo esc_attr($images['0']);?>">
								        <div class="container">
								            <?php echo wp_kses_post(wpautop($title));?>

								            <?php if(!empty($sales_price_to)):?>
								            <ul class="ps-countdown ps-countdown--fashion" data-time="<?php echo esc_attr(date("F d, Y", $sales_price_to));?> 23:59:59">
						                        <li><span class="days"></span>
						                            <p><?php esc_html_e('Days', 'xuper-theme-helpers');?></p>
						                        </li>
						                        <li><span class="hours"></span>
						                            <p><?php esc_html_e('Hours', 'xuper-theme-helpers');?></p>
						                        </li>
						                        <li><span class="minutes"></span>
						                            <p><?php esc_html_e('minutes', 'xuper-theme-helpers');?></p>
						                        </li>
						                        <li><span class="seconds"></span>
						                            <p><?php esc_html_e('Seconds', 'xuper-theme-helpers');?></p>
						                        </li>
						                    </ul>
								            <?php endif;?>
								            
						                    <?php
									      	echo apply_filters( 'xuper_shortcode_sale_product_add_to_cart_link',
												sprintf( '<a rel="nofollow" href="%s" data-quantity="%s" data-product_id="%s" data-product_sku="%s" class="ps-btn product-item-cart %s">%s</a>',
													esc_url( $product->add_to_cart_url() ),
													esc_attr( isset( $quantity ) ? $quantity : 1 ),
													esc_attr( $product->get_id() ),
													esc_attr( $product->get_sku() ),
													esc_attr( isset( $class ) ? $class : 'button' ),
													esc_html( 'Order Now', 'xuper-theme-helpers' )
												),
											$product );
									      	?>
								        </div>
								    </div>
									<?php
									break;
								default:
									?>
									<div class="ps-section--offer-1">
								        <div class="container">
								            <div class="ps-block--offer-fashion">
								                <div class="ps-block__left bg--cover" data-background="<?php echo esc_attr($images['0']);?>"></div>
								                <div class="ps-block__right">
								                    <?php echo wp_kses_post(wpautop($title));?>

								                    <?php if(!empty($sales_price_to)):?>
								                    <ul class="ps-countdown ps-countdown--fashion" data-time="<?php echo esc_attr(date("F d, Y", $sales_price_to));?> 23:59:59">
								                        <li><span class="days"></span>
								                            <p><?php esc_html_e('Days', 'xuper-theme-helpers');?></p>
								                        </li>
								                        <li><span class="hours"></span>
								                            <p><?php esc_html_e('Hours', 'xuper-theme-helpers');?></p>
								                        </li>
								                        <li><span class="minutes"></span>
								                            <p><?php esc_html_e('minutes', 'xuper-theme-helpers');?></p>
								                        </li>
								                        <li><span class="seconds"></span>
								                            <p><?php esc_html_e('Seconds', 'xuper-theme-helpers');?></p>
								                        </li>
								                    </ul>
								                    <?php endif;?>
								                    <?php
											      	echo apply_filters( 'xuper_shortcode_sale_product_add_to_cart_link',
														sprintf( '<a rel="nofollow" href="%s" data-quantity="%s" data-product_id="%s" data-product_sku="%s" class="ps-btn--outline product-item-cart %s">%s</a>',
															esc_url( $product->add_to_cart_url() ),
															esc_attr( isset( $quantity ) ? $quantity : 1 ),
															esc_attr( $product->get_id() ),
															esc_attr( $product->get_sku() ),
															esc_attr( isset( $class ) ? $class : 'button' ),
															esc_html( 'Order Now', 'xuper-theme-helpers' )
														),
													$product );
											      	?>
								                </div>
								            </div>
								        </div>
								    </div>
									<?php
									break;
							}
						?>
						</div>
						<?php
					}
				endwhile;
			endif; wp_reset_postdata();
		$html = ob_get_clean();
		endif;

		return $html;
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Xuper - Product sale", 'xuper-theme-helpers' ),
	      	"base" => "nouxuper_product_sale",
	      	"class" => "",
	      	"category" => esc_html__( "Xuper Theme", 'xuper-theme-helpers'),
	      	"params" => array(
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Product ID", 'xuper-theme-helpers' ),
		            "param_name" => "id",
		            "holder" => "div",
		        ),
		        array(
		            "type" => "textarea",
		            "class" => "",
		            "holder" => "div",
		            "heading" => esc_html__( "Content", 'xuper-theme-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "attach_image",
		            "class" => "",
		            "heading" => esc_html__( "Image", 'xuper-theme-helpers' ),
		            "param_name" => "img",
		            'description' => esc_html__('If used this image, it will replace the default.', 'bakery-helpers'),
		        ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "heading" => esc_html__( "Type of item show", 'xuper-theme-helpers' ),
		            "param_name" => "style",
		            "value" => array(
		            	esc_html__('Style #1', 'xuper-theme-helpers') => '1', 
		            	esc_html__('Style #2', 'xuper-theme-helpers') => '2', 
		            	esc_html__('Style #3', 'xuper-theme-helpers') => '3', 
		            ),
		        ),
	      	)
	    ) );
		endif;
	}
}
?>