<?php
/**
* 
*/
class Xuper_Theme_Helpers_Shortcode_Banner
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		
		$atts = shortcode_atts( array(
			'title' => '',
			'img' => '',
			'btn_text' => '',
			'url' => '',
		), $atts, 'nouxuper_banner' );
		

		ob_start();
			if(!empty($atts['img'])):
				$image = wp_get_attachment_image_src($atts['img'], 'full');
				?>
				<div class="ps-section ps-section--campaign pt-30 pb-70">
			        <div class="ps-container">
			            <div class="ps-post--campaign">
			                <div class="ps-post__thumbnail bg--cover" data-background="<?php echo esc_attr($image['0']);?>"><a class="ps-post__overlay" href="<?php echo esc_url($atts['url']);?>"></a></div>
			                <div class="ps-post__content">
			                    <?php if(!empty($atts['title'])){echo wp_kses_post(wpautop($atts['title']));}?>

			                    <?php if(!empty($atts['btn_text'])){?>
			                    <a class="ps-post__morelink" href="<?php echo esc_url($atts['url']);?>"><?php echo esc_html($atts['btn_text']);?></a>
			                    <?php }?>
			                </div>
			            </div>
			        </div>
			    </div>
				<?php
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Post items.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Xuper - Banner", 'xuper-theme-helpers' ),
	      	"base" => "nouxuper_banner",
	      	"class" => "",
	      	"category" => esc_html__( "Xuper Theme", 'xuper-theme-helpers'),
    		"params" => array(
		        array(
		            "type" => "textarea",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Content", 'xuper-theme-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "attach_image",
		            "class" => "",
		            "heading" => esc_html__( "Image", 'xuper-theme-helpers' ),
		            "param_name" => "img",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Button text", 'xuper-theme-helpers' ),
		            "param_name" => "btn_text",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "URL", 'xuper-theme-helpers' ),
		            "param_name" => "url",
		        ),
	      	)
	    ) );
		endif;
	}
}
?>