<?php
/**
* 
*/
class Xuper_Theme_Helpers_Shortcode_Posts
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		if(empty($atts)){
			return '';
		}

		$atts = shortcode_atts( array(
			'title' => '',
			'desc' => '',
			'ids' => '',
			'cat' => '',
			'number' => '',
		), $atts, 'nouxuper_posts' );
		
		$per_page = !empty($atts['number']) ? intval($atts['number']) : '3';
		$args = array(
			'post_type' => 'post', 
			'post_status' => 'publish',
			'ignore_sticky_posts' => true,
			'posts_per_page' => $per_page
			);

		if(!empty($atts['ids'])){
			$args['post__in'] = explode(',', $atts['ids']);
		}else{
			if(!empty($atts['cat'])){
				$args['tax_query'] = array(
					array(
						'taxonomy' => 'category',
						'field'    => 'term_id',
						'terms'    => $atts['cat'],
					),
				);
			}
		}

		$post_class = 'ps-post ps-post--home';
		if(is_page_template('page-templates/home-left.php')){
			$post_class = 'ps-post ps-post--home ps-post--jewelry';
		}

		$query = new WP_Query($args);
		ob_start();
			if($query->have_posts()):

				$link = home_url('/');
				$show_on_front = get_option('show_on_front');
				if($show_on_front == 'page'){
					$link = get_permalink(get_option('page_for_posts'));
				}
				$size = 'nouxuper_397x255';
				if(is_page_template('page-templates/home-left.php')){
					$size = 'nouxuper_251x142';
				}
				?>
				<div class="ps-section">
        			<div class="ps-container<?php if(is_page_template('page-templates/home-left.php')){echo '-left';}?>">
		                <div class="ps-section__header text-center">
		                    <?php if(!empty($atts['title'])){?>
		                    	<h2 class="ps-section__title"><?php echo esc_html($atts['title']);?></h2>
		                    <?php }?>
		                    <?php if(!empty($atts['desc'])){?>
		                    	<?php echo wp_kses_post(wpautop($atts['desc']));?>
		                    <?php }?>
		                </div>
	                    <div class="ps-section__content">
                			<div class="row">
		                        <?php while($query->have_posts()): $query->the_post();?>
			                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 ">
			                            <div id="shortcode-post-<?php the_ID(); ?>" <?php post_class($post_class);?>>
			                            	
			                            	<?php if(has_post_thumbnail()){?>
			                            	<div class="ps-post__thumbnail">
			                            		<div class="ps-post__posted"><span class="date"><?php echo get_the_date('d');?></span><span class="month"><?php echo get_the_date('M');?></span></div>
				                                <a class="ps-post__overlay" href="<?php the_permalink();?>"></a>
				                                <?php the_post_thumbnail($size, array('class' => 'lazy'));?>
				                            </div>
				                            <?php }?>

				                            <div class="ps-post__content">
				                            	<a class="ps-post__title" href="<?php the_permalink();?>"><?php the_title();?></a>
				                                <?php nouxuper_post_meta();?>
				                                <?php if('gallery' != get_post_format()):?>
										        	<?php echo wp_kses_post(wpautop(nouxuper_word_count(get_the_excerpt(), 20))); ?>
										      	<?php endif;?>
				                                <a class="ps-post__morelink" href="<?php the_permalink();?>"><?php esc_html_e('Read more', 'xuper-theme-helpers');?><i class="ps-icon-arrow-right"></i></a>
				                            </div>
										</div>
			                        </div>
		                        <?php endwhile;?>
	                        </div>
	                    </div>
		            </div>
		        </div>
				<?php
			endif;wp_reset_postdata();
		return ob_get_clean();
	}

	/**
	 * Map shortcode Post items.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Xuper - Posts", 'xuper-theme-helpers' ),
	      	"base" => "nouxuper_posts",
	      	"class" => "",
	      	"category" => esc_html__( "Xuper Theme", 'xuper-theme-helpers'),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", 'xuper-theme-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Description", 'xuper-theme-helpers' ),
		            "param_name" => "desc",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "IDs posts, EX: 21,22,23", 'xuper-theme-helpers' ),
		            "param_name" => "ids",
		            'group' => esc_html__('Display', 'xuper-theme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Category ID", 'xuper-theme-helpers' ),
		            "param_name" => "cat",
		            'group' => esc_html__('Display', 'xuper-theme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Number of posts show(default 3)", 'xuper-theme-helpers' ),
		            "param_name" => "number",
		            'group' => esc_html__('Display', 'xuper-theme-helpers'),
		        ),
	      	)
	    ) );
		endif;
	}
}
?>