<?php
/**
* 
*/
class Xuper_Theme_Helpers_Shortcode_Banner_Masonry
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		$atts = shortcode_atts( array(
			'md_col' => '',
			'sm_col' => '',
			'xs_col' => '',
			'gap' => '',
			'radio' => '',
			'css' => '',
		), $atts, 'nouxuper_banner_masonry' );

		$md_col = !empty($atts['md_col']) ? $atts['md_col']: '4';
		$sm_col = !empty($atts['sm_col']) ? $atts['sm_col']: '2';
		$xs_col = !empty($atts['xs_col']) ? $atts['xs_col']: '1';
		$gap = !empty($atts['gap']) ? $atts['gap']: '0';
		$radio = !empty($atts['radio']) ? $atts['radio']: '4:3';
		$css = !empty($atts['css']) ? $atts['css']: '';

		ob_start();
			if(!empty($content)):
				?>
				<?php if(!empty($css)){?><div class="<?php echo esc_attr($css);?>"><?php }?>
				    <div class="ps-section--collection">
				        <div class="masonry-wrapper" data-col-md="<?php echo esc_attr($md_col);?>" data-col-sm="<?php echo esc_attr($sm_col);?>" data-col-xs="<?php echo esc_attr($xs_col);?>" data-gap="<?php echo esc_attr($gap);?>" data-radio="<?php echo esc_attr($radio);?>">
				          <div class="ps-masonry">
				            <div class="grid-sizer"></div>
				            <?php echo do_shortcode($content);?>
				          </div>
				        </div>
				    </div>
				<?php if(!empty($css)){?></div><?php }?>
				<?php
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Xuper - Banner Masonry", 'xuper-theme-helpers' ),
	      	"base" => "nouxuper_banner_masonry",
	      	"class" => "",
	      	"category" => esc_html__( "Xuper Theme", 'xuper-theme-helpers'),
	      	"params" => array(
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Column desktops screen", 'xuper-theme-helpers' ),
		            "param_name" => "md_col",
		            'value' => '4',
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Column tablets screen", 'xuper-theme-helpers' ),
		            "param_name" => "sm_col",
		            'value' => '2',
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Column phones screen", 'xuper-theme-helpers' ),
		            "param_name" => "xs_col",
		            'value' => '1',
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Data-gap", 'xuper-theme-helpers' ),
		            'description' => esc_html__('Value from 5 to 100, step 5.'),
		            "param_name" => "gap",
		            'value' => '0'
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Data-radio", 'xuper-theme-helpers' ),
		            "param_name" => "radio",
		            'value' => '4:3'
		        ),

		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Custom class css", 'xuper-theme-helpers' ),
		            "param_name" => "css",
		            'group' => esc_html__('Style', 'xuper-theme-helpers'),
		        ),
	      	),
	      	"as_parent" => array('only' => 'nouxuper_banner_masonry_item'),
	      	"content_element" => true,
		    "show_settings_on_create" => false,
		    "is_container" => true,
		    "js_view" => 'VcColumnView'
	    ) );
		endif;
	}
}
?>