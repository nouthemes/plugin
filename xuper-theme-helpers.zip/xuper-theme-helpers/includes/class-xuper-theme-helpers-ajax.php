<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://themeforest.net/user/nouthemes/portfolio
 * @since      1.0.0
 *
 * @package    Xuper_Theme_Helpers
 * @subpackage Xuper_Theme_Helpers/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Xuper_Theme_Helpers
 * @subpackage Xuper_Theme_Helpers/admin
 * @author     Noutheme <nouthemes@gmail.com>
 */
class Xuper_Theme_Helpers_Ajax {

	/**
	 * Hook in ajax handlers.
	 */
	public static function init() 
	{
		self::add_ajax_events();
	}

	/**
	 * Hook in methods - uses WordPress ajax handlers (admin-ajax).
	 */
	public static function add_ajax_events() 
	{
		
		$ajax_events = array(
			'remove_product_from_lists',
			'load_more_products',
			'wishlist',
			'compare',
			'load_more_portfolios',
			'load_more_products_shortcode',
			'remove_product_from_cart',
			'post_like'
		);

		foreach ( $ajax_events as $ajax_event ) {
			add_action( 'wp_ajax_nouxuper_helpers_' . $ajax_event, array( __CLASS__, $ajax_event ) );
			add_action( 'wp_ajax_nopriv_nouxuper_helpers_' . $ajax_event, array( __CLASS__, $ajax_event ) );
		}
	}

	public static function remove_product_from_cart(){
		$status = array('status' => '0', 'html' => '');
		if( !empty($_POST['cart_item_key']) && !empty($_POST['product_id']) && !empty($_POST['nonce'] ) && wp_verify_nonce( $_POST['nonce'], 'nouxuper-theme-nonce' ) ){
			$id = $_POST['product_id'];
			if ( $cart_item = WC()->cart->get_cart_item( $_POST['cart_item_key'] ) ) {
				WC()->cart->remove_cart_item( $_POST['cart_item_key'] );
				$product = wc_get_product( $_POST['product_id'] );
				$removed_notice  = sprintf( __( '%s removed.', 'xuper-theme-helpers' ), $product->get_name() );
				wc_add_notice( $removed_notice );
				$status['status'] = 1;
				ob_start();
					nouxuper_woocommerce_cart_link();
				$status['html'] = ob_get_clean();
			}
		}

		wp_send_json($status);
	}

	public static function load_more_products_shortcode(){
		$status = array('status' => '0', 'html' => '');
		if( !empty($_POST['page']) && !empty($_POST['nonce'] ) && wp_verify_nonce( $_POST['nonce'], 'nouxuper-theme-nonce' ) ){
			
			if($_POST['shortcode'] == 'nouxuper_products'){

				$atts = array(
					'type' => !empty($_POST['query_type']) ? $_POST['query_type'] : 'recent',
					'ids' => !empty($_POST['ids']) ? $_POST['ids'] : '',
					'cat' => !empty($_POST['cat']) ? $_POST['cat'] : '',
					'number' => !empty($_POST['number']) ? $_POST['number'] : '',
					'order_by' => !empty($_POST['order_by']) ? $_POST['order_by'] : '',
					'paged' => $_POST['page']
					);
				$shortcode_id = !empty($_POST['shortcode_id']) ? $_POST['shortcode_id'] : '';
				$style = !empty($_POST['style']) ? $_POST['style'] : 'grid';
				$number = !empty($_POST['number']) ? $_POST['number'] : get_option('posts_per_page');
				$products = nouxuper_get_products($atts);
				if($products->have_posts()){
					$status['status'] = 1;
					ob_start();
					$i = $number;
					$shop = nouxuper_shop_style();
					while($products->have_posts()): $products->the_post();$i++;?>
						<?php if($style == 'masonry'):?>
							<?php 
							$custom_item = '';
							if( $i == ($number+2) ){
								$custom_item = ' large';
							}
							?>
							<div <?php post_class('grid-item '.$custom_item);?> data-id="<?php the_ID();?>" data-url="<?php the_permalink();?>" data-title="<?php the_title();?>">
				              	<div class="grid-item__content-wrapper">
				                    <div class="ps-product--metro">
				                      <div class="ps-product__thumbnail">

				                      	<?php woocommerce_show_product_loop_sale_flash();?>

						            	<a href="<?php the_permalink();?>">
								            <?php 
								            if(!empty($custom_item)){
								            	$size = 'nouxuper_546x694';
								            }else{
								            	$size = 'nouxuper_263x336';
								            }
								            the_post_thumbnail($size);
								            ?>
								        </a>

						            	<?php if(!empty($shop['addtocart'])):?>                    
							              	<?php woocommerce_template_loop_add_to_cart();?>
							          	<?php endif;?>

							            <?php do_action( 'nouxuper_shop_loop_item_social' );?>
				                      </div>
				                      <div class="ps-product__content">
				                      		<a class="ps-product__title" href="<?php the_permalink();?>"> <?php the_title();?></a>
    										<?php woocommerce_template_loop_price();?>
				                      </div>
				                    </div>
				              	</div>
				            </div>
				        <?php elseif($style == 'grid_filter'):?>
				        	<div class="ps-product-column">
				                  <div <?php post_class('ps-product--1'); ?> data-id="<?php the_ID();?>" data-url="<?php the_permalink();?>" data-title="<?php the_title();?>" data-mh="product-item-<?php echo esc_attr($shortcode_id);?>">
				                    <div class="ps-product__thumbnail">
				                    	<?php woocommerce_show_product_loop_sale_flash();?>
								        <a href="<?php the_permalink();?>">
								            <?php the_post_thumbnail('nouxuper_198x254');?>
								        </a>
								          
								        <?php if(!empty($shop['addtocart'])):?>
								            <?php woocommerce_template_loop_add_to_cart();?>
								        <?php endif;?>


								        <?php do_action( 'nouxuper_shop_loop_item_social' );?>
				                    </div>
				                    <div class="ps-product__content">
				                    	<a class="ps-product__title" href="<?php the_permalink();?>"> <?php the_title();?></a>
										<?php woocommerce_template_loop_price();?>
				                    </div>
				                  </div>
				            </div>
						<?php else:?>
			            	<div <?php post_class('col-lg-3 col-md-4 col-sm-6 col-xs-12'); ?> data-id="<?php the_ID();?>" data-url="<?php the_permalink();?>" data-title="<?php the_title();?>">
			                      <div class="ps-product--1" data-mh="product-item-<?php echo esc_attr($shortcode_id);?>">
			                        <div class="ps-product__thumbnail">
			                        	<?php woocommerce_show_product_loop_sale_flash();?>
								        <a href="<?php the_permalink();?>">
								            <?php the_post_thumbnail('nouxuper_256x326');?>
								        </a>
								          
								        <?php if(!empty($shop['addtocart'])):?>
								            <?php woocommerce_template_loop_add_to_cart();?>
								        <?php endif;?>


								        <?php do_action( 'nouxuper_shop_loop_item_social' );?>
			                        </div>
			                        <div class="ps-product__content">
			                        	<a class="ps-product__title" href="<?php the_permalink();?>"> <?php the_title();?></a>
										<?php woocommerce_template_loop_price();?>
			                        </div>
			                      </div>
			                </div>
			            <?php endif;?>
		           <?php endwhile;
		           $status['html'] = ob_get_clean();
				}wp_reset_postdata();
			}

		}
		wp_send_json($status);
		exit();
	}

	public static function load_more_products(){
		$status = array('status' => '0', 'html' => '');
		if( !empty($_POST['page']) && !empty($_POST['nonce'] ) && wp_verify_nonce( $_POST['nonce'], 'nouxuper-theme-nonce' ) ){
			
			$data = !empty($_SESSION['nouxuper_filter_products']) ? $_SESSION['nouxuper_filter_products'] : array();
			$col = !empty($_POST['columns']) ? intval($_POST['columns']) : $data['col'];

			$args = array(
				'post_type' => 'product', 
				'post_status' => 'publish',
				'posts_per_page' => $data['posts_per_page'],
				'paged' => intval($_POST['page']),
			);

			if(!empty($data) && is_array($data)){

				if($data['type'] == 'attribute'){
					$args['tax_query']['relation'] = 'AND';
					foreach ( $data['params'] as $key => $value ) {
						$args['tax_query'][] = array(
								'taxonomy' => $key,
								'field'    => 'slug',
								'terms'    => $value,
							);
					}
				}

				if($data['type'] == 'tax'){
					foreach ( $data['params'] as $key => $value ) {
						$args['tax_query'][] = array(
								'taxonomy' => $key,
								'field'    => 'slug',
								'terms'    => $value,
							);
					}
				}

			}

			$orderby_value = isset( $_GET['orderby'] ) ? wc_clean( (string) $_GET['orderby'] ) : apply_filters( 'woocommerce_default_catalog_orderby', get_option( 'woocommerce_default_catalog_orderby' ) );

			// Get order + orderby args from string
			$orderby_value = explode( '-', $orderby_value );
			$orderby       = esc_attr( $orderby_value[0] );
			$order         = ! empty( $orderby_value[1] ) ? $orderby_value[1] : $order;

			$orderby = strtolower( $orderby );
			$order   = strtoupper( $order );

			if ( ! is_search() ) {
				$args['orderby']  = 'menu_order title';
				$args['order']    = ( 'DESC' === $order ) ? 'DESC' : 'ASC';
				$args['meta_key'] = '';
			}

			switch ( $orderby ) {
				case 'rand' :
					$args['orderby']  = 'rand';
					break;
				case 'date' :
					$args['orderby']  = 'date ID';
					$args['order']    = ( 'ASC' === $order ) ? 'ASC' : 'DESC';
					break;
				case 'popularity' :
					$args['meta_key'] = 'total_sales';
					break;
				case 'rating' :
					$args['meta_key'] = '_wc_average_rating';
					$args['orderby']  = array(
						'meta_value_num' => 'DESC',
						'ID'             => 'ASC',
					);
					break;
				case 'title' :
					$args['orderby'] = 'title';
					$args['order']   = ( 'DESC' === $order ) ? 'DESC' : 'ASC';
					break;
				case 'relevance' :
					$args['orderby'] = 'relevance';
					$args['order']   = 'DESC';
					break;
			}
			$query = new WP_Query($args);
			if($query->have_posts()){
				$status['status'] = 1;

				ob_start();
					$i = $data['posts_per_page'];
					while($query->have_posts()){ $query->the_post();
						$shop = nouxuper_shop_style();
						if($shop['layout'] == '1'){
							if($col != '5'){
								$class_col = 'col-lg-'.intval(12/$col).' col-md-'.intval(12/$col).' col-sm-6 col-xs-12';
							}else{
								$class_col = 'ps-product-column';
							}
							?>
							<div <?php post_class($class_col); ?> data-id="<?php the_ID();?>" data-url="<?php the_permalink();?>" data-title="<?php the_title();?>">
							      <div class="ps-product--1" data-mh="product-item">
							        <div class="ps-product__thumbnail">
							        	<?php woocommerce_show_product_loop_sale_flash();?>
							        	<a href="<?php the_permalink();?>">
										    <?php 
									          if(has_post_thumbnail()){
									          	$shop = nouxuper_shop_style();
												$sidebar = false;
												if(!empty($shop['sidebar']) && $shop['sidebar'] != 'hide'){
													if( is_active_sidebar('shop-sidebar') ){
														$sidebar = true;
													}
												}
									          	switch ($col) {
													case '4':
														# code...
														$size = 'nouxuper_263x336';
														if($sidebar){
															$size = 'nouxuper_160x205';
														}
														break;
													case '5':
														# code...
														$size = 'nouxuper_198x254';
														if($sidebar){
															$size = 'nouxuper_160x205';
														}
														break;
													case '6':
														# code...
														$size = 'nouxuper_160x205';
														if($sidebar){
															$size = 'nouxuper_160x205';
														}
														break;
													default:
														# code...
														$size = 'nouxuper_350x448';
														if($sidebar){
															$size = 'nouxuper_263x336';
														}
														break;
												}
									          	the_post_thumbnail($size);
									          }else{
									          	woocommerce_template_loop_product_thumbnail();
									          }
							          		?>
							          	</a>
							          <?php if(!empty($shop['addtocart'])):?>                    
							              <?php woocommerce_template_loop_add_to_cart();?>
							          <?php endif;?>


							          <?php do_action( 'nouxuper_shop_loop_item_social' );?>
							          
							        </div>
							        <div class="ps-product__content">
							        	<a class="ps-product__title" href="<?php the_permalink();?>"> <?php the_title();?></a>
							        	<?php woocommerce_template_loop_price();?>
							        </div>
							      </div>
							</div>
							<?php
						}else{
							$custom_item = '';
							if($shop['layout'] == '2'){
								if( $i == '1' ){
									$custom_item = ' large';
								}else{
									if($i != 0 && $i % 10 == 0){
										$custom_item = ' large';
									}
								}
							}else{
								if( $i == '0' ){
									$custom_item = ' large';
								}else{
									if($i != 0 && $i % 5 == 0){
										$custom_item = ' large';
									}
								}
							}
							?>
							<div <?php post_class('grid-item '.$custom_item);?> data-id="<?php the_ID();?>" data-url="<?php the_permalink();?>" data-title="<?php the_title();?>">
							    <div class="grid-item__content-wrapper">
							          <div class="ps-product--metro">
							            <div class="ps-product__thumbnail">

							            	<?php woocommerce_show_product_loop_sale_flash();?>

							            	<a href="<?php the_permalink();?>">
									            <?php
									            if(!empty($custom_item)){
									            	if(has_post_thumbnail()){
											          	the_post_thumbnail('nouxuper_546x694');
											        }
									            }else{
										          	woocommerce_template_loop_product_thumbnail();
										        }
								          		?>
									        </a>

							            	<?php if(!empty($shop['addtocart'])):?>                    
								              	<?php woocommerce_template_loop_add_to_cart();?>
								          	<?php endif;?>

								            <?php do_action( 'nouxuper_shop_loop_item_social' );?>

							            </div>
							            <div class="ps-product__content">
							            	<a class="ps-product__title" href="<?php the_permalink();?>"> <?php the_title();?></a>
							            	<?php woocommerce_template_loop_price();?>
							            </div>
							          </div>
							    </div>
							</div>
							<?php
						}
						$i++;
					}
				$status['html'] = ob_get_clean();

			}wp_reset_postdata();

		}
		wp_send_json($status);
		exit();
	}


	public static function remove_product_from_lists(){
		$status = array('status' => '0', 'html' => '');
		if( !empty($_POST['product_id']) && !empty($_POST['type'] ) && !empty($_POST['nonce'] ) && wp_verify_nonce( $_POST['nonce'], 'nouxuper-theme-nonce' ) ){

			switch ($_POST['type']) {
				case 'wishlist':
					$delete = Xuper_Theme_Helpers_Wishlist::delete($_POST['product_id']);
					$status['status'] = $delete;
					break;
				case 'compare':
					$delete = Xuper_Theme_Helpers_Compare::delete($_POST['product_id']);
					$status['status'] = $delete;
					break;
			}
		}
		wp_send_json($status);
		exit();
	}

	public static function wishlist(){
		$status = array('status' => '0', 'html' => '');
		if( !empty($_POST['product_id'] ) && !empty($_POST['nonce'] ) && wp_verify_nonce( $_POST['nonce'], 'nouxuper-theme-nonce' ) ){
			$wishlist = true;
			switch ($_POST['do_action']) {
				case 'add':
					$wishlist = Xuper_Theme_Helpers_Wishlist::add($_POST['product_id']);
					if($wishlist){
						$status['html'] = esc_html__('added to wishlist.', 'xuper-theme-helpers');
					}else{
						$status['html'] = esc_html__('has exists in wishlist.', 'xuper-theme-helpers');
					}
					break;
				case 'delete':
					$wishlist = Xuper_Theme_Helpers_Wishlist::delete($_POST['product_id']);
					if($wishlist){
						$status['html'] = esc_html__('Delete from wishlist successfully.', 'xuper-theme-helpers');
					}else{
						$status['html'] = esc_html__('not exists in wishlist.', 'xuper-theme-helpers');
					}
					break;
			}

			if($wishlist){
				$status['status'] = '1';
			}
		}
		wp_send_json($status);
		exit();
	}

	public static function compare(){
		$status = array('status' => '0', 'html' => '');
		if( !empty($_POST['product_id']) && !empty($_POST['nonce']) && wp_verify_nonce( $_POST['nonce'], 'nouxuper-theme-nonce' ) ){
			$compare = false;
			switch ($_POST['do_action']) {
				case 'add':
					$compare = Xuper_Theme_Helpers_Compare::add($_POST['product_id']);
					if($compare){
						$status['html'] = esc_html__('added to compare.', 'xuper-theme-helpers');
					}else{
						$status['html'] = esc_html__('has exists in compare list.', 'xuper-theme-helpers');
					}
					$status['product_id'] = $compare;
					break;
				case 'delete':
					$compare = Xuper_Theme_Helpers_Compare::delete($_POST['product_id']);
					if($compare){
						$status['html'] = esc_html__('Delete from compare list successfully.', 'xuper-theme-helpers');
					}else{
						$status['html'] = esc_html__('not exists in compare list.', 'xuper-theme-helpers');
					}
					break;
			}

			if($compare){
				$status['status'] = '1';
			}
		}
		wp_send_json($status);
		exit();
	}

	public static function post_like(){
		$response = array('status' => '0', 'button' => $_POST['post_id']);
		if( !empty($_POST['post_id']) && !empty($_POST['security']) && wp_verify_nonce( $_POST['security'], 'nouxuper-theme-nonce' ) ){
			// Test if javascript is disabled
			$disabled = false;
			// Test if this is a comment
			$is_comment = 1;
			// Base variables
			$post_id = intval($_POST['post_id']);
			$post_users = NULL;
			$like_count = 0;

			$count = get_post_meta( $post_id, "_post_like_count", true );
			$count = !empty($count) ? $count : 0;

			$likestatus = xuper_helpers_already_liked($post_id);
			if ($likestatus != true) {

				if ( is_user_logged_in() ) { // user is logged in
					$user_id = get_current_user_id();
					$post_users = xuper_helpers_post_user_likes( $user_id, $post_id );
					
					// Update User & Post
					$user_like_count = get_user_option( "_user_like_count", $user_id );
					$user_like_count =  ( isset( $user_like_count ) && is_numeric( $user_like_count ) ) ? $user_like_count : 0;
					update_user_option( $user_id, "_user_like_count", ++$user_like_count );
					
					if ( $post_users ) {
						update_post_meta( $post_id, "_user_liked", $post_users );
					}

				} else { // user is anonymous

					$user_ip = xuper_helpers_get_ip();
					$post_users = xuper_helpers_post_ip_likes( $user_ip, $post_id, $is_comment );
					
					// Update Post
					if ( $post_users ) {
						update_post_meta( $post_id, "_user_IP", $post_users );
					}

				}

				$like_count = ++$count;
				$response['status'] = "liked";

			}else{
				if ( is_user_logged_in() ) { // user is logged in
					$user_id = get_current_user_id();
					$post_users = xuper_helpers_post_user_likes( $user_id, $post_id );
					// Update User
					$user_like_count = get_user_option( "_user_like_count", $user_id );
					$user_like_count =  ( isset( $user_like_count ) && is_numeric( $user_like_count ) ) ? $user_like_count : 0;
					if ( $user_like_count > 0 ) {
						update_user_option( $user_id, '_user_like_count', --$user_like_count );
					}

					// Update Post
					if ( $post_users ) {	
						$uid_key = array_search( $user_id, $post_users );
						unset( $post_users[$uid_key] );
						update_post_meta( $post_id, "_user_liked", $post_users );
					}
				} else { // user is anonymous
					$user_ip = xuper_helpers_get_ip();
					$post_users = xuper_helpers_post_ip_likes( $user_ip, $post_id, $is_comment );
					// Update Post
					if ( $post_users ) {
						$uip_key = array_search( $user_ip, $post_users );
						unset( $post_users[$uip_key] );
						update_post_meta( $post_id, "_user_IP", $post_users );
					}
				}

				$like_count = ( $count > 0 ) ? --$count : 0; // Prevent negative number
				$response['status'] = "unliked";
			}

			update_post_meta( $post_id, "_post_like_count", $like_count );
			$response['button'] = xuper_helpers_button_like($post_id, false);
		}

		wp_send_json( $response );
		exit();
	}

}
