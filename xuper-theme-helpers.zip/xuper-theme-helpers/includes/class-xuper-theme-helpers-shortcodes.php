<?php 
/**
* 
*/
class Xuper_Theme_Helpers_Shortcodes
{
	
	/**
	 * Init shortcodes.
	 */
	public static function init() {

		$shortcodes = array(
			'banner',
			'bigbanner',
			'banner_masonry',
			'banner_masonry_item',
			'info',
			'info_item',
			'map',
			'contact_info',
			'aboutme',
			'brand',
			'brand_item',
			'gallery_carousel',
			'features',
			'feature_item',
			'testimonial',
			'testimonial_item',
			'accordion',
			'newsletter',
			'instagram',
			'product',
			'products',
			'block_products',
			'text_block',
			'posts',
			'video',
			'product_sale'
		);

		if(!empty($shortcodes)):
			foreach ( $shortcodes as $shortcode ) {
				$class = ucwords(str_replace('_', ' ', $shortcode));
				$class = 'Xuper_Theme_Helpers_Shortcode_'.str_replace(' ', '_', $class);
				if(class_exists($class)){
					add_shortcode( 'nouxuper_'.$shortcode, array($class, 'shortcode') );
					add_action( 'vc_before_init', array($class, 'map') );
				}
			}
			add_action( 'vc_before_init', array(__CLASS__, 'add_params') );
		endif;
	}

	public static function add_params(){
		
		$attribute_vc_row = array(
            "type" => "dropdown",
            "class" => "",
            "heading" => esc_html__( "Container", 'xuper-theme-helpers' ),
            "param_name" => "with_container",
            "value" => array(
            	esc_html__('None', 'xuper-theme-helpers') => '', 
            	esc_html__('Container', 'xuper-theme-helpers') => 'ps-container', 
            	//esc_html__('Container fluid', 'xuper-theme-helpers') => 'ps-container-fluid',
            )
        );

        $remove_wrap_vc_row = array(
            "type" => "dropdown",
            "class" => "",
            "heading" => esc_html__( "Remove wrapper", 'xuper-theme-helpers' ),
            "param_name" => "remove_wrapper",
            "value" => array(
            	esc_html__('None', 'xuper-theme-helpers') => '', 
            	esc_html__('Yes', 'xuper-theme-helpers') => '1',
            )
        );

		vc_add_param( 'vc_row', $attribute_vc_row );
		vc_add_param( 'vc_row_inner', $attribute_vc_row );

		vc_add_param( 'vc_row', $remove_wrap_vc_row );
		vc_add_param( 'vc_row_inner', $remove_wrap_vc_row );

		$attribute_vc_row = array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Custom attribute", 'xuper-theme-helpers' ),
            'description' => esc_html__('Add custom attribute separated by commas, EX: data-mh="contact-1",data-mh="contact-2"', 'xuper-theme-helpers'),
            "param_name" => "attributes",
            'group' => esc_html__('Attributes', 'xuper-theme-helpers'),
        );
		vc_add_param( 'vc_row', $attribute_vc_row );
		vc_add_param( 'vc_row_inner', $attribute_vc_row );
		vc_add_param( 'vc_column', $attribute_vc_row );
		vc_add_param( 'vc_column_inner', $attribute_vc_row );

		$size = get_intermediate_image_sizes();

		$attribute_product = array(
		    'type' => 'dropdown',
		    'heading' => esc_html__( "Select image size", 'xuper-theme-helpers' ),
		    'param_name' => 'thumbnail_size',
		    'value' => $size,
		);
		vc_add_param( 'nouxuper_product', $attribute_product );
	}

	/**
	 * get-attributes-of-nested-shortcodes
	 *
	 * @param string $str
	 * @param array $atts
	 *
	 * @return string
	 * @link http://wordpress.stackexchange.com/questions/121562/get-attributes-of-nested-shortcodes
	 */
	public static function get_attributes_nested_shortcodes( $str, $att = null ) {
		$res = array();
		$reg = get_shortcode_regex();
		preg_match_all( '~' . $reg . '~', $str, $matches );
		$i = 0;
		foreach ( $matches[2] as $key => $name ) {
			$parsed = shortcode_parse_atts( $matches[3][ $key ] );
			$parsed = is_array( $parsed ) ? $parsed : array();

			$res[ $i ]              = array_key_exists( $att, $parsed ) ? $parsed[ $att ] : $parsed;
			$res[ $i ]['name']      = $name;
			$res[ $i ]['shortcode'] = $matches[0][ $key ];
			$i                      = $i + 1;
		}

		return $res;
	}

}
?>