<?php
/**
* Autoload class 
*
* @package inc/autoloader
* @author nouthemes [nouthemes@gmail.com]
*/
defined( 'ABSPATH' ) OR exit;

if( !class_exists('Xuper_Theme_Helpers_Autoloader') ){


	class Xuper_Theme_Helpers_Autoloader 
	{

		/**
		 * Autoloader load method. Load the class.
		 *
		 * @param $class_name
		 */
		public function load( $class_name ) 
		{

			if ( 0 === strpos( $class_name, 'Xuper_Theme_Helpers_' ) ) {

				// String to lower
				$class_name = strtolower( $class_name );

				// Format file name
				$file_name = 'class-xuper-theme-helpers-' . str_ireplace( '_', '-', str_ireplace( 'Xuper_Theme_Helpers_', '', $class_name ) ) . '.php';
				// Setup the file path
				$file_path = '';

				if ( 0 === strpos( $class_name, 'xuper_theme_helpers_shortcode_' ) ) {
					$file_path .= 'shortcodes/';
				}

				if ( 0 === strpos( $class_name, 'xuper_theme_helpers_widget_' ) ) {
					$file_path .= 'widgets/';
				}

				// Append file name to clas path
				$file_path .= $file_name;
				// Check & load file
				if ( file_exists( plugin_dir_path( __FILE__ ). $file_path ) ) {
					require_once( plugin_dir_path( __FILE__ ). $file_path );
				}

			}

		}

	}

}