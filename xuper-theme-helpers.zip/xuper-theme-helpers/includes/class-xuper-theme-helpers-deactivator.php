<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://themeforest.net/user/nouthemes
 * @since      1.0.0
 *
 * @package    Xuper_Theme_Helpers
 * @subpackage Xuper_Theme_Helpers/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Xuper_Theme_Helpers
 * @subpackage Xuper_Theme_Helpers/includes
 * @author     Nouthemes <nouthemes@gmail.com>
 */
class Xuper_Theme_Helpers_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
