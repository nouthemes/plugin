<?php

/**
 * Fired during plugin activation
 *
 * @link       https://themeforest.net/user/nouthemes
 * @since      1.0.0
 *
 * @package    Xuper_Theme_Helpers
 * @subpackage Xuper_Theme_Helpers/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Xuper_Theme_Helpers
 * @subpackage Xuper_Theme_Helpers/includes
 * @author     Nouthemes <nouthemes@gmail.com>
 */
class Xuper_Theme_Helpers_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
