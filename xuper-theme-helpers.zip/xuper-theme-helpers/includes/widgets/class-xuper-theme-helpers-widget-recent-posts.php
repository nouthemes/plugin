<?php 
defined( 'ABSPATH' ) OR exit;

/**
* Class widget Recent Posts
*
* @author nouthemes [nouthemes@gmail.com] 
* @since 1.0
* @Code Nam
*/

class Xuper_Theme_Helpers_Widget_Recent_Posts extends WP_Widget {

	/**
	 * Sets up a new Upload a banner.
	 *
	 * @since 2.8.0
	 * @access public
	 */
	public function __construct() {
		$widget_ops = array(
			'classname' => 'widget_recent-posts',
			'description' => esc_html__( 'Get posts with parameter.', 'xuper-theme-helpers' ),
			'customize_selective_refresh' => true,
		);
		parent::__construct('Xuper_Theme_Helpers_Widget_Recent_Posts', esc_html__('* Xuper - Posts', 'xuper-theme-helpers'), $widget_ops);
	}

	/**
	 * @param array $args
	 * @param array $instance
	 */
	// Creating widget front-end
	// This is where the action happens
	public function widget( $args, $instance ) {

		$title = ( isset($instance['title']) && !empty($instance['title']) ) ? $instance['title'] : '';
		$number = ( isset($instance['number']) && !empty($instance['number']) ) ? $instance['number'] : '5';
		$cat = ( isset($instance['cat']) && !empty($instance['cat']) ) ? $instance['cat'] : '';
		$id_str = ( isset($instance['id_str']) && !empty($instance['id_str']) ) ? $instance['id_str'] : '';
		$ids = array();

		if(!empty($id_str)){
			$ids = explode(',', $id_str);
		}

		$posts_args = array('post_type' => 'post', 'posts_per_page' => intval($number), 'ignore_sticky_posts' => true, 'post_status' => 'publish');

		if(!empty($ids)){
			$posts_args['post__in'] = $ids;
		}else{
			if($cat > 0){
				$posts_args['cat'] = $cat;
			}
		}

		$query = new WP_Query($posts_args);
		if($query->have_posts()):

			echo $args['before_widget'];
			
				if(!empty($title)){ echo $args['before_title'].$title.$args['after_title']; }
			
				while($query->have_posts()){ $query->the_post();
					?>
					<div class="ps-post--sidebar">
                      	<div class="ps-post__thumbnail">
                      		<a class="ps-post__overlay" href="<?php the_permalink();?>"></a>
                      		<?php the_post_thumbnail('thumbnail');?>
                      	</div>
                      	<div class="ps-post__content">
                      		<a class="ps-post__title" href="<?php the_permalink();?>"><?php the_title();?></a>
                      		<p><?php the_date(get_option('date_format'));?></p>
                      	</div>
                    </div>
					<?php
				}

			echo $args['after_widget'];

		endif;wp_reset_postdata();	

	}
		
	// Widget Backend 
	public function form( $instance ) {

		$instance = wp_parse_args( 
			(array) $instance, array(
									 'title' => '', 
									 'number' => '5',
									 'cat' => '',
									 'id_str' => ''
									 ) 
		);
		$title 	= strip_tags($instance['title']);
		$number = intval( $instance['number'] );
		$cat 	= intval( $instance['cat'] );
		$id_str = sanitize_text_field( $instance['id_str'] );
		?>

		<p><label for="<?php echo esc_attr( $this->get_field_id('title') ); ?>"><?php esc_html_e('Title:', 'xuper-theme-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('title') ); ?>" name="<?php echo esc_attr( $this->get_field_name('title') ); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>

		
		<p><label for="<?php echo esc_attr( $this->get_field_id('number') ); ?>"><?php esc_html_e('Number of posts show:', 'xuper-theme-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('number') ); ?>" name="<?php echo esc_attr( $this->get_field_name('number') ); ?>" type="number" value="<?php echo esc_attr($number); ?>" /></p>

		<p><label for="<?php echo esc_attr( $this->get_field_id('cat') ); ?>"><?php esc_html_e('Category:', 'xuper-theme-helpers'); ?></label>
		<?php 
		$args = array(
			'show_option_none'   => esc_html__('Select a category', 'xuper-theme-helpers'),
			'selected'           => $cat,
			'name'               => esc_attr( $this->get_field_name('cat') ),
			'id'                 => esc_attr( $this->get_field_id('cat') ),
			'class'              => 'widefat',
			'taxonomy'           => 'category',
			'value_field'	     => 'term_id',
		);
		wp_dropdown_categories( $args ); 
		?>
		</p>

		<p><label for="<?php echo esc_attr( $this->get_field_id('id_str') ); ?>"><?php esc_html_e('IDs post:', 'xuper-theme-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('id_str') ); ?>" name="<?php echo esc_attr( $this->get_field_name('id_str') ); ?>" type="text" value="<?php echo esc_attr($id_str); ?>" /><span><?php esc_html_e('EX: 1123,21,32', 'xuper-theme-helpers');?></span></p>

		<?php
	}

	
	
	// Updating widget replacing old instances with new
	public function update( $new_instance, $old_instance ) {
		
		$instance = $old_instance;

		$instance['title'] 				= strip_tags($new_instance['title']);
		
		$instance['number']            = sanitize_text_field( $new_instance['number'] );
		$instance['cat']     		= sanitize_text_field( $new_instance['cat'] );
		$instance['id_str']            	= sanitize_text_field( $new_instance['id_str'] );

		return $instance;
	}

}

?>