<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://themeforest.net/user/nouthemes
 * @since             1.0.0
 * @package           Xuper_Theme_Helpers
 *
 * @wordpress-plugin
 * Plugin Name:       Xuper theme helpers
 * Plugin URI:        https://themeforest.net/user/nouthemes
 * Description:       Xuper theme helpers
 * Version:           1.0.1
 * Author:            Nouthemes
 * Author URI:        https://themeforest.net/user/nouthemes
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       xuper-theme-helpers
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! defined( 'XUPER_HELPERS_VER' ) ) {
	/**
	 *
	 */
	define( 'XUPER_HELPERS_VER', '1.0.0' );
}

if ( ! defined( 'XUPER_HELPERS_DIR' ) ) {
	/**
	 *
	 */
	define( 'XUPER_HELPERS_DIR', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'XUPER_HELPERS_URL' ) ) {
	/**
	 *
	 */
	define( 'XUPER_HELPERS_URL', plugin_dir_url( __FILE__ ) );
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'PLUGIN_NAME_VERSION', '1.0.0' );

require plugin_dir_path( __FILE__ ) . 'xuper-theme-helpers-functions.php';

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-xuper-theme-helpers-activator.php
 */
function activate_xuper_theme_helpers() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-xuper-theme-helpers-activator.php';
	Xuper_Theme_Helpers_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-xuper-theme-helpers-deactivator.php
 */
function deactivate_xuper_theme_helpers() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-xuper-theme-helpers-deactivator.php';
	Xuper_Theme_Helpers_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_xuper_theme_helpers' );
register_deactivation_hook( __FILE__, 'deactivate_xuper_theme_helpers' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-xuper-theme-helpers.php';

add_action('vc_before_init', 'xuper_theme_helpers_shortcodes_container');
function xuper_theme_helpers_shortcodes_container(){
	if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	    class WPBakeryShortCode_Nouxuper_Brand extends WPBakeryShortCodesContainer {
	    }
	    class WPBakeryShortCode_Nouxuper_Banner_Masonry extends WPBakeryShortCodesContainer {
	    }
	    class WPBakeryShortCode_Nouxuper_Info extends WPBakeryShortCodesContainer {
	    }
	}
	if ( class_exists( 'WPBakeryShortCode' ) ) {
	    
	    class WPBakeryShortCode_Nouxuper_Brand_Item extends WPBakeryShortCode {
	    }
	    class WPBakeryShortCode_Nouxuper_Banner_Masonry_Item extends WPBakeryShortCode {
	    }
	    class WPBakeryShortCode_Nouxuper_Info_Item extends WPBakeryShortCode {
	    }
	    
	}
}
/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_xuper_theme_helpers() {

	$plugin = new Xuper_Theme_Helpers();
	$plugin->run();

}
run_xuper_theme_helpers();
