<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// METABOX OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options      = array();

// -----------------------------------------
// Page Metabox Options                    -
// -----------------------------------------
$options[]    = array(
  'id'        => '_product_video',
  'title'     => esc_html__('Video Youtube Only', 'xuper-theme-helpers'),
  'post_type' => 'product',
  'context'   => 'side',
  'priority'  => 'default',
  'sections'  => array(

    array(
      'name'   => 'section_1',
      'fields' => array(
        array(
          'id'            => 'url',
          'title'     => esc_html__('URL', 'xuper-theme-helpers'),
          'type'          => 'text',
          'desc'    => esc_html__('EX: https://www.youtube.com/watch?v=4ZighUyrsRU', 'xuper-theme-helpers'),
        ),
      ),
    ),

  ),
);

$options[]    = array(
  'id'        => 'nouxuper_layout_settings',
  'title'     => esc_html__('Layout Settings', 'xuper-theme-helpers'),
  'post_type' => array('page','post'),
  'context'   => 'normal',
  'priority'  => 'default',
  'sections'  => array(

    // begin: a section
    array(
      'name'  => 'general',
      'title' => esc_html__('General', 'xuper-theme-helpers'),
      'icon'  => 'fa fa-cog',
      'fields' => array(

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Logo', 'xuper-theme-helpers'),
        ),
        array(
          'id'        => 'logo_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Logo', 'xuper-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'xuper-theme-helpers'),
            '1' => esc_html__('Custom logo', 'xuper-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'logo_custom',
          'type'  => 'upload',
          'title' => esc_html__('Upload Custom Logo', 'xuper-theme-helpers'),
          'dependency'   => array( 'logo_type', '==', '1' )
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Header', 'xuper-theme-helpers'),
        ),
        array(
          'id'        => 'header_style',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Header style', 'xuper-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'xuper-theme-helpers'),
            '1' => esc_html__('Style #1', 'xuper-theme-helpers'),
            '2' => esc_html__('Style #2', 'xuper-theme-helpers'),
            '3' => esc_html__('Style #3', 'xuper-theme-helpers'),
          ),
          'default' => '0'
        ),
        
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Custome title', 'xuper-theme-helpers'),
        ),
        array(
          'id'      => 'post_title',
          'type'    => 'text',
          'title'   => esc_html__('Title', 'xuper-theme-helpers'),
        ),
        array(
          'id'      => 'post_desc',
          'type'    => 'textarea',
          'title'   => esc_html__('Description', 'xuper-theme-helpers'),
        ),
      ),
    ),
    // end: a section

    // begin: a section
    array(
      'name'  => 'sidebar',
      'title' => esc_html__('Sidebar', 'xuper-theme-helpers'),
      'icon'  => 'fa fa-tint',
      'fields' => array(

        array(
          'id'        => 'sidebar',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Sidebar style', 'xuper-theme-helpers'),
          'options'   => array(
            '0'     => esc_html__('Default', 'xuper-theme-helpers'),
            'right' => esc_html__('Right', 'xuper-theme-helpers'),
            'left' => esc_html__('Left', 'xuper-theme-helpers'),
            'hide' => esc_html__('No sidebar', 'xuper-theme-helpers'),
          ),
        ),

        

      ),
    ),
    // end: a section

  ),
);


$options[]    = array(
  'id'        => 'nouxuper_layout_settings',
  'title'     => esc_html__('Single Settings', 'xuper-theme-helpers'),
  'post_type' => array('product'),
  'context'   => 'normal',
  'priority'  => 'default',
  'sections'  => array(

    // begin: a section
    array(
      'name'  => 'sidebar',
      'title' => esc_html__('General', 'xuper-theme-helpers'),
      'icon'  => 'fa fa-tint',
      'fields' => array(

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Logo', 'xuper-theme-helpers'),
        ),
        array(
          'id'        => 'logo_type',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Logo', 'xuper-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'xuper-theme-helpers'),
            '1' => esc_html__('Custom logo', 'xuper-theme-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'    => 'logo_custom',
          'type'  => 'upload',
          'title' => esc_html__('Upload Custom Logo', 'xuper-theme-helpers'),
          'dependency'   => array( 'logo_type', '==', '1' )
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Header', 'xuper-theme-helpers'),
        ),
        array(
          'id'        => 'header_style',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Header style', 'xuper-theme-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'xuper-theme-helpers'),
            '1' => esc_html__('Style #1', 'xuper-theme-helpers'),
            '2' => esc_html__('Style #2', 'xuper-theme-helpers'),
            '3' => esc_html__('Style #3', 'xuper-theme-helpers'),
          ),
          'default' => '0'
        ),
      ),
    ),
    // end: a section
    

  ),
);

Xuper_Helpers_CSFramework_Metabox::instance( $options );
