<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// CUSTOMIZE SETTINGS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options              = array();

// -----------------------------------------
// Customize Core Fields                   -
// -----------------------------------------
$options[]            = array(
  'name'              => 'header',
  'title'             => esc_html__('Header', 'xuper-theme-helpers'),
  'settings'          => array(

    // textarea
    array(
      'name'          => 'header_notify',
      'transport'     => 'postMessage',
      'control'       => array(
        'label'       => esc_html__('Address', 'xuper-theme-helpers'),
        'type'        => 'textarea',
      ),
    ),
    array(
      'name'          => 'logo',
      'transport'     => 'postMessage',
      'control'       => array(
        'label'       => esc_html__('Logo', 'xuper-theme-helpers'),
        'type'        => 'upload',
      ),
    ),

  )
);
$options[]            = array(
  'name'              => 'footer',
  'title'             => esc_html__('Footer', 'xuper-theme-helpers'),
  'settings'          => array(

    array(
      'name'          => 'copyright_subheading',
      'control'       => array(
        'type'        => 'cs_field',
        'options'     => array(
          'type'      => 'subheading',
          'content'   => esc_html__('Copyright', 'xuper-theme-helpers'),
        ),
      ),
    ),
    // textarea
    array(
      'name'          => 'copyright',
      'transport'     => 'postMessage',
      'control'       => array(
        'label'       => esc_html__('Copyright text', 'xuper-theme-helpers'),
        'type'        => 'textarea',
      ),
    ),

  )
);

Xuper_Helpers_CSFramework_Customize::instance( $options );
