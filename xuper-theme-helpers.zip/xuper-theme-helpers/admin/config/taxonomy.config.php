<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// TAXONOMY OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options     = array();

// -----------------------------------------
// Taxonomy Options                        -
// -----------------------------------------
$options[]   = array(
  'id'       => 'nouexist_layout_settings',
  'taxonomy' => 'post_tag', // category, post_tag or your custom taxonomy name
  'fields'   => array(

    array(
      'type'    => 'subheading',
      'content' => esc_html__('Logo', 'xuper-theme-helpers'),
    ),
    array(
      'id'        => 'logo_type',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Logo', 'xuper-theme-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'xuper-theme-helpers'),
        '1' => esc_html__('Custom logo', 'xuper-theme-helpers'),
      ),
      'default' => '0'
    ),
    array(
      'id'    => 'logo_custom',
      'type'  => 'upload',
      'title' => esc_html__('Upload Custom Logo', 'xuper-theme-helpers'),
      'dependency'   => array( 'logo_type', '==', '1' )
    ),
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Heading', 'xuper-theme-helpers'),
    ),
    array(
      'id'        => 'header_style',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Header style', 'xuper-theme-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'xuper-theme-helpers'),
        '1' => esc_html__('Style #1', 'xuper-theme-helpers'),
        '2' => esc_html__('Style #2', 'xuper-theme-helpers'),
        '3' => esc_html__('Style #3', 'xuper-theme-helpers'),
      ),
      'default' => '0'
    ),

        
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Custome title', 'xuper-theme-helpers'),
    ),
    array(
      'id'      => 'post_title',
      'type'    => 'text',
      'title'   => esc_html__('Title', 'xuper-theme-helpers'),
    ),
    array(
      'id'      => 'post_desc',
      'type'    => 'textarea',
      'title'   => esc_html__('Description', 'xuper-theme-helpers'),
    ),

  ),
);
$options[]   = array(
  'id'       => 'nouexist_layout_settings',
  'taxonomy' => 'category', // category, post_tag or your custom taxonomy name
  'fields'   => array(

    array(
      'type'    => 'subheading',
      'content' => esc_html__('Logo', 'xuper-theme-helpers'),
    ),
    array(
      'id'        => 'logo_type',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Logo', 'xuper-theme-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'xuper-theme-helpers'),
        '1' => esc_html__('Custom logo', 'xuper-theme-helpers'),
      ),
      'default' => '0'
    ),
    array(
      'id'    => 'logo_custom',
      'type'  => 'upload',
      'title' => esc_html__('Upload Custom Logo', 'xuper-theme-helpers'),
      'dependency'   => array( 'logo_type', '==', '1' )
    ),
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Heading', 'xuper-theme-helpers'),
    ),
    array(
      'id'        => 'header_style',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Header style', 'xuper-theme-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'xuper-theme-helpers'),
        '1' => esc_html__('Style #1', 'xuper-theme-helpers'),
        '2' => esc_html__('Style #2', 'xuper-theme-helpers'),
        '3' => esc_html__('Style #3', 'xuper-theme-helpers'),
      ),
      'default' => '0'
    ),


        
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Custome title', 'xuper-theme-helpers'),
    ),
    array(
      'id'      => 'post_title',
      'type'    => 'text',
      'title'   => esc_html__('Title', 'xuper-theme-helpers'),
    ),
    array(
      'id'      => 'post_desc',
      'type'    => 'textarea',
      'title'   => esc_html__('Description', 'xuper-theme-helpers'),
    ),

  ),
);

$options[]   = array(
  'id'       => 'nouexist_layout_settings',
  'taxonomy' => 'product_cat', // category, post_tag or your custom taxonomy name
  'fields'   => array(

    array(
      'type'    => 'subheading',
      'content' => esc_html__('Logo', 'xuper-theme-helpers'),
    ),
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Logo', 'xuper-theme-helpers'),
    ),
    array(
      'id'        => 'logo_type',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Logo', 'xuper-theme-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'xuper-theme-helpers'),
        '1' => esc_html__('Custom logo', 'xuper-theme-helpers'),
      ),
      'default' => '0'
    ),
    array(
      'id'    => 'logo_custom',
      'type'  => 'upload',
      'title' => esc_html__('Upload Custom Logo', 'xuper-theme-helpers'),
      'dependency'   => array( 'logo_type', '==', '1' )
    ),
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Heading', 'xuper-theme-helpers'),
    ),
    array(
      'id'        => 'header_style',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Header style', 'xuper-theme-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'xuper-theme-helpers'),
        '1' => esc_html__('Style #1', 'xuper-theme-helpers'),
        '2' => esc_html__('Style #2', 'xuper-theme-helpers'),
        '3' => esc_html__('Style #3', 'xuper-theme-helpers'),
      ),
      'default' => '0'
    ),

        
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Custome title', 'xuper-theme-helpers'),
    ),
    array(
      'id'      => 'post_title',
      'type'    => 'text',
      'title'   => esc_html__('Title', 'xuper-theme-helpers'),
    ),
    array(
      'id'      => 'post_desc',
      'type'    => 'textarea',
      'title'   => esc_html__('Description', 'xuper-theme-helpers'),
    ),

  ),
);

$options[]   = array(
  'id'       => 'nouexist_layout_settings',
  'taxonomy' => 'product_tag', // category, post_tag or your custom taxonomy name
  'fields'   => array(

    array(
      'type'    => 'subheading',
      'content' => esc_html__('Logo', 'xuper-theme-helpers'),
    ),
    array(
      'id'        => 'logo_type',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Logo', 'xuper-theme-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'xuper-theme-helpers'),
        '1' => esc_html__('Custom logo', 'xuper-theme-helpers'),
      ),
      'default' => '0'
    ),
    array(
      'id'    => 'logo_custom',
      'type'  => 'upload',
      'title' => esc_html__('Upload Custom Logo', 'xuper-theme-helpers'),
      'dependency'   => array( 'logo_type', '==', '1' )
    ),
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Heading', 'xuper-theme-helpers'),
    ),
    array(
      'id'        => 'header_style',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Header style', 'xuper-theme-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'xuper-theme-helpers'),
        '1' => esc_html__('Style #1', 'xuper-theme-helpers'),
        '2' => esc_html__('Style #2', 'xuper-theme-helpers'),
        '3' => esc_html__('Style #3', 'xuper-theme-helpers'),
      ),
      'default' => '0'
    ),

    array(
      'id'        => 'banner_heading_enable',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Enable Banner Heading', 'xuper-theme-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'xuper-theme-helpers'),
        '1' => esc_html__('Show', 'xuper-theme-helpers'),
        '2' => esc_html__('Hide', 'xuper-theme-helpers'),
      ),
      'default' => '0'
    ),
    
        
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Custome title', 'xuper-theme-helpers'),
        ),
        array(
          'id'      => 'post_title',
          'type'    => 'text',
          'title'   => esc_html__('Title', 'xuper-theme-helpers'),
        ),
        array(
          'id'      => 'post_desc',
          'type'    => 'textarea',
          'title'   => esc_html__('Description', 'xuper-theme-helpers'),
        ),

  ),
);
Xuper_Helpers_CSFramework_Taxonomy::instance( $options );
