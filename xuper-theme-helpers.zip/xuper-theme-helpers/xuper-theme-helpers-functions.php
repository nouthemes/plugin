<?php 
if ( ! defined( 'WPINC' ) ) {
	die;
}

function xuper_helper_get_taxonomies()
{
	global $wpdb;
	return $wpdb->get_results( "SELECT DISTINCT `taxonomy` FROM $wpdb->term_taxonomy" );
}

/**
* Sync from customizer vs theme options
* 
* @author nouthemes [nouthemes@gmail.com]
* @since 1.0
* @return url
* @code Nam
*/
if(!function_exists('xuper_helpers_option')){
  function xuper_helpers_option($setting, $default = '')
  { 
    $options = get_option( '_nouxuper_options', array() );
    $value = $default;
    if ( isset( $options[ $setting ] ) ) {
        $value = $options[ $setting ];
    }
    return $value;
  }
}

/**
 *
 * Get option
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! function_exists( 'xuper_helpers_cs_get_option' ) ) {
  function xuper_helpers_cs_get_option( $option_name = '', $default = '' ) {

    $options = apply_filters( 'cs_get_option', get_option( xuper_HELPERS_CS_OPTION ), $option_name, $default );

    if( ! empty( $option_name ) && ! empty( $options[$option_name] ) ) {
      return $options[$option_name];
    } else {
      return ( ! empty( $default ) ) ? $default : null;
    }

  }
}

function xuper_helpers_get_current_id(){
	$object_id = get_queried_object_id();
    if ( ( get_option( 'show_on_front' ) && get_option( 'page_for_posts' ) && is_home() ) || ( get_option( 'page_for_posts' ) && is_archive() && ! is_post_type_archive() && ! is_tax() ) && ! ( is_tax( 'product_cat' ) || is_tax( 'product_tag' ) ) || ( get_option( 'page_for_posts' ) && is_search() ) ) {
        
        $page_ID = get_option( 'page_for_posts' );

    } else {

        if ( isset( $object_id ) ) {
            $page_ID = $object_id;
        }

        if ( ! is_singular() ) {
            $page_ID = false;
        }

    }

    return $page_ID;
}

function xuper_helpers_single_product_settings(){
  	$related_type = xuper_helpers_option('nouxuper_product_related_type', 'related');
  	$title = xuper_helpers_option('nouxuper_shop_related_title');
  	$desc = xuper_helpers_option('nouxuper_shop_related_desc');

  	$facebook = xuper_helpers_option('nouxuper_single_share_facebook', 1);
	$google = xuper_helpers_option('nouxuper_single_share_google', 1);
	$twitter = xuper_helpers_option('nouxuper_single_share_twitter', 1);
	$pinterest = xuper_helpers_option('nouxuper_single_share_pinterest', 1);
	$linkedin = xuper_helpers_option('nouxuper_single_share_linkedin', 1);

  	$post_id = xuper_helpers_get_current_id();
  	if($post_id){
    	$nouxuper_meta = get_post_meta( $post_id, 'nouxuper_layout_settings', true );
        if ( isset($nouxuper_meta['product_related_type']) && !empty($nouxuper_meta['product_related_type']) ) {
            $related_type = $nouxuper_meta['product_related_type'];
        }
        if ( isset($nouxuper_meta['shop_related_title']) && !empty($nouxuper_meta['shop_related_title']) ) {
            $title = $nouxuper_meta['shop_related_title'];
        }
        if ( isset($nouxuper_meta['shop_related_desc']) && !empty($nouxuper_meta['shop_related_desc']) ) {
            $desc = $nouxuper_meta['shop_related_desc'];
        }

        if ( isset($nouxuper_meta['facebook']) && !empty($nouxuper_meta['facebook']) ) {
            $facebook = $nouxuper_meta['facebook'];
            if($nouxuper_meta['facebook'] == 2){
            	$facebook = '';
            }
        }
        if ( isset($nouxuper_meta['google']) && !empty($nouxuper_meta['google']) ) {
            $google = $nouxuper_meta['google'];
            if($nouxuper_meta['google'] == 2){
            	$google = '';
            }
        }
        if ( isset($nouxuper_meta['twitter']) && !empty($nouxuper_meta['twitter']) ) {
            $twitter = $nouxuper_meta['twitter'];
            if($nouxuper_meta['twitter'] == 2){
            	$twitter = '';
            }
        }
        if ( isset($nouxuper_meta['pinterest']) && !empty($nouxuper_meta['pinterest']) ) {
            $pinterest = $nouxuper_meta['pinterest'];
            if($nouxuper_meta['pinterest'] == 2){
            	$pinterest = '';
            }
        }
        if ( isset($nouxuper_meta['linkedin']) && !empty($nouxuper_meta['linkedin']) ) {
            $linkedin = $nouxuper_meta['linkedin'];
            if($nouxuper_meta['linkedin'] == 2){
            	$linkedin = '';
            }
        }
  	}

  	return apply_filters('nouxuper_single_product_settings', 
  				array(
  					'related_type' => $related_type, 
  					'related_title' => $title, 
  					'related_desc' => $desc,
  					'facebook' => $facebook,
  					'google' => $google,
  					'twitter' => $twitter,
  					'pinterest' => $pinterest,
  					'linkedin' => $linkedin
  				), 
  				$post_id
  			);
}

/**
 * Get post like
 *
 * @package Masta
 * @since 1.0
 * @author nouthemes [nouthemes@gmail.com]
 */

if(!function_exists('xuper_helpers_post_like')){
	function xuper_helpers_post_like($id = null) 
	{
		$post_id = xuper_helpers_get_current_id();
		if($id){
			$post_id = $id;
		}
		$meta = get_post_meta($post_id, '_post_like_count', true);

		if ( is_numeric( $meta ) && $meta > 0 ) { 
			$number = xuper_helpers_format_count($meta);
		} else {
			$number = 0;
		}
			
	    return $number;
	}
}


/**
 * Format number with K, M, B
 *
 * @package Masta
 * @since 1.0
 * @author nouthemes [nouthemes@gmail.com]
 */
if(!function_exists('xuper_helpers_format_count')){
	function xuper_helpers_format_count( $number ) {
		$precision = 2;
		if ( $number >= 1000 && $number < 1000000 ) {
			$formatted = number_format( $number/1000, $precision ).'K';
		} else if ( $number >= 1000000 && $number < 1000000000 ) {
			$formatted = number_format( $number/1000000, $precision ).'M';
		} else if ( $number >= 1000000000 ) {
			$formatted = number_format( $number/1000000000, $precision ).'B';
		} else {
			$formatted = $number; // Number is less than 1000
		}
		$formatted = str_replace( '.00', '', $formatted );
		return $formatted;
	}
}


/**
 * Get current IP address
 *
 * @package Masta
 * @since 1.0
 * @author nouthemes [nouthemes@gmail.com]
 */
if(!function_exists('xuper_helpers_get_ip')){
	function xuper_helpers_get_ip() {
		if ( isset( $_SERVER['HTTP_CLIENT_IP'] ) && ! empty( $_SERVER['HTTP_CLIENT_IP'] ) ) {
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		} elseif ( isset( $_SERVER['HTTP_X_FORWARDED_FOR'] ) && ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} else {
			$ip = ( isset( $_SERVER['REMOTE_ADDR'] ) ) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
		}
		$ip = filter_var( $ip, FILTER_VALIDATE_IP );
		$ip = ( $ip === false ) ? '0.0.0.0' : $ip;
		return $ip;
	}
}


if(!function_exists('xuper_helpers_already_liked')){
	function xuper_helpers_already_liked( $post_id ) {
		
		$post_users = NULL;
		$user_id = NULL;
    $is_comment = null;

		if ( is_user_logged_in() ) { // user is logged in

			$user_id = get_current_user_id();
			$post_meta_users = get_post_meta( $post_id, "_user_liked" );
			
			if ( count( $post_meta_users ) > 0 ) {
				$post_users = $post_meta_users[0];
			}

		} else { // user is anonymous

			$user_id = xuper_helpers_get_ip();
			$post_meta_users = get_post_meta( $post_id, "_user_IP" ); 
			
			if ( count( $post_meta_users ) > 0 ) { // meta exists, set up values
				$post_users = $post_meta_users[0];
			}
		}

		if ( is_array( $post_users ) && in_array( $user_id, $post_users ) ) {
			return true;
		} else {
			return false;
		}
	}
}

/**
 * Utility returns the button icon for "like" action
 * @since    1.0
 */
if(!function_exists('xuper_helpers_get_liked_icon')){
	function xuper_helpers_get_liked_icon() {
		$loved_icon = xuper_helpers_option('xuper_helpers_loved_icon', 'fa fa-heart');
		$icon = ' <i class="'.esc_attr( $loved_icon ).'"></i>';
		return $icon;
	}
}	

/**
 * Utility returns the button icon for "unlike" action
 * @since   1.0
 */
if(!function_exists('xuper_helpers_get_unliked_icon')){
	function xuper_helpers_get_unliked_icon() {
		$love_icon = xuper_helpers_option('xuper_helpers_love_icon', 'fa fa-heart-o');
		$icon = '<i class="'.esc_attr( $love_icon ).'"></i>';
		return $icon;
	}
}	

if(!function_exists('xuper_helpers_button_like')){
	function xuper_helpers_button_like($post_id, $echo = true)
	{
		$title = esc_html__('Like', 'xuper-theme-helpers');
    $class = '';

		$liked = xuper_helpers_already_liked($post_id);
		if($liked){
			$class = esc_attr( 'liked', 'xuper-theme-helpers' );
			$title = esc_html__( 'Unlike', 'xuper-theme-helpers' );
		}

		$archive_layout = nouxuper_blog_style();
		
    $output = '<a data-id="'.intval($post_id).'" class="post-like '.esc_attr($class).'"><i class="ps-icon-heart"></i> ' . esc_attr( $title ) . '</a>';

		if($archive_layout['layout'] === 2){
			$output = '<a data-id="'.intval($post_id).'" class="ps-post__favorite post-like '.esc_attr($class).'"><i class="ps-icon-heart"></i> ' . esc_attr( $title ) . '</a>';
		}

		
		$display_button = xuper_helpers_option('nouxuper_blog_like_enable', 1);
		if(empty($display_button)){
			$output = '';
		}

		if($echo){
			echo $output;
		}else{
			return $output;
		}
	}
}

/**
* Single share post
*
*/
if(!function_exists('xuper_helpers_share_post')){
  add_action('nouxuper_action_blog_list', 'xuper_helpers_share_post');
  function xuper_helpers_share_post($layout)
  {
    if($layout == '1'){
      ?>
      <div class="ps-post__actions">
        <div class="ps-post__likes"><?php echo xuper_helpers_button_like(get_the_ID());?></div>
                <a href="<?php echo esc_url(the_permalink()); ?>#comments"><i class="fa fa-comments"></i> <?php printf( _nx( '1 Comment', '%1$s Comments', get_comments_number(), 'comments title', 'xuper-theme-helpers' ), number_format_i18n( get_comments_number() ) );?></a>
                <div class="ps-post__shared">
                  <a href="#"><i class="fa fa-share-alt"></i><?php esc_html_e('Share', 'xuper-theme-helpers');?></a>
                    <ul class="xuper-share" data-title="<?php the_title();?>" data-url="<?php the_permalink();?>">
                        <li><a href="#" data-type="facebook"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#" data-type="twitter"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#" data-type="google"><i class="fa fa-google-plus"></i></a></li>
                    </ul>
                </div>
            </div>
      <?php
    }else{
      ?>
      <div class="ps-post__likes layout__grid"><?php echo xuper_helpers_button_like(get_the_ID());?></div>
      <?php
    }
  }
}

if(!function_exists('xuper_helpers_share_single_post')){
  add_action('nouxuper_action_single_blog', 'xuper_helpers_share_single_post');
  function xuper_helpers_share_single_post($layout)
  {
    ?>
    <div class="ps-post__social"><i class="fa fa-share-alt"></i><a href="#"><?php esc_html_e('Share', 'xuper-theme-helpers');?></a>
        <ul class="xuper-share" data-title="<?php the_title();?>" data-url="<?php the_permalink();?>">
            <li><a href="#" data-type="facebook"><i class="fa fa-facebook"></i></a></li>
            <li><a href="#" data-type="twitter"><i class="fa fa-twitter"></i></a></li>
            <li><a href="#" data-type="google"><i class="fa fa-google-plus"></i></a></li>
        </ul>
    </div>
    <?php
  }
}

if(!function_exists('xuper_helpers_share_single_product')){
	add_action('woocommerce_share', 'xuper_helpers_share_single_product');
	function xuper_helpers_share_single_product($layout)
	{
		?>
    <p class="ps-product__sharing xuper-share" data-title="<?php the_title();?>" data-url="<?php the_permalink();?>"><?php esc_html_e('Share this', 'xuper-theme-helpers');?>
        <a href="#" data-type="facebook"><i class="fa fa-facebook"></i></a>
        <a href="#" data-type="twitter"><i class="fa fa-twitter"></i></a>
        <a href="#" data-type="google"><i class="fa fa-google-plus"></i></a>
    </p>
    <?php
	}
}

function xuper_helpers_post_user_likes( $user_id, $post_id, $is_comment=false ) {
	$post_users = '';
	$post_meta_users = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_liked" ) : get_post_meta( $post_id, "_user_liked" );
	if ( count( $post_meta_users ) != 0 ) {
		$post_users = $post_meta_users[0];
	}
	if ( !is_array( $post_users ) ) {
		$post_users = array();
	}
	if ( !in_array( $user_id, $post_users ) ) {
		$post_users['user-' . $user_id] = $user_id;
	}
	return $post_users;
} 

function xuper_helpers_post_ip_likes( $user_ip, $post_id, $is_comment ) {
	$post_users = '';
	$post_meta_users = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_IP" ) : get_post_meta( $post_id, "_user_IP" );
	// Retrieve post information
	if ( count( $post_meta_users ) != 0 ) {
		$post_users = $post_meta_users[0];
	}
	if ( !is_array( $post_users ) ) {
		$post_users = array();
	}
	if ( !in_array( $user_ip, $post_users ) ) {
		$post_users['ip-' . $user_ip] = $user_ip;
	}
	return $post_users;
}

function xuper_helpers_get_image_by_id($id, $size, $class = array()){
	$image_attributes = wp_get_attachment_image_src( $id, $size );
	if($image_attributes){
		echo '<img src="'.esc_attr($image_attributes[0]).'" alt="">';
	}
}

function xuper_helpers_product_countdown($str){
	?>
	<ul class="ps-countdown" data-time="<?php echo esc_attr($str);?> 23:59:59">
        <li><span class="hours"></span>
            <p><?php esc_html_e('Hours', 'xuper-theme-helpers');?></p>
        </li>
        <li class="divider">:</li>
        <li><span class="minutes"></span>
            <p><?php esc_html_e('Minutes', 'xuper-theme-helpers');?></p>
        </li>
        <li class="divider">:</li>
        <li><span class="seconds"></span>
            <p><?php esc_html_e('Seconds', 'xuper-theme-helpers');?></p>
        </li>
    </ul>
	<?php
}

function xuper_helpers_product_proccess($product){
	if($product->get_manage_stock() && $product->get_stock_quantity() > 0):
		$total_sales = get_post_meta($product->get_id(), 'total_sales', true);
      	$total_sales = !empty($total_sales) ? $total_sales : '0';
      	$total_stock = $product->get_stock_quantity();
		?>
		<div class="ps-product__status">
            <div class="sold"><?php esc_html_e('Already sold', 'xuper-theme-helpers');?>: <span><?php echo intval($total_sales)?></span></div>
            <div class="avaiable"><?php esc_html_e('avaiable', 'xuper-theme-helpers');?>: <span><?php echo intval($total_stock)?></span></div>
        </div>
        <div class="progress">
            <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo intval($total_sales*100/$total_stock)?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo intval($total_sales*100/$total_stock)?>%;"></div>
        </div>
		<?php
	endif;
}

/**
 * Get Woo style
 *
 * @package Shoes
 * @since 1.0
 * @author nouthemes [nouthemes@gmail.com]
 */

if(!function_exists('nouxuper_helpers_shop_style')){
  function nouxuper_helpers_shop_style() 
  {
      $layout = xuper_helpers_option('nouxuper_woo_archive_layout', '1');
      $sidebar = xuper_helpers_option('nouxuper_woo_archive_sidebar', 'left');
      $wishlist = xuper_helpers_option('nouxuper_woo_archive_wishlist');
      $compare = xuper_helpers_option('nouxuper_woo_archive_compare');
      $quickview = xuper_helpers_option('nouxuper_woo_archive_quickview');
      $addtocart = xuper_helpers_option('nouxuper_woo_archive_addtocart', 1);
      $banner_heading = xuper_helpers_option('nouxuper_shop_banner_heading');
      $banner_heading_style = xuper_helpers_option('nouxuper_shop_banner_heading_style', '1');
      $pagination = xuper_helpers_option('nouxuper_woo_archive_pagination', '1');
      
      if(is_tax()){
        $queried_object = get_queried_object();
        $term_id = $queried_object->term_id;
        if($term_id){
            $nouxuper_meta = get_term_meta( $term_id, 'nouxuper_layout_settings', true );
            if ( isset($nouxuper_meta['sidebar']) && !empty($nouxuper_meta['sidebar']) ) {
                $sidebar = $nouxuper_meta['sidebar'];
            }

            if ( isset($nouxuper_meta['wishlist']) && !empty($nouxuper_meta['wishlist']) ) {
                $wishlist = $nouxuper_meta['wishlist'];
            }

            if ( isset($nouxuper_meta['compare']) && !empty($nouxuper_meta['compare']) ) {
                $compare = $nouxuper_meta['compare'];
            }
            if ( !empty($nouxuper_meta['banner_heading']) ) {
              $banner_heading = $nouxuper_meta['banner_heading'];
            }
            if ( !empty($nouxuper_meta['quickview']) ) {
              $quickview = $nouxuper_meta['quickview'];
            }
            if ( !empty($nouxuper_meta['pagination']) ) {
              $pagination = $nouxuper_meta['pagination'];
            }
            if ( isset($nouxuper_meta['banner_heading_style']) && !empty($nouxuper_meta['banner_heading_style']) ) {
                $banner_heading_style = $nouxuper_meta['banner_heading_style'];
            }
            if ( isset($nouxuper_meta['layout']) && !empty($nouxuper_meta['layout']) ) {
                $layout = $nouxuper_meta['layout'];
            }
        }
    } 

    $post_id = xuper_helpers_get_current_id();
    if($post_id){
      $nouxuper_meta = get_post_meta( $post_id, 'nouxuper_layout_settings', true );
      if ( !empty($nouxuper_meta['sidebar']) ) {
        $sidebar = $nouxuper_meta['sidebar'];
      }
      if ( !empty($nouxuper_meta['banner_heading']) ) {
        $banner_heading = $nouxuper_meta['banner_heading'];
      }
      if ( isset($nouxuper_meta['banner_heading_style']) && !empty($nouxuper_meta['banner_heading_style']) ) {
          $banner_heading_style = $nouxuper_meta['banner_heading_style'];
      }
    }  

    if( !is_active_sidebar('shop-sidebar') ){
      $sidebar = 'hide';
    } 

    if(isset($_GET['shop_layout']) && !empty($_GET['shop_layout']) && intval($_GET['shop_layout'])){
      $layout = intval($_GET['shop_layout']);
    }

    return array('layout' => $layout, 'addtocart' => $addtocart, 'wishlist' => $wishlist, 'compare' => $compare, 'sidebar' => $sidebar, 'banner_heading' => $banner_heading, 'quickview' => $quickview, 'banner_heading_style' => $banner_heading_style, 'pagination' => $pagination);
  }
}

function nouxuper_helpers_get_image_by_id($id, $size, $class = array()){
	$image_attributes = wp_get_attachment_image_src( $id, $size );
	if($image_attributes){
		echo '<img src="'.esc_attr($image_attributes[0]).'" alt="">';
	}
}

function nouxuper_helpers_get_portfolios(){
	$per_page = get_option('posts_per_page');
	if(is_page()){
		$settings = get_post_meta(get_the_ID(), '_portfolio_page', true);
		if(!empty($settings['posts_per_page'])){
			$per_page = $settings['posts_per_page'];
		}
	}
	$args = array('post_type' => 'nouxuper_portfolio', 'post_status' => 'publish', 'posts_per_page' => $per_page);
	return new WP_Query($args);
}

function nouxuper_get_products($atts){
	$per_page = !empty($atts['number']) ? intval($atts['number']) : '8';
	$args = array(
		'post_type' => 'product', 
		'post_status' => 'publish',
		'posts_per_page' => $per_page
		);

	if(!empty($atts['id']) && intval($atts['id'])){
		$args['p'] = $atts['id'];
	}

	if(!empty($atts['paged'])){
		$args['paged'] = intval($atts['paged']);
	}

	if(!empty($atts['ids'])){
		$args['post__in'] = explode(',', $atts['ids']);
	}else{
		if(!empty($atts['cat'])){
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'product_cat',
					'field'    => 'term_id',
					'terms'    => $atts['cat'],
				),
			);
		}
	}
	if(!empty($atts['type'])){
		switch ( $atts['type'] ) {
			case 'featured' :
				$meta_query  = WC()->query->get_meta_query();
				$tax_query   = WC()->query->get_tax_query();
				$tax_query[] = array(
					'taxonomy' => 'product_visibility',
					'field'    => 'name',
					'terms'    => 'featured',
					'operator' => 'IN',
				);
				$args['meta_query'] = $meta_query;
				$args['tax_query']  = $tax_query;
				break;
			case 'onsale' :
				$product_ids_on_sale    = wc_get_product_ids_on_sale();
				$product_ids_on_sale[]  = 0;
				$args['post__in'] = $product_ids_on_sale;
				break;	
			case 'bestsale' :
				$args['meta_key'] = 'total_sales';
				$args['orderby']  = 'meta_value_num';
		}
	}


	$transient_name = 'nouxuper_wc_loop' . substr( md5( wp_json_encode( $args ) . 'products' ), 28 ) . WC_Cache_Helper::get_transient_version( 'product_query' );
	$products            = get_transient( $transient_name );

	if ( false === $products ) {
		$products = new WP_Query( $args );
		set_transient( $transient_name, $products, DAY_IN_SECONDS * 30 );
	}
	
	return $products;
}
?>