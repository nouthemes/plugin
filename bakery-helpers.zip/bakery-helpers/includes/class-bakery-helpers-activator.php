<?php

/**
 * Fired during plugin activation
 *
 * @link       http://nouthemes.com
 * @since      1.0.0
 *
 * @package    Bakery_Helpers
 * @subpackage Bakery_Helpers/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Bakery_Helpers
 * @subpackage Bakery_Helpers/includes
 * @author     nouthemes <nouthemes@gmail.com>
 */
class Bakery_Helpers_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

	public static function install_admin_notice(){
		?>
        <div class="error">
            <p><?php esc_html_e( 'Bakery Theme Helpers is enabled but not effective. It requires Bakery Theme in order to work.', 'bakery-helpers' ); ?></p>
        </div>
        <?php
	}

}
