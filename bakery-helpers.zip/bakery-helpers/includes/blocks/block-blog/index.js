( function( wp ) {
	const {registerBlockType} = wp.blocks; //Blocks API
	const {createElement} = wp.element; //React.createElement
	const {__} = wp.i18n; //translation functions
	const {InspectorControls, MediaUpload} = wp.editor; //Block inspector wrapper
	const {TextControl, SelectControl, ServerSideRender, FormFileUpload, Button} = wp.components; //WordPress form inputs and server-side renderer

	registerBlockType( 'bakery-helpers-blocks/blog', {
		title: noubakery_helpers_blocks_params.block_blog_title, // Block title.
		category:  'bakery-helpers', //category
		attributes:  {
			style : {
				default: '',
			},
			id : {
				default: '',
			},
			img : {
				default: '',
			},
		},
		//display the post title
		edit(props){
			const attributes =  props.attributes;
			const setAttributes =  props.setAttributes;

			//Function to update id attribute
			function changeId(id){
				setAttributes({id});
			}

			//Function to update heading level
			function changeStyle(style){
				setAttributes({style});
			}

			//Function to update heading level
			function changeImage(img_object){
				const {id} = img_object;
				setAttributes({img: id});
			}

			//Display block preview and UI
			return createElement('div', {}, [
				//Preview a block with a PHP render callback
				createElement( ServerSideRender, {
					block: 'bakery-helpers-blocks/blog',
					attributes: attributes
				} ),
				//Block inspector
				createElement( InspectorControls, {},
					[
						//A simple text control for post id
						createElement(SelectControl, {
							value: attributes.style,
							label: __( 'Type of post show' ),
							onChange: changeStyle,
							options: [
					            { value: 'large', label: __( 'Large' ) },
					            { value: 'small', label: __( 'Small' ) }
					        ]
						}),
						//A simple text control for post id
						createElement(TextControl, {
							value: attributes.id,
							label: __( 'ID' ),
							onChange: changeId,
							type: 'number',
							min: 1,
							step: 1
						}),
					
						createElement(MediaUpload, {
							onSelect: changeImage,
							type: 'image',
							render: function( obj ) {
								return createElement( Button, {
									    className: 'components-icon-button image-block-btn is-button is-default is-large',
									    onClick: obj.open
									},
									createElement( 'svg', { className: 'dashicon dashicons-edit', width: '20', height: '20' },
										createElement( 'path', { d: "M2.25 1h15.5c.69 0 1.25.56 1.25 1.25v15.5c0 .69-.56 1.25-1.25 1.25H2.25C1.56 19 1 18.44 1 17.75V2.25C1 1.56 1.56 1 2.25 1zM17 17V3H3v14h14zM10 6c0-1.1-.9-2-2-2s-2 .9-2 2 .9 2 2 2 2-.9 2-2zm3 5s0-6 3-6v10c0 .55-.45 1-1 1H5c-.55 0-1-.45-1-1V8c2 0 3 4 3 4s1-3 3-3 3 2 3 2z" } )
									),
									createElement( 'span', {},
									    __('Select image')
									),
								);
							}
						}),
					]
				)
			] )
		},
		save(){
			return null;//save has to exist. This all we need
		}
	});
} )(
	window.wp
);