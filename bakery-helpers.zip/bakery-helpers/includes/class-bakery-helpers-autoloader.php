<?php
/**
* Autoload class 
*
* @package inc/autoloader
* @author nouthemes [nouthemes@gmail.com]
*/
defined( 'ABSPATH' ) OR exit;

if( !class_exists('Bakery_Helpers_Autoloader') ){


	class Bakery_Helpers_Autoloader 
	{

		/**
		 * Autoloader load method. Load the class.
		 *
		 * @param $class_name
		 */
		public function load( $class_name ) 
		{

			if ( 0 === strpos( $class_name, 'Bakery_Helpers_' ) ) {

				// String to lower
				$class_name = strtolower( $class_name );

				// Format file name
				$file_name = 'class-bakery-helpers-' . str_ireplace( '_', '-', str_ireplace( 'Bakery_Helpers_', '', $class_name ) ) . '.php';
				// Setup the file path
				$file_path = '';

				if ( 0 === strpos( $class_name, 'bakery_helpers_shortcode_' ) ) {
					$file_path .= 'shortcodes/';
				}

				if ( 0 === strpos( $class_name, 'bakery_helpers_blocks_' ) ) {
					$file_path .= 'blocks/';
				}

				// Append file name to clas path
				$file_path .= $file_name;
				// Check & load file
				if ( file_exists( plugin_dir_path( __FILE__ ). $file_path ) ) {
					require_once( plugin_dir_path( __FILE__ ). $file_path );
				}

			}

		}

	}

}