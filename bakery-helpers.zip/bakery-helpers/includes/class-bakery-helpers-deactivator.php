<?php

/**
 * Fired during plugin deactivation
 *
 * @link       http://nouthemes.com
 * @since      1.0.0
 *
 * @package    Bakery_Helpers
 * @subpackage Bakery_Helpers/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Bakery_Helpers
 * @subpackage Bakery_Helpers/includes
 * @author     nouthemes <nouthemes@gmail.com>
 */
class Bakery_Helpers_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
