<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Register the scripts, styles, and blocks needed for the block editor.
 *
 * @package Bakery
 * @since 1.0.4
 * @author nouthemes [nouthemes@gmail.com]
 */
class Bakery_Helpers_Block_Library
{

	/**
	 * Hook in ajax handlers.
	 */
	public static function init() 
	{
		if ( function_exists( 'register_block_type' ) ) {
			add_action( 'init', array( __CLASS__, 'register_blocks' ), 1000000 );
			add_action( 'init', array( __CLASS__, 'register_assets' ), 1000000 );
			add_filter( 'block_categories', array( __CLASS__, 'add_block_category' ) );
		}
	}

	public static function register_blocks(){
		register_block_type(
			'bakery-helpers-blocks/blog',
			array(
				'render_callback' => array( 'Bakery_Helpers_Blocks_Blog', 'render' ),
				'editor_script'   => 'bakery-helpers-blocks-blog',
				'attributes' => [
					'style' => [
						'default' => ''
					],
					'id' => [
						'default' => ''
					],
					'img' => [
						'default' => ''
					],
				]
			)
		);
	}

	public static function register_assets(){
		wp_enqueue_script(
			'bakery-helpers-blocks-blog', BAKERYTHEMEHELPERS_URL . 'includes/blocks/block-blog/index.js', array(
				'wp-api-fetch',
				'wp-blocks',
				'wp-components',
				'wp-compose',
				'wp-data',
				'wp-element',
				'wp-editor',
				'wp-i18n',
				'wp-url'
			), 
			BAKERYTHEMEHELPERS_VERSION,
			true
		);

		wp_localize_script( 'jquery', 'noubakery_helpers_blocks_params', array(
			'ajax_url' 				=> esc_url( admin_url( 'admin-ajax.php' ) ),
			'block_blog_title' => esc_html__('Blog', 'bakery-helpers')
		) );
	}

	/**
	 * Adds a Bakery category to the block inserter.
	 *
	 * @since 1.0.4
	 *
	 * @param array $categories Array of categories.
	 * @return array Array of block categories.
	 */
	public static function add_block_category( $categories ) {
		return array_merge(
			$categories,
			array(
				array(
					'slug'  => 'bakery-helpers',
					'title' => esc_html__( 'Bakery', 'bakery-helpers' ),
					'icon'  => 'bakery-helpers',
				),
			)
		);
	}
}