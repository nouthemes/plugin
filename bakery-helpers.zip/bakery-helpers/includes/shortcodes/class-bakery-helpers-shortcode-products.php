<?php
/**
* 
*/
class Bakery_Helpers_Shortcode_Products
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		if ( empty( $atts ) ) {
			return '';
		}

		$atts = shortcode_atts( array(
			'style' => '',
			'type' => '',
			'ids' => '',
			'cat' => '',
			'number' => '',
			'order_by' => '',
			'col' => '',
		), $atts, 'noubakery_products' );
		
		$col = (!empty($atts['col']) && intval($atts['col'])) ? intval($atts['col']) : 4;
		$products = self::get_products($atts);
		ob_start();
			if($products->have_posts()):

				if(isset($atts['style']) && $atts['style'] != 'slider'){
					?>
					<div class="ps-section__content products">
        				<?php while($products->have_posts()): $products->the_post();?>
        					<div <?php post_class('col-lg-3 col-md-3 col-sm-6 col-xs-12');?>>
        						<?php wc_get_template_part('content', 'product-grid');?>
        					</div>
        				<?php endwhile;?>
            		</div>
					<?php
				}else{
					?>
					<div class="ps-section__content products">
            			<div class="owl-slider owl-slider--best-seller" data-owl-auto="true" data-owl-loop="true" data-owl-speed="5000" data-owl-gap="30" data-owl-nav="true" data-owl-dots="false" data-owl-animate-in="" data-owl-animate-out="" data-owl-item="<?php echo esc_attr($col);?>" data-owl-item-xs="1" data-owl-item-sm="2" data-owl-item-md="3" data-owl-item-lg="<?php echo esc_attr($col);?>" data-owl-nav-left="&lt;i class=&quot;ps-icon--back&quot;&gt;&lt;/i&gt;" data-owl-nav-right="&lt;i class=&quot;ps-icon--next&quot;&gt;&lt;/i&gt;">

            				<?php while($products->have_posts()): $products->the_post();?>
            					<div <?php post_class();?>>
	        						<?php wc_get_template_part('content', 'product-grid');?>
	        					</div>
            				<?php endwhile;?>

            			</div>
            		</div>
					<?php
				}

			endif;wp_reset_postdata();
		return ob_get_clean();
		
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		vc_map( array(
	      	"name" => esc_html__( "Bakery - Products", 'bakery-helpers' ),
	      	"base" => "noubakery_products",
	      	"class" => "",
	      	"category" => esc_html__( "Bakery theme", 'bakery-helpers'),
	      	'description' => esc_html__('Products display type Slider or Grid', 'bakery-helpers'),
    		"params" => array(
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "holder" => "div",
		            "heading" => esc_html__( "Type of section show", 'bakery-helpers' ),
		            "param_name" => "style",
		            "value" => array(esc_html__('Grid', 'bakery-helpers') => 'grid', esc_html__('Slider', 'bakery-helpers') => 'slider'), 
		        ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "holder" => "div",
		            "heading" => esc_html__( "Type of products show", 'bakery-helpers' ),
		            "param_name" => "type",
		            "value" => array(esc_html__('--Select type--', 'bakery-helpers') => '', esc_html__('Recent', 'bakery-helpers') => 'recent', esc_html__('Featured', 'bakery-helpers') => 'featured', esc_html__('Sale', 'bakery-helpers') => 'onsale', esc_html__('Best sale', 'bakery-helpers') => 'bestsale'), 
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "IDs posts, EX: 21,22,23", 'bakery-helpers' ),
		            "param_name" => "ids",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Category ID", 'bakery-helpers' ),
		            "param_name" => "cat",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Number of posts show", 'bakery-helpers' ),
		            "param_name" => "number",
		        ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "heading" => esc_html__( "Column", 'bakery-helpers' ),
		            "param_name" => "col",
		            "value" => array(4 => '4', 3 => '3', 2 => '2'), 
		        ),
	      	)
	    ) );
	}

	private static function get_products($atts){
		
		$per_page = !empty($atts['number']) ? intval($atts['number']) : '8';
		$args = array(
			'post_type' => 'product', 
			'post_status' => 'publish',
			'posts_per_page' => $per_page
			);

		if(!empty($atts['ids'])){
			$args['post__in'] = explode(',', $atts['ids']);
		}else{
			if(!empty($atts['cat'])){
				$args['tax_query'] = array(
					array(
						'taxonomy' => 'product_cat',
						'field'    => 'term_id',
						'terms'    => $atts['cat'],
					),
				);
			}
		}
		switch ( $atts['type'] ) {
			case 'featured' :
				$args['tax_query'][] = array(
                        'taxonomy' => 'product_visibility',
                        'field'    => 'name',
                        'terms'    => 'featured',
                    );
				break;
			case 'onsale' :
				$product_ids_on_sale    = wc_get_product_ids_on_sale();
				$product_ids_on_sale[]  = 0;
				$args['post__in'] = $product_ids_on_sale;
				break;	
			case 'bestsale' :
				$args['meta_key'] = 'total_sales';
				$args['orderby']  = 'meta_value_num';
		}

		return new WP_Query( apply_filters( 'noubakery_products_shortcode_query_args', $args ) );
	}
}
?>