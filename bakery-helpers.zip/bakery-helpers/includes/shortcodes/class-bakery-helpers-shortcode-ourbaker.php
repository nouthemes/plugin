<?php
/**
* 
*/
class Bakery_Helpers_Shortcode_Ourbaker
{
	
	public static function shortcode($atts){
		$atts = shortcode_atts( array(
			'title_top' => '',
			'title' => '',
			'desc' => '',
			'position' => '',
			'img_signature' => '',
			'img_about' => '',
			'class' => '',
		), $atts, 'noubakery_our_baker' );

		ob_start();
			?>
			<div class="ps-section ps-section--about <?php echo esc_attr( !empty($atts['class']) ? $atts['class'] : '' );?>">
		        <div class="container">
		          	<div class="row">
		                <div class="col-lg-7 col-md-7 col-sm-12 col-xs-12 ">
		                  <div class="ps-section__header text-center">
		                  	<?php if(!empty($atts['title_top'])):?>
				        		<div class="ps-section__top"><?php echo esc_html($atts['title_top']);?></div>
				        	<?php endif;?>

				        	<?php if(!empty($atts['title'])):?>
				        		<h3 class="ps-section__title"><?php echo esc_html($atts['title']);?></h3>
				        	<?php endif;?>

		                  </div>
		                  <div class="ps-section__content text-center">
		                  	
		                  	<?php if(!empty($atts['desc'])):?>
		                    <p>“<?php echo esc_html($atts['desc']);?>”</p>
		                    <?php endif;?>

		                    <?php if(!empty($atts['img_signature'])):?>
		                    <div class="ps-about__sign text-center mb-30 mt-40">
		                    	<?php echo noubakery_get_image_by_id($atts['img_signature'], 'full');?>
		                    </div>
		                    <?php endif;?>

		                 
		                    <?php if(!empty($atts['position'])):?>
				        		<p class="ps-about-sign"><?php echo esc_html($atts['position']);?></p>
				        	<?php endif;?>

		                  </div>
		                </div>

		                <?php if(!empty($atts['img_about'])):?>
		                <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12 ">
		                	<?php echo noubakery_get_image_by_id($atts['img_about'], 'full');?>
		                </div>
		                <?php endif;?>

		          	</div>
		        </div>
		    </div>
			<?php
		return ob_get_clean();
	}

	/**
	 * Map shortcode Our Baker
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map()
	{
		if(function_exists('vc_map')):
			vc_map( array(
		      	"name" => esc_html__( "Bakery - Our baker", "bakery-helpers" ),
		      	"base" => "noubakery_our_baker",
		      	"class" => "",
		      	"category" => esc_html__( "Bakery theme", "bakery-helpers"),
		      	"params" => array(
			        array(
			            "type" => "textfield",
			            "holder" => "div",
			            "class" => "",
			            "heading" => esc_html__( "Title top", "bakery-helpers" ),
			            "param_name" => "title_top",
			        ),
			        array(
			            "type" => "textfield",
			            "holder" => "div",
			            "class" => "",
			            "heading" => esc_html__( "Title", "bakery-helpers" ),
			            "param_name" => "title",
			        ),
			        array(
			            "type" => "textfield",
			            "class" => "",
			            "heading" => esc_html__( "Position", "bakery-helpers" ),
			            "param_name" => "position",
			        ),
			        array(
			            "type" => "textarea",
			            "class" => "",
			            "heading" => esc_html__( "Description", "bakery-helpers" ),
			            "param_name" => "desc",
			        ),
			        array(
			            "type" => "attach_image",
			            "class" => "",
			            "heading" => esc_html__( "Image signature", "bakery-helpers" ),
			            "param_name" => "img_signature",
			        ),
			        array(
			            "type" => "attach_image",
			            "class" => "",
			            "heading" => esc_html__( "Image about", "bakery-helpers" ),
			            "param_name" => "img_about",
			        ),
			        array(
			            "type" => "textfield",
			            "class" => "",
			            "heading" => esc_html__( "Custome class", "bakery-helpers" ),
			            "param_name" => "class",
			        ),
		      	)
		    ) );
		endif;
	}
}
?>