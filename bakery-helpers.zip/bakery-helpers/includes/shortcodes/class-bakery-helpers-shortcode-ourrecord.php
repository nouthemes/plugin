<?php 
/**
* 
*/
class Bakery_Helpers_Shortcode_Ourrecord
{
	
	public static function shortcode( $atts, $content = '' ){
		$atts = shortcode_atts( array(
			'title_top' => '',
			'title' => '',
		), $atts, 'noubakery_our_record' );

		ob_start();
		?>
		<div class="ps-section ps-section--award pt-80 pb-40">
	        <div class="container">
	          <div class="ps-section__header text-center mb-50">
	            <?php if(!empty($atts['title_top'])):?>
	        		<div class="ps-section__top"><?php echo esc_html($atts['title_top']);?></div>
	        	<?php endif;?>

	        	<?php if(!empty($atts['title'])):?>
	        		<h3 class="ps-section__title"><?php echo esc_html($atts['title']);?></h3>
	        	<?php endif;?>
	          </div>
	          <div class="ps-section__content">
	            <div class="row"><?php echo do_shortcode($content);?></div>
	          </div>
	        </div>
	    </div> 
		<?php
		return ob_get_clean();
	}

	/**
	 * Map shortcode Our Record
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map()
	{
		if(function_exists('vc_map')):
			vc_map( array(
		      	"name" => esc_html__( "Bakery - Our Record", "bakery-helpers" ),
		      	"base" => "noubakery_our_record",
		      	"class" => "",
		      	"as_parent" => array('only' => 'noubakery_our_record_item'),
		      	"content_element" => true,
			    "show_settings_on_create" => false,
			    "is_container" => true,
		      	"category" => esc_html__( "Bakery theme", "bakery-helpers"),
		      	"params" => array(
			        array(
			            "type" => "textfield",
			            "holder" => "div",
			            "class" => "",
			            "heading" => esc_html__( "Title top", "bakery-helpers" ),
			            "param_name" => "title_top",
			        ),
			        array(
			            "type" => "textfield",
			            "holder" => "div",
			            "class" => "",
			            "heading" => esc_html__( "Title", "bakery-helpers" ),
			            "param_name" => "title",
			        ),
			        
		      	),
		      	"js_view" => 'VcColumnView'
		    ) );
		endif;
	}
}
?>