<?php
/**
* 
*/
class Bakery_Helpers_Shortcode_Contactform
{
	
	public static function shortcode($atts){
		$atts = shortcode_atts( array(
			'title' => '',
			'desc' => '',
		), $atts, 'noubakery_contact_form' );
		
		ob_start();
		?>
		<section class="ps-section ps-section--map">
			<?php 
			$address = noubakery_cs_get_option('noubakery_contact_address');
			$type = noubakery_cs_get_option('noubakery_contact_type', 'address');
			$lng = noubakery_cs_get_option('noubakery_contact_lng');
			$lat = noubakery_cs_get_option('noubakery_contact_lat');
			$zoom = noubakery_cs_get_option('noubakery_contact_map_zoom', 17);

			$display = false;

			if($type == 'coordinates'){
				if(!empty($lng) && !empty($lat)){
					$display = true;
				}
			}else{
				if(!empty($address)){
					$display = true;
				}
			}
			if(!empty($display)):
			?>
	        <div id="contact-map" data-type="<?php echo esc_attr($type);?>" data-lat="<?php echo esc_attr($lat);?>" data-lng="<?php echo esc_attr($lng);?>" data-address="<?php echo esc_attr($address);?>" data-zoom="<?php echo intval($zoom);?>"></div>
	        <?php endif;?>

	        <div class="ps-delivery">
	          <div class="ps-delivery__header">
	            <?php if(!empty($atts['title'])):?><h3><?php echo esc_html($atts['title']);?></h3><?php endif;?>
	            <?php if(!empty($atts['desc'])): echo wpautop(esc_html($atts['desc']));endif;?>
	          </div>
	          <div class="ps-delivery__content">
	            <form class="ps-delivery__form" action="<?php echo esc_url(home_url('/'));?>" method="post">
	              <div class="form-group">
	                <label><?php esc_html_e('Name', 'bakery-helpers');?><span>*</span></label>
	                <input class="form-control" type="text" name="name">
	              </div>
	              <div class="form-group">
	                <label><?php esc_html_e('Email', 'bakery-helpers');?><span>*</span></label>
	                <input class="form-control" type="email" name="email">
	              </div>
	              <div class="form-group">
	                <label><?php esc_html_e('Phone Number', 'bakery-helpers');?><span>*</span></label>
	                <input class="form-control" type="text" name="phone">
	              </div>
	              <div class="form-group">
	                <label><?php esc_html_e('Your message', 'bakery-helpers');?><span>*</span></label>
	                <textarea class="form-control" name="content"></textarea>
	              </div>
	              <div class="form-group text-center">
	                <button class="ps-btn noubakery-contact__submit"><?php esc_html_e('Send Message', 'bakery-helpers');?><i class="fa fa-angle-right"></i></button>
	              </div>
	            </form>
	          </div>
	        </div>
	    </section>
		<?php
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Bakery - Contact form", "bakery-helpers" ),
	      	"base" => "noubakery_contact_form",
	      	"class" => "",
	      	"category" => esc_html__( "Bakery theme", "bakery-helpers"),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", "bakery-helpers" ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textarea",
		            "class" => "",
		            "heading" => esc_html__( "Description", "bakery-helpers" ),
		            "param_name" => "desc",
		        )
	      	)
	    ) );
		endif;
	}
}