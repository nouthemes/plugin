<?php
/**
* @since 1.0.3
*/
class Bakery_Helpers_Shortcode_Contactform
{
	
	public static function shortcode($atts){
		$atts = shortcode_atts( array(
			'title' => '',
			'name_label' => '',
			'email_label' => '',
			'phone_label' => '',
			'message_label' => '',
			'button_label' => '',
			'desc' => '',
		), $atts, 'noubakery_contact_form' );
		
		ob_start();
		?>
		<section class="ps-section ps-section--map">
			<?php 
			$address = noubakery_cs_get_option('noubakery_contact_address');
			$type = noubakery_cs_get_option('noubakery_contact_type', 'address');
			$lng = noubakery_cs_get_option('noubakery_contact_lng');
			$lat = noubakery_cs_get_option('noubakery_contact_lat');
			$zoom = noubakery_cs_get_option('noubakery_contact_map_zoom', 17);

			$display = false;

			if($type == 'coordinates'){
				if(!empty($lng) && !empty($lat)){
					$display = true;
				}
			}else{
				if(!empty($address)){
					$display = true;
				}
			}
			if(!empty($display)):

				$name_label = isset($atts['name_label']) && !empty($atts['name_label']) ? $atts['name_label'] : esc_html__('Name', 'bakery-helpers');
				$phone_label = isset($atts['phone_label']) && !empty($atts['phone_label']) ? $atts['phone_label'] : esc_html__('Phone Number', 'bakery-helpers');
				$email_label = isset($atts['email_label']) && !empty($atts['email_label']) ? $atts['email_label'] : esc_html__('Email', 'bakery-helpers');
				$message_label = isset($atts['message_label']) && !empty($atts['message_label']) ? $atts['message_label'] : esc_html__('Your message', 'bakery-helpers');
				$button_label = isset($atts['button_label']) && !empty($atts['button_label']) ? $atts['button_label'] : esc_html__('Send Message', 'bakery-helpers');
			?>
	        <div id="contact-map" data-type="<?php echo esc_attr($type);?>" data-lat="<?php echo esc_attr($lat);?>" data-lng="<?php echo esc_attr($lng);?>" data-address="<?php echo esc_attr($address);?>" data-zoom="<?php echo intval($zoom);?>"></div>
	        <?php endif;?>

	        <div class="ps-delivery">
	          <div class="ps-delivery__header">
	            <?php if(!empty($atts['title'])):?><h3><?php echo esc_html($atts['title']);?></h3><?php endif;?>
	            <?php if(!empty($atts['desc'])): echo wpautop(esc_html($atts['desc']));endif;?>
	          </div>
	          <div class="ps-delivery__content">
	            <form class="ps-delivery__form" action="<?php echo esc_url(home_url('/'));?>" method="post">
	              <div class="form-group">
	                <label><?php echo esc_html($name_label);?><span>*</span></label>
	                <input class="form-control" type="text" name="name">
	              </div>
	              <div class="form-group">
	                <label><?php echo esc_html($email_label);?><span>*</span></label>
	                <input class="form-control" type="email" name="email">
	              </div>
	              <div class="form-group">
	                <label><?php echo esc_html($phone_label);?><span>*</span></label>
	                <input class="form-control" type="text" name="phone">
	              </div>
	              <div class="form-group">
	                <label><?php echo esc_html($message_label);?><span>*</span></label>
	                <textarea class="form-control" name="content"></textarea>
	              </div>
	              <div class="form-group text-center">
	                <button class="ps-btn noubakery-contact__submit"><?php echo esc_html($button_label);?><i class="fa fa-angle-right"></i></button>
	              </div>
	            </form>
	          </div>
	        </div>
	    </section>
		<?php
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Bakery - Contact form", "bakery-helpers" ),
	      	"base" => "noubakery_contact_form",
	      	"class" => "",
	      	"category" => esc_html__( "Bakery theme", "bakery-helpers"),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", "bakery-helpers" ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textarea",
		            "class" => "",
		            "heading" => esc_html__( "Description", "bakery-helpers" ),
		            "param_name" => "desc",
		        ),
		        array(
		            "type" => "textfield",
		            "holder" => "",
		            "class" => "",
		            "heading" => esc_html__( "Field label: Name", "bakery-helpers" ),
		            "param_name" => "name_label",
		            "value" => esc_html__('Name', 'bakery-helpers')
		        ),
		        array(
		            "type" => "textfield",
		            "holder" => "",
		            "class" => "",
		            "heading" => esc_html__( "Field label: Email", "bakery-helpers" ),
		            "param_name" => "email_label",
		            "value" => esc_html__('Email', 'bakery-helpers')
		        ),
		        array(
		            "type" => "textfield",
		            "holder" => "",
		            "class" => "",
		            "heading" => esc_html__( "Field label: Phone", "bakery-helpers" ),
		            "param_name" => "phone_label",
		            "value" => esc_html__('Phone Number', 'bakery-helpers')
		        ),
		        array(
		            "type" => "textfield",
		            "holder" => "",
		            "class" => "",
		            "heading" => esc_html__( "Field label: Message", "bakery-helpers" ),
		            "param_name" => "message_label",
		            "value" => esc_html__('Your message', 'bakery-helpers')
		        ),
		        array(
		            "type" => "textfield",
		            "holder" => "",
		            "class" => "",
		            "heading" => esc_html__( "Button label", "bakery-helpers" ),
		            "param_name" => "button_label",
		            "value" => esc_html__('Send Message', 'bakery-helpers')
		        )
	      	)
	    ) );
		endif;
	}
}