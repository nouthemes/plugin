<?php
/**
* 
*/
class Bakery_Helpers_Shortcode_Product_Special
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode($atts) {
		$atts = shortcode_atts( array(
			'ids' => '',
			'style' => '',
		), $atts, 'noubakery_product_special' );
		
		ob_start();
			if(!empty($atts['ids'])):
				$ids = explode(',', $atts['ids']);
				$args = array(
					'post_type' => 'product', 
					'post_status' => 'publish',
					'post__in' => $ids
				);
				$products = new WP_Query($args);
				if($products->have_posts()):
				?>
				<div class="ps-section__content products">
					<div class="ps-product-special <?php echo ($atts['style'] == 'vertical' ? 'ps-product-special--2' : '');?>">
						<?php if($atts['style'] == 'vertical'){
							self::vertical($products);
						}else{
							self::horizontal($products);
						}?>
				    </div>
			    </div>
				<?php	
				endif;
				wp_reset_postdata();
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Post items.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Bakery - Products Special", "bakery-helpers" ),
	      	"base" => "noubakery_product_special",
	      	"class" => "",
	      	"category" => esc_html__( "Bakery theme", "bakery-helpers"),
    		"params" => array(
		        array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Products', 'bakery-helpers' ),
					'param_name' => 'ids',
					'description' => esc_html__( 'Enter List of Products ID. EX: 21,22,23', 'bakery-helpers' ),
				),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "heading" => esc_html__( "Type of slider show", 'bakery-helpers' ),
		            "param_name" => "style",
		            "value" => array(esc_html__('Horizontal', 'bakery-helpers') => 'horizontal', esc_html__('Vertical', 'bakery-helpers') => 'vertical'), 
		        ),
	      	)
	    ) );
		endif;
	}

	private static function horizontal($products){
		?>
		<div class="owl-slider ps-cake-list mb-50" data-owl-auto="true" data-owl-loop="false" data-owl-speed="10000" data-owl-gap="30" data-owl-nav="false" data-owl-dots="false" data-owl-animate-in="" data-owl-animate-out="" data-owl-item="5" data-owl-item-xs="2" data-owl-item-sm="3" data-owl-item-md="4" data-owl-item-lg="5" data-owl-nav-left="&lt;i class=&quot;fa fa-angle-left&quot;&gt;&lt;/i&gt;" data-owl-nav-right="&lt;i class=&quot;fa fa-angle-right&quot;&gt;&lt;/i&gt;">
            <?php 
            while($products->have_posts()): $products->the_post();
            $product = wc_get_product(get_the_ID());
            ?>
            <a class="ps-cake" href="javascript:;">
            	<?php echo wp_kses_post($product->get_image('thumbnail')); ?>
            </a>
            <?php endwhile;?>
        </div>
        <div class="owl-slider ps-cake-detail" data-owl-auto="true" data-owl-loop="false" data-owl-speed="10000" data-owl-gap="0" data-owl-nav="false" data-owl-dots="false" data-owl-animate-in="fadeIn" data-owl-animate-out="fadeOut" data-owl-item="1" data-owl-item-xs="1" data-owl-item-sm="1" data-owl-item-md="1" data-owl-item-lg="1" data-owl-nav-left="&lt;i class=&quot;fa fa-angle-left&quot;&gt;&lt;/i&gt;" data-owl-nav-right="&lt;i class=&quot;fa fa-angle-right&quot;&gt;&lt;/i&gt;">
            <?php 
            while($products->have_posts()): $products->the_post();
            global $post;
            $product = wc_get_product(get_the_ID());
            $class = implode( ' ', array_filter( array(
							            'button',
							            'product_type_' . $product->get_type(),
							            $product->is_purchasable() && $product->is_in_stock() ? 'add_to_cart_button' : '',
							            $product->supports( 'ajax_add_to_cart' ) ? 'ajax_add_to_cart' : '',
							        ) ) );
            ?>
            <div class="ps-cake--detail product">
                <div class="ps-cake__thumbnail">
                	<?php echo wp_kses_post($product->get_image('noubakery_350x490')); ?>
                	<?php woocommerce_show_product_loop_sale_flash();?>
                </div>
                <div class="ps-cake__content">
                    <h3><a class="ps-product__title" href="<?php echo esc_url( $product->get_permalink() ); ?>"><?php the_title();?></a></h3>
                    <?php echo wp_kses_post($post->post_excerpt);?>

                    <p class="ps-cake__total mb-30"><?php esc_html_e('Only Today', 'bakery-helpers');?>: <?php echo wp_kses_post($product->get_price_html()); ?></p>
                    
                    <?php
					      	echo apply_filters( 'woocommerce_sidebar_add_to_cart_link',
								sprintf( '<a data-type="compare" rel="nofollow" href="%s" data-quantity="%s" data-product_id="%s" data-product_sku="%s" class="ps-btn ps-btn--sm product-item-cart %s">%s<i class="fa fa-angle-right"></i></a>',
									esc_url( $product->add_to_cart_url() ),
									esc_attr( isset( $quantity ) ? $quantity : 1 ),
									esc_attr( $product->get_id() ),
									esc_attr( $product->get_sku() ),
									esc_attr( isset( $class ) ? $class : 'button' ),
									esc_html( $product->add_to_cart_text() )
								),
							$product );
					      	?>
                </div>
            </div>
            <?php endwhile;?>
        </div>
		<?php
	}

	private static function vertical($products){
		?>
		<div class="row">
            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 ">
              <div class="slick ps-cake-list">
                <?php 
	            while($products->have_posts()): $products->the_post();
	            $product = wc_get_product(get_the_ID());
	            ?>
	            <div class="slick-item"><a class="ps-cake" href="javascript:;"><?php echo wp_kses_post($product->get_image('thumbnail')); ?></a></div>
	            <?php endwhile;?>
              </div>
            </div>

            <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 ">
            	<div class="slick ps-cake-detail">
	              	<?php 
		            while($products->have_posts()): $products->the_post();
		            global $post;
		            $product = wc_get_product(get_the_ID());
		            $class = implode( ' ', array_filter( array(
								            'button',
								            'product_type_' . $product->get_type(),
								            $product->is_purchasable() && $product->is_in_stock() ? 'add_to_cart_button' : '',
								            $product->supports( 'ajax_add_to_cart' ) ? 'ajax_add_to_cart' : '',
								        ) ) );
		            ?>
		            <div class="ps-cake--detail ps-cake--detail--2 product">
                        <div class="ps-cake__thumbnail">
                        	<?php echo wp_kses_post($product->get_image('noubakery_350x490')); ?>
	                    	<?php woocommerce_show_product_loop_sale_flash();?>
                        </div>
                        <div class="ps-cake__content">
                            <h3>
                            	<a class="ps-product__title" href="<?php echo esc_url( $product->get_permalink() ); ?>">
                            		<?php the_title();?>
                            	</a>
                            </h3>
	                    	<?php echo wp_kses_post($post->post_excerpt);?>

                            <p class="ps-cake__total mb-30"><?php esc_html_e('Only Today', 'bakery-helpers');?>: <?php echo wp_kses_post($product->get_price_html()); ?></p>

                            <?php
					      	echo apply_filters( 'woocommerce_product_special_add_to_cart_link',
								sprintf( '<a data-type="compare" rel="nofollow" href="%s" data-quantity="%s" data-product_id="%s" data-product_sku="%s" class="ps-btn ps-btn--sm product-item-cart %s">%s<i class="fa fa-angle-right"></i></a>',
									esc_url( $product->add_to_cart_url() ),
									esc_attr( isset( $quantity ) ? $quantity : 1 ),
									esc_attr( $product->get_id() ),
									esc_attr( $product->get_sku() ),
									esc_attr( isset( $class ) ? $class : 'button' ),
									esc_html( $product->add_to_cart_text() )
								),
							$product );
					      	?>
					      	
                        </div>
                    </div>
		            <?php endwhile;?>
		        </div>
            </div>
      </div>
		<?php
	}
}
?>