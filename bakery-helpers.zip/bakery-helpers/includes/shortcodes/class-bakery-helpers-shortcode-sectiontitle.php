<?php
/**
* 
*/
class Bakery_Helpers_Shortcode_Sectiontitle
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		$atts = shortcode_atts( array(
			'title' => '',
			'sub' => '',
			'class' => '',
			'title_position' => ''
		), $atts, 'noubakery_section_title' );
		
		ob_start();
			if(!empty($atts['title']) || !empty($atts['sub'])):
			?>
			<div class="ps-section__header <?php echo esc_attr(!empty($atts['class']) ? $atts['class'] : '');?>">
	            <?php if(!empty($atts['title'])):?><h4 class="ps-section__top"><?php echo esc_html($atts['title']);?></h4><?php endif;?>
	            <?php if(!empty($atts['sub'])):?><h3 class="ps-section__title <?php if(!empty($atts['title_position'])):?>ps-section__title--<?php echo esc_attr($atts['title_position']);?><?php endif;?>"><?php echo esc_html($atts['sub']);?></h3><?php endif;?>
	        </div>
			<?php	
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Bakery - Section title", "bakery-helpers" ),
	      	"base" => "noubakery_section_title",
	      	"class" => "",
	      	"category" => esc_html__( "Bakery theme", "bakery-helpers"),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", "bakery-helpers" ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Subtitle", "bakery-helpers" ),
		            "param_name" => "sub",
		        ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "heading" => esc_html__( "Title position", "mastatheme-helpers" ),
		            "param_name" => "title_position",
		            "value" => array(esc_html__('--Select position--', 'bakery-helpers') => '', esc_html__('Left', 'bakery-helpers') => 'left', esc_html__('Full', 'bakery-helpers') => 'full')
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Custome class", "bakery-helpers" ),
		            "param_name" => "class",
		        )
	      	)
	    ) );
		endif;
	}
}
?>