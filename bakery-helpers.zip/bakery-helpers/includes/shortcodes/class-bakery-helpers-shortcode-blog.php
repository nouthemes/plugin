<?php
/**
* 
*/
class Bakery_Helpers_Shortcode_Blog
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		if(empty($atts)){
			return '';
		}

		$atts = shortcode_atts( array(
			'style' => '',
			'id' => '',
			'img' => '',
		), $atts, 'masta_post' );
		
		$args = array('post_type' => 'post', 'p' => $atts['id']);
		$query = new WP_Query($args);
		ob_start();
			if($query->have_posts()):
				while($query->have_posts()): $query->the_post();
				$thumbnail_id = get_post_thumbnail_id(get_the_ID());
				if(!empty($atts['img'])){
					$thumbnail_id = $atts['img'];
				}

				if($atts['style'] == 'small'){
					$images = wp_get_attachment_image_src($thumbnail_id, 'noubakery_555x235');
				}else{
					$images = wp_get_attachment_image_src($thumbnail_id, 'noubakery_555x500');
				}
				?>
				<div class="ps-new <?php if($atts['style'] != 'small'){echo 'ps-new--large';}?>">
					<?php if($images):?><img src="<?php echo esc_attr($images[0]);?>" alt=""><?php endif;?>
	                <div class="ps-new__container">
	                    <header class="ps-new__header">
	                      <p><?php esc_html_e('by', 'bakery-helpers');?><a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) );?>"> <?php the_author();?></a> / <?php the_date(get_option('date_format'));?></p>
	                      <a class="ps-new__title" href="<?php the_permalink();?>"><?php the_title();?></a>
	                    </header>
	                    <div class="ps-new__content">
	                      <p data-number-line="2"><?php echo wp_trim_words( get_the_content(), 15, ' ...' );?></p>
	                      <a class="ps-btn ps-btn--sm" href="<?php the_permalink();?>"><?php esc_html_e('Read more', 'bakery-helpers');?></a>
	                    </div>
	                </div>
                </div>
				<?php
				endwhile;
			endif;wp_reset_postdata();
		return ob_get_clean();
	}

	/**
	 * Map shortcode Post items.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Bakery - Post Item", "bakery-helpers" ),
	      	"base" => "noubakery_post",
	      	"class" => "",
	      	"category" => esc_html__( "Bakery theme", "bakery-helpers"),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "ID", "bakery-helpers" ),
		            "param_name" => "id",
		        ),
		        array(
		            "type" => "attach_image",
		            "class" => "",
		            "heading" => esc_html__( "Custom Featured Image", "bakery-helpers" ),
		            "param_name" => "img",
		        ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "heading" => esc_html__( "Type of post show", 'bakery-helpers' ),
		            "param_name" => "style",
		            "value" => array(esc_html__('Large', 'bakery-helpers') => 'large', esc_html__('Small', 'bakery-helpers') => 'small'), 
		        ),
	      	)
	    ) );
		endif;
	}
}
?>