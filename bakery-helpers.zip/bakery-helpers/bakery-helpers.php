<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              http://nouthemes.com
 * @since             1.0.0
 * @package           Bakery_Helpers
 *
 * @wordpress-plugin
 * Plugin Name:       Bakery helpers
 * Plugin URI:        bakery-helpers
 * Description:       Shortcode for bakery theme
 * Version:           1.0.3
 * Author:            nouthemes
 * Author URI:        http://nouthemes.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       bakery-helpers
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! defined( 'BAKERYTHEMEHELPERS_DIR' ) ) {
	/**
	 *
	 */
	define( 'BAKERYTHEMEHELPERS_DIR', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'BAKERYTHEMEHELPERS_URL' ) ) {
	/**
	 *
	 */
	define( 'BAKERYTHEMEHELPERS_URL', plugin_dir_url( __FILE__ ) );
}

if ( ! defined( 'CS_OPTION' ) ) {
	/**
	 *
	 */
	define( 'CS_OPTION', '_noubakery_options' );
}
/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-bakery-helpers-activator.php
 */
function activate_bakery_helpers() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-bakery-helpers-activator.php';
	Bakery_Helpers_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-bakery-helpers-deactivator.php
 */
function deactivate_bakery_helpers() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-bakery-helpers-deactivator.php';
	Bakery_Helpers_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_bakery_helpers' );
register_deactivation_hook( __FILE__, 'deactivate_bakery_helpers' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'bakery-helpers-functions.php';
require plugin_dir_path( __FILE__ ) . 'includes/class-bakery-helpers.php';

/**
 * Check theme active.
 *
 * @since    1.0.0
 */
if( ! function_exists( 'bakery_helpers_install' ) ) {
    function bakery_helpers_install() {
        if( 'bakery' != get_option( 'template' ) ) {
            add_action( 'admin_notices', array('Bakery_Helpers_Activator', 'install_admin_notice') );
        }
    }
}
add_action( 'plugins_loaded', 'bakery_helpers_install', 11 );

add_action('vc_before_init', 'shortcodes_container');

function shortcodes_container(){
	if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	    class WPBakeryShortCode_Noubakery_Our_Record extends WPBakeryShortCodesContainer {
	    }
	    class WPBakeryShortCode_Noubakery_Our_Team extends WPBakeryShortCodesContainer {
	    }
	    class WPBakeryShortCode_Noubakery_Brand extends WPBakeryShortCodesContainer {
	    }
	    class WPBakeryShortCode_Noubakery_Testimonial extends WPBakeryShortCodesContainer {
	    }
	    class WPBakeryShortCode_Noubakery_Quote extends WPBakeryShortCodesContainer {
	    }
	}
	if ( class_exists( 'WPBakeryShortCode' ) ) {
	    class WPBakeryShortCode_Noubakery_Our_Record_Item extends WPBakeryShortCode {
	    }
	    class WPBakeryShortCode_Noubakery_Our_Team_Item extends WPBakeryShortCode {
	    }
	    class WPBakeryShortCode_Noubakery_Brand_Item extends WPBakeryShortCode {
	    }
	    class WPBakeryShortCode_Noubakery_Testimonial_Item extends WPBakeryShortCode {
	    }
	    class WPBakeryShortCode_Noubakery_Quote_Item extends WPBakeryShortCode {
	    }
	}
}


/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_bakery_helpers() {

	$plugin = new Bakery_Helpers();
	$plugin->run();

}
run_bakery_helpers();