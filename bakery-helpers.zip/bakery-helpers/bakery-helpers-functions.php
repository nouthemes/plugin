<?php
/**
 *
 * Get option
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! function_exists( 'noubakery_cs_get_option' ) ) {
  function noubakery_cs_get_option( $option_name = '', $default = '' ) {

    $options = apply_filters( 'noubakery_cs_get_option', get_option( CS_OPTION ), $option_name, $default );

    if( ! empty( $option_name ) && ! empty( $options[$option_name] ) ) {
      return $options[$option_name];
    } else {
      return ( ! empty( $default ) ) ? $default : null;
    }

  }
}

/**
 * Get post like
 *
 * @package Masta
 * @since 1.0
 * @author nouthemes [nouthemes@gmail.com]
 */

if(!function_exists('noubakery_post_like')){
	function noubakery_post_like($id = null) 
	{
		$post_id = noubakery_get_current_id();
		if($id){
			$post_id = $id;
		}
		$meta = get_post_meta($post_id, '_post_like_count', true);

		if ( is_numeric( $meta ) && $meta > 0 ) { 
			$number = noubakery_format_count($meta);
		} else {
			$number = 0;
		}
			
	    return $number;
	}
}


/**
 * Format number with K, M, B
 *
 * @package Masta
 * @since 1.0
 * @author nouthemes [nouthemes@gmail.com]
 */
if(!function_exists('noubakery_format_count')){
	function noubakery_format_count( $number ) {
		$precision = 2;
		if ( $number >= 1000 && $number < 1000000 ) {
			$formatted = number_format( $number/1000, $precision ).'K';
		} else if ( $number >= 1000000 && $number < 1000000000 ) {
			$formatted = number_format( $number/1000000, $precision ).'M';
		} else if ( $number >= 1000000000 ) {
			$formatted = number_format( $number/1000000000, $precision ).'B';
		} else {
			$formatted = $number; // Number is less than 1000
		}
		$formatted = str_replace( '.00', '', $formatted );
		return $formatted;
	}
}


/**
 * Get current IP address
 *
 * @package Masta
 * @since 1.0
 * @author nouthemes [nouthemes@gmail.com]
 */
if(!function_exists('noubakery_get_ip')){
	function noubakery_get_ip() {
		if ( isset( $_SERVER['HTTP_CLIENT_IP'] ) && ! empty( $_SERVER['HTTP_CLIENT_IP'] ) ) {
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		} elseif ( isset( $_SERVER['HTTP_X_FORWARDED_FOR'] ) && ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} else {
			$ip = ( isset( $_SERVER['REMOTE_ADDR'] ) ) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
		}
		$ip = filter_var( $ip, FILTER_VALIDATE_IP );
		$ip = ( $ip === false ) ? '0.0.0.0' : $ip;
		return $ip;
	}
}


if(!function_exists('noubakery_already_liked')){
	function noubakery_already_liked( $post_id, $is_comment = null ) {
		
		$post_users = NULL;
		$user_id = NULL;

		if ( is_user_logged_in() ) { // user is logged in

			$user_id = get_current_user_id();
			$post_meta_users = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_liked" ) : get_post_meta( $post_id, "_user_liked" );
			
			if ( count( $post_meta_users ) != 0 ) {
				$post_users = $post_meta_users[0];
			}

		} else { // user is anonymous

			$user_id = noubakery_get_ip();
			$post_meta_users = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_IP" ) : get_post_meta( $post_id, "_user_IP" ); 
			
			if ( count( $post_meta_users ) != 0 ) { // meta exists, set up values
				$post_users = $post_meta_users[0];
			}
		}

		if ( is_array( $post_users ) && in_array( $user_id, $post_users ) ) {
			return true;
		} else {
			return false;
		}
	}
}

/**
 * Utility returns the button icon for "like" action
 * @since    1.0
 */
if(!function_exists('noubakery_get_liked_icon')){
	function noubakery_get_liked_icon() {
		$loved_icon = noubakery_cs_get_option('noubakery_loved_icon', 'fa fa-heart');
		$icon = ' <i class="'.esc_attr( $loved_icon ).'"></i>';
		return $icon;
	}
}	

/**
 * Utility returns the button icon for "unlike" action
 * @since   1.0
 */
if(!function_exists('noubakery_get_unliked_icon')){
	function noubakery_get_unliked_icon() {
		$love_icon = noubakery_cs_get_option('noubakery_love_icon', 'fa fa-heart-o');
		$icon = '<i class="'.esc_attr( $love_icon ).'"></i>';
		return $icon;
	}
}	

if(!function_exists('noubakery_button_like')){
	function noubakery_button_like($post_id, $class = '', $icon = '', $count = '', $title = '', $echo = true)
	{
		if(empty($title)){
			$title = esc_html__('Like', 'bakery');
		}

		if(empty($icon)){
			$icon = noubakery_get_unliked_icon();
		}

		$liked = noubakery_already_liked($post_id);
		if($liked){
			$class = esc_attr( 'liked', 'bakery' );
			$title = esc_html__( 'Unlike', 'bakery' );
			$icon = noubakery_get_liked_icon();
		}

		$output = '<a data-id="'.intval($post_id).'" class="post-like like '.esc_attr($class).'" href="#">' . esc_attr( $title ) . ''.wp_kses_post($icon).'<span><i>'.noubakery_post_like($post_id).'</i></span></a>';

		$display_button = noubakery_cs_get_option('noubakery_post_like');
		if(empty($display_button)){
			$output = '';
		}

		if($echo){
			echo $output;
		}else{
			return $output;
		}
	}
}

/**
* Single share post
*
*/
if(!function_exists('noubakery_share_post')){
	function noubakery_share_post()
	{
		$facebook = noubakery_cs_get_option('noubakery_single_share_facebook');
		$google = noubakery_cs_get_option('noubakery_single_share_google');
		$twitter = noubakery_cs_get_option('noubakery_single_share_twitter');
		if( !empty($facebook) || !empty($google) || !empty($twitter) ):
		?>
		
          <?php if(!empty($facebook)):?>
          <a href="#" data-type="facebook" class="share facebook" ><i class="fa fa-facebook"></i><?php esc_html_e('Share', 'bakery');?></a>
          <?php endif;?>
          <?php if(!empty($twitter)):?>
          <a href="#" data-type="twitter" class="share twitter" ><i class="fa fa-twitter"></i><?php esc_html_e('Tweet', 'bakery');?></a>
          <?php endif;?>
        
		<?php
		endif;
	}
}
?>