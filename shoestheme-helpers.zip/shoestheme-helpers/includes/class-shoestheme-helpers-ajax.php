<?php

/**
 * AJAX handler
 *
 * @link       http://nouthemes.com/
 * @since      1.0.0
 *
 * @package    Shoestheme_Helpers
 * @subpackage Shoestheme_Helpers/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Shoestheme_Helpers
 * @subpackage Shoestheme_Helpers/includes
 * @author     Nouthemes.com <nouthemes@gmail.com>
 */
class Shoestheme_Helpers_Ajax {

	/**
	 * Hook in ajax handlers.
	 */
	public static function init() 
	{
		self::add_ajax_events();
	}

	/**
	 * Hook in methods - uses WordPress ajax handlers (admin-ajax).
	 */
	public static function add_ajax_events() 
	{
		
		$ajax_events = array(
			'post_like',
			'wishlist',
			'compare',
			'remove_product_from_lists',
			'email_contact',

		);

		foreach ( $ajax_events as $ajax_event ) {
			add_action( 'wp_ajax_shoestheme_helpers_' . $ajax_event, array( __CLASS__, $ajax_event ) );
			add_action( 'wp_ajax_nopriv_shoestheme_helpers_' . $ajax_event, array( __CLASS__, $ajax_event ) );
		}
	}

	public static function email_contact()
	{
		$status = array('status' => '0', 'html' => '');

		if( !empty($_POST['nonce'] ) && wp_verify_nonce( $_POST['nonce'], 'noushoes-theme-nonce' ) ){
			$status['status'] = 2;
			if(!empty($_POST['name']) && !empty($_POST['email']) && !empty($_POST['content']) && is_email($_POST['email'])){
				$subject = sprintf(esc_html__('[%s] Email from contact form', 'shoestheme-helpers'), get_bloginfo('name'));
			
					$message = sprintf(esc_html__('This email was sent from form contact on website %s', 'shoestheme-helpers'), get_bloginfo('name'))." \n\n\n";
					$message .= esc_html__('Name:', 'shoestheme-helpers')." ".esc_html($_POST['name'])." \n\n";
					$message .= esc_html__('Email:', 'shoestheme-helpers')." ".esc_html($_POST['email'])." \n\n";
					$message .= esc_html__('Comments:', 'shoestheme-helpers')."\n ".wp_kses_post($_POST['content'])."";
					
				Shoestheme_Helpers_Email::send( get_option('admin_email'), $subject, $message );
				$status['status'] = 1;
			}
		}

		wp_send_json($status);
		exit();
	}

	public static function post_like() {
		// Security
		$nonce = isset( $_POST['security'] ) ? sanitize_text_field( $_POST['security'] ) : 0;
		
		if ( !wp_verify_nonce( $nonce, 'noushoes-theme-nonce' ) ) {
			exit( esc_html__( 'Not permitted', 'shoestheme-helpers' ) );
		}
		// Test if javascript is disabled
		$disabled = ( isset( $_POST['disabled'] ) && $_POST['disabled'] == true ) ? true : false;
		// Test if this is a comment
		$is_comment = ( isset( $_POST['is_comment'] ) && $_POST['is_comment'] == 1 ) ? 1 : 0;
		// Base variables
		$post_id = ( isset( $_POST['post_id'] ) && is_numeric( $_POST['post_id'] ) ) ? $_POST['post_id'] : '';
		
		$result = array();
		$post_users = NULL;
		$like_count = 0;

		// Get plugin options
		if ( $post_id != '' ) {

			$count = get_post_meta( $post_id, "_post_like_count", true );
			$count = ( isset( $count ) && is_numeric( $count ) ) ? $count : 0;
			
			if ( !shoestheme_helpers_already_liked( $post_id, $is_comment ) ) { // Like the post

				if ( is_user_logged_in() ) { // user is logged in

					$user_id = get_current_user_id();
					$post_users = shoestheme_helpers_post_user_likes( $user_id, $post_id, $is_comment );
					
					if ( $is_comment == 1 ) {

						// Update User & Comment
						$user_like_count = get_user_option( "_comment_like_count", $user_id );
						$user_like_count =  ( isset( $user_like_count ) && is_numeric( $user_like_count ) ) ? $user_like_count : 0;
						update_user_option( $user_id, "_comment_like_count", ++$user_like_count );
						
						if ( $post_users ) {
							update_comment_meta( $post_id, "_user_comment_liked", $post_users );
						}

					} else {

						// Update User & Post
						$user_like_count = get_user_option( "_user_like_count", $user_id );
						$user_like_count =  ( isset( $user_like_count ) && is_numeric( $user_like_count ) ) ? $user_like_count : 0;
						update_user_option( $user_id, "_user_like_count", ++$user_like_count );
						
						if ( $post_users ) {
							update_post_meta( $post_id, "_user_liked", $post_users );
						}
					}

				} else { // user is anonymous

					$user_ip = shoestheme_helpers_get_ip();
					$post_users = shoestheme_helpers_post_ip_likes( $user_ip, $post_id, $is_comment );
					
					// Update Post
					if ( $post_users ) {
						if ( $is_comment == 1 ) {
							update_comment_meta( $post_id, "_user_comment_IP", $post_users );
						} else { 
							update_post_meta( $post_id, "_user_IP", $post_users );
						}
					}

				}

				$like_count = ++$count;
				$response['status'] = "liked";
				$response['icon'] = shoestheme_helpers_get_liked_icon();

			} else { // Unlike the post

				if ( is_user_logged_in() ) { // user is logged in

					$user_id = get_current_user_id();
					$post_users = shoestheme_helpers_post_user_likes( $user_id, $post_id, $is_comment );
					// Update User
					if ( $is_comment == 1 ) {
						$user_like_count = get_user_option( "_comment_like_count", $user_id );
						$user_like_count =  ( isset( $user_like_count ) && is_numeric( $user_like_count ) ) ? $user_like_count : 0;
						if ( $user_like_count > 0 ) {
							update_user_option( $user_id, "_comment_like_count", --$user_like_count );
						}
					} else {
						$user_like_count = get_user_option( "_user_like_count", $user_id );
						$user_like_count =  ( isset( $user_like_count ) && is_numeric( $user_like_count ) ) ? $user_like_count : 0;
						if ( $user_like_count > 0 ) {
							update_user_option( $user_id, '_user_like_count', --$user_like_count );
						}
					}
					// Update Post
					if ( $post_users ) {	
						$uid_key = array_search( $user_id, $post_users );
						unset( $post_users[$uid_key] );
						if ( $is_comment == 1 ) {
							update_comment_meta( $post_id, "_user_comment_liked", $post_users );
						} else { 
							update_post_meta( $post_id, "_user_liked", $post_users );
						}
					}
				} else { // user is anonymous
					$user_ip = shoestheme_helpers_get_ip();
					$post_users = shoestheme_helpers_post_ip_likes( $user_ip, $post_id, $is_comment );
					// Update Post
					if ( $post_users ) {
						$uip_key = array_search( $user_ip, $post_users );
						unset( $post_users[$uip_key] );
						if ( $is_comment == 1 ) {
							update_comment_meta( $post_id, "_user_comment_IP", $post_users );
						} else { 
							update_post_meta( $post_id, "_user_IP", $post_users );
						}
					}
				}

				$like_count = ( $count > 0 ) ? --$count : 0; // Prevent negative number
				$response['status'] = "unliked";
				$response['icon'] = shoestheme_helpers_get_unliked_icon();
			}

			if ( $is_comment == 1 ) {
				update_comment_meta( $post_id, "_comment_like_count", $like_count );
				update_comment_meta( $post_id, "_comment_like_modified", date( 'Y-m-d H:i:s' ) );
			} else { 
				update_post_meta( $post_id, "_post_like_count", $like_count );
				update_post_meta( $post_id, "_post_like_modified", date( 'Y-m-d H:i:s' ) );
			}

			$response['count'] = shoestheme_helpers_post_like($post_id);

			$liked = shoestheme_helpers_already_liked($post_id);
			if($liked){
				$class = esc_attr( 'liked', 'shoestheme-helpers' );
				$title = esc_html__( 'Unlike', 'shoestheme-helpers' );
				$icon = shoestheme_helpers_get_liked_icon();
			}else{
				$title = esc_html__('Like', 'shoestheme-helpers');
				$icon = shoestheme_helpers_get_unliked_icon();
			}

			$response['button'] = '<span data-id="'.intval($post_id).'" class="post-like like '.esc_attr($class).'">'.wp_kses_post($icon).' ' . esc_html( $title ) . '</span>';

			wp_send_json( $response );
			exit();
		}
	}

	public static function remove_product_from_lists(){
		$status = array('status' => '0', 'html' => '');
		if( !empty($_POST['product_id']) && !empty($_POST['type'] ) && !empty($_POST['nonce'] ) && wp_verify_nonce( $_POST['nonce'], 'noushoes-theme-nonce' ) ){

			switch ($_POST['type']) {
				case 'wishlist':
					$delete = Shoestheme_Helpers_Wishlist::delete($_POST['product_id']);
					$status['status'] = $delete;
					break;
				case 'compare':
					$delete = Shoestheme_Helpers_Compare::delete($_POST['product_id']);
					$status['status'] = $delete;
					break;
			}
		}
		wp_send_json($status);
		exit();
	}

	public static function wishlist(){
		$status = array('status' => '0', 'html' => '');
		if( !empty($_POST['product_id'] ) && !empty($_POST['nonce'] ) && wp_verify_nonce( $_POST['nonce'], 'noushoes-theme-nonce' ) ){
			$wishlist = true;
			switch ($_POST['do_action']) {
				case 'add':
					$wishlist = Shoestheme_Helpers_Wishlist::add($_POST['product_id']);
					if($wishlist){
						$status['html'] = esc_html__('added to wishlist.', 'shoestheme-helpers');
					}else{
						$status['html'] = esc_html__('has exists in wishlist.', 'shoestheme-helpers');
					}
					break;
				case 'delete':
					$wishlist = Shoestheme_Helpers_Wishlist::delete($_POST['product_id']);
					if($wishlist){
						$status['html'] = esc_html__('Delete from wishlist successfully.', 'shoestheme-helpers');
					}else{
						$status['html'] = esc_html__('not exists in wishlist.', 'shoestheme-helpers');
					}
					break;
			}

			if($wishlist){
				$status['status'] = '1';
			}
		}
		wp_send_json($status);
		exit();
	}

	public static function compare(){
		$status = array('status' => '0', 'html' => '');
		if( !empty($_POST['product_id']) && !empty($_POST['nonce']) && wp_verify_nonce( $_POST['nonce'], 'noushoes-theme-nonce' ) ){
			$compare = false;
			switch ($_POST['do_action']) {
				case 'add':
					$compare = Shoestheme_Helpers_Compare::add($_POST['product_id']);
					if($compare){
						$status['html'] = esc_html__('added to compare.', 'shoestheme-helpers');
					}else{
						$status['html'] = esc_html__('has exists in compare list.', 'shoestheme-helpers');
					}
					$status['product_id'] = $compare;
					break;
				case 'delete':
					$compare = Shoestheme_Helpers_Compare::delete($_POST['product_id']);
					if($compare){
						$status['html'] = esc_html__('Delete from compare list successfully.', 'shoestheme-helpers');
					}else{
						$status['html'] = esc_html__('not exists in compare list.', 'shoestheme-helpers');
					}
					break;
			}

			if($compare){
				$status['status'] = '1';
			}
		}
		wp_send_json($status);
		exit();
	}

}
