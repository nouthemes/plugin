<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       http://nouthemes.com/
 * @since      1.0.0
 *
 * @package    Shoestheme_Helpers
 * @subpackage Shoestheme_Helpers/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Shoestheme_Helpers
 * @subpackage Shoestheme_Helpers/public
 * @author     Nouthemes.com <nouthemes@gmail.com>
 */
class Shoestheme_Helpers_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Shoestheme_Helpers_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Shoestheme_Helpers_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/shoestheme-helpers-public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Shoestheme_Helpers_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Shoestheme_Helpers_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/shoestheme-helpers-public.js', array( 'jquery' ), $this->version, false );

	}

	public function social(){
		shoestheme_helpers_button_like(get_the_ID());
		shoestheme_helpers_share_post();
	}

	public function widgets_init(){
		register_widget( 'Shoestheme_Helpers_Widget_Banner' );
		register_widget( 'Shoestheme_Helpers_Widget_Recent_Posts' );
		register_widget( 'Shoestheme_Helpers_Widget_Categories' );
		register_widget( 'Shoestheme_Helpers_Widget_About' );
	}

}
