<?php
/**
* Wishlist class
*
* @package classes
* @author nouthemes [nouthemes@gmail.com]
* @since 1.0
*/
defined( 'ABSPATH' ) OR exit;

class Shoestheme_Helpers_Wishlist{

	public static function add( $product_id ){

		if(empty($product_id)){
			return false;
		}

		if(!intval($product_id)){
			return false;
		}

		if(self::is_product_in_wishlist( $product_id )){
			return false;
		}

		$wishlist = $_SESSION['noushoes_wl_products'];

		if ( is_user_logged_in() ) {
			$user_id = get_current_user_id();
			$wishlist = get_user_meta($user_id, 'noushoes_wl_products', true);
		}

		array_push($wishlist, $product_id);			
		$_SESSION['noushoes_wl_products'] = self::format_array(array_unique($wishlist));

		if ( is_user_logged_in() ) {
			$user_id = get_current_user_id();
			update_user_meta($user_id, 'noushoes_wl_products', self::format_array(array_unique($wishlist)));
		}

		return true;
	}

	public static function delete( $product_id ){
		if(self::is_product_in_wishlist( $product_id )){
			$wishlist = $_SESSION['noushoes_wl_products'];
			if ( is_user_logged_in() ) {
				$user_id = get_current_user_id();
				$wishlist = get_user_meta($user_id, 'noushoes_wl_products', true);
			}

		    if(($key = array_search($product_id, $wishlist)) !== false) {
			    unset($wishlist[$key]);
			    $_SESSION['noushoes_wl_products'] = self::format_array(array_unique($wishlist));

			    if ( is_user_logged_in() ) {
					$user_id = get_current_user_id();
					update_user_meta($user_id, 'noushoes_wl_products', self::format_array(array_unique($wishlist)));
				}
			    return true;
			}
		}else{
			return false;
		}
	}

	/**
     * Check if the product exists in the wishlist.
     *
     * @param int $product_id Product id to check
     * @return bool
     * @since 1.0
     */
    public static function is_product_in_wishlist( $product_id ) {
	    $exists = false;
	    $wishlist = self::get_products_in_wishlist();
	    if( $wishlist && is_array( $wishlist ) ) {
		    foreach ( $wishlist as $item ) {
			    if ( $item == $product_id ) {
				    $exists = true;
			    }
		    }
	    }

	    return apply_filters( 'noushoes_is_product_in_wishlist', $exists, $product_id );
    }

    public static function get_products_in_wishlist(){
    	$wishlist_session = $_SESSION['noushoes_wl_products'];

    	if ( !is_user_logged_in() ) {
    		return self::format_array(array_unique($wishlist_session));
    	}

    	$new_wishlist = array();
    	$user_id = get_current_user_id();
		$wishlist = get_user_meta($user_id, 'noushoes_wl_products', true);
		if(is_array($wishlist) && is_array($wishlist_session)){
			$new_wishlist = array_merge($wishlist, $wishlist_session);
		}else{
			$new_wishlist = $wishlist_session;
		}
		update_user_meta($user_id, 'noushoes_wl_products', self::format_array(array_unique($new_wishlist)));
		return self::format_array(array_unique($new_wishlist));
    }

    public static function get_remove_url($product_id){
    	$permalink = get_permalink(cs_get_option('noushoes_shop_wishlist_page_id'));
    	return esc_url(add_query_arg( 'remove_item_wishlist', $product_id, $permalink ));
    }

    private static function format_array($array){
    	$reset_array_keys = array();
		foreach($array as $value) {
		    $reset_array_keys[] = $value;
		}
		return $reset_array_keys;
    }

	
}
