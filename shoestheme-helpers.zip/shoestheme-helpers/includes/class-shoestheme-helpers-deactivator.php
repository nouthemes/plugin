<?php

/**
 * Fired during plugin deactivation
 *
 * @link       http://nouthemes.com/
 * @since      1.0.0
 *
 * @package    Shoestheme_Helpers
 * @subpackage Shoestheme_Helpers/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Shoestheme_Helpers
 * @subpackage Shoestheme_Helpers/includes
 * @author     Nouthemes.com <nouthemes@gmail.com>
 */
class Shoestheme_Helpers_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
