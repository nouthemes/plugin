<?php 
/**
* 
*/
class Shoestheme_Helpers_Shortcodes
{
	
	/**
	 * Init shortcodes.
	 */
	public static function init() {
		$shortcodes = array(
			'banner_simple'                => 'Shoestheme_Helpers_Shortcode_Banner_Simple',
			'banner'                       => 'Shoestheme_Helpers_Shortcode_Banner',
			'our_team'                     => 'Shoestheme_Helpers_Shortcode_Ourteam',
			'our_team_item'                => 'Shoestheme_Helpers_Shortcode_Ourteamitem',
			'brand'                    	   => 'Shoestheme_Helpers_Shortcode_Brand',
			'brand_item'                   => 'Shoestheme_Helpers_Shortcode_Branditem',
			'contact_form'                 => 'Shoestheme_Helpers_Shortcode_Contactform',
			'contact_form_simple'          => 'Shoestheme_Helpers_Shortcode_Contactform_Simple',
			'feature' 			           => 'Shoestheme_Helpers_Shortcode_Feature',
			'products' 					   => 'Shoestheme_Helpers_Shortcode_Products',
			'testimonial' 				   => 'Shoestheme_Helpers_Shortcode_Testimonial',
			'testimonial_item' 			   => 'Shoestheme_Helpers_Shortcode_Testimonial_Item',
			'posts' 			   		   => 'Shoestheme_Helpers_Shortcode_Blog',
			'google_map' 				   => 'Shoestheme_Helpers_Shortcode_Google_Map',
			'dealer_location' 			   => 'Shoestheme_Helpers_Shortcode_Dealer_Location',
			'section_title' 			   => 'Shoestheme_Helpers_Shortcode_Sectiontitle',
			'product_sale' 			       => 'Shoestheme_Helpers_Shortcode_Product_Sale',
			'product_sale_slide' 		   => 'Shoestheme_Helpers_Shortcode_Product_Sale_Slide',
			'product_sale_slide_item' 	   => 'Shoestheme_Helpers_Shortcode_Product_Sale_Slide_Item',
		);

		if(!empty($shortcodes)):
			foreach ( $shortcodes as $shortcode => $function ) {
				add_shortcode( apply_filters( "noushoes_{$shortcode}_shortcode_tag", 'noushoes_'.$shortcode ), array($function, 'shortcode') );
				add_action( 'vc_before_init', array($function, 'map') );
			}

			add_action( 'vc_before_init', array(__CLASS__, 'add_params') );
		endif;
	}

	public static function add_params(){
		$attribute_vc_row = array(
		    'type' => 'checkbox',
		    'heading' => esc_html__( "Row with container", 'shoestheme-helpers' ),
		    'param_name' => 'with_container',
		    'value' => '',
		);
		vc_add_param( 'vc_row', $attribute_vc_row );
	}

	/**
	 * get-attributes-of-nested-shortcodes
	 *
	 * @param string $str
	 * @param array $atts
	 *
	 * @return string
	 * @link http://wordpress.stackexchange.com/questions/121562/get-attributes-of-nested-shortcodes
	 */
	public static function get_attributes_nested_shortcodes( $str, $att = null ) {
		$res = array();
		$reg = get_shortcode_regex();
		preg_match_all( '~' . $reg . '~', $str, $matches );
		$i = 0;
		foreach ( $matches[2] as $key => $name ) {
			$parsed = shortcode_parse_atts( $matches[3][ $key ] );
			$parsed = is_array( $parsed ) ? $parsed : array();

			$res[ $i ]              = array_key_exists( $att, $parsed ) ? $parsed[ $att ] : $parsed;
			$res[ $i ]['name']      = $name;
			$res[ $i ]['shortcode'] = $matches[0][ $key ];
			$i                      = $i + 1;
		}

		return $res;
	}

}
?>