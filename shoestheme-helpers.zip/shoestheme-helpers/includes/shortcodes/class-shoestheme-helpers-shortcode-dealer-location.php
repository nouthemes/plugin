<?php
/**
* 
*/
class Shoestheme_Helpers_Shortcode_Dealer_Location
{
	
	public static function shortcode($atts){
		$atts = shortcode_atts( array(
			'country' => '',
			'city' => '',
			'address' => '',
			'email' => '',
			'phone' => '',
		), $atts, 'noushoes_dealer_location' );

		$country = !empty($atts['country']) ? $atts['country'] : '';
		$city = !empty($atts['city']) ? $atts['city'] : '';
		$address = !empty($atts['address']) ? $atts['address'] : '';
		$email = !empty($atts['email']) ? $atts['email'] : '';
		$phone = !empty($atts['phone']) ? $atts['phone'] : '';

		ob_start();
		?>
		<div class="ps-contact__block" data-mh="contact-block">
            <header>
                <h3><?php echo esc_html($country);?> <span> <?php echo esc_html($city);?></span></h3>
            </header>
            <footer>
                <?php if(!empty($address)):?><p><i class="fa fa-map-marker"></i> <?php echo esc_html($address);?></p><?php endif;?>
                <?php if(!empty($email)):?><p><i class="fa fa-envelope-o"></i><a href="mailto:<?php echo esc_html($email);?>"><?php echo esc_html($email);?></a></p><?php endif;?>
                <?php if(!empty($phone)):?><p><i class="fa fa-phone"></i> <?php echo esc_html($phone);?></p><?php endif;?>
            </footer>
        </div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Shoes - Dealer Location", 'shoestheme-helpers' ),
	      	"base" => "noushoes_dealer_location",
	      	"class" => "",
	      	"category" => esc_html__( "Shoes Theme", 'shoestheme-helpers'),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Country", 'shoestheme-helpers' ),
		            "param_name" => "country",
		        ),
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "City", 'shoestheme-helpers' ),
		            "param_name" => "city",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Address", 'shoestheme-helpers' ),
		            "param_name" => "address",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Email", 'shoestheme-helpers' ),
		            "param_name" => "email",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Phone", 'shoestheme-helpers' ),
		            "param_name" => "phone",
		        ),
	      	)
	    ) );
		endif;
	}
}