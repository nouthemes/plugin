<?php
/**
* 
*/
class Shoestheme_Helpers_Shortcode_Brand
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		$atts = shortcode_atts( array(
		), $atts, 'noushoes_brand' );
		
		ob_start();
			if(!empty($content)):
			?>
			<div class="ps-home-partner">
	            <div class="ps-container">
	                <div class="owl-slider" data-owl-auto="true" data-owl-loop="true" data-owl-speed="5000" data-owl-gap="40" data-owl-nav="false" data-owl-dots="false" data-owl-item="6" data-owl-item-xs="2" data-owl-item-sm="4" data-owl-item-md="5" data-owl-item-lg="6" data-owl-duration="1000" data-owl-mousedrag="on">
			          <?php echo do_shortcode($content);?>
			        </div>
			      </div>
		    </div><!--/.panel-partner-->
			<?php	
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Shoes - Brand Carousel", 'shoestheme-helpers' ),
	      	"base" => "noushoes_brand",
	      	"class" => "",
	      	"category" => esc_html__( "Shoes Theme", 'shoestheme-helpers'),
	      	"params" => array(),
	      	"as_parent" => array('only' => 'noushoes_brand_item'),
	      	"content_element" => true,
		    "show_settings_on_create" => false,
		    "is_container" => true,
		    "js_view" => 'VcColumnView'
	    ) );
		endif;
	}
}
?>