<?php
/**
* 
*/
class Shoestheme_Helpers_Shortcode_Branditem
{
	
	/**
	 * Brand slider item
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts ) {
		$atts = shortcode_atts( array(
			'img' => '',
			'url' => '',
		), $atts, 'noushoes_brand_item' );
		
		ob_start();
			if(!empty($atts['img'])):
			?>
			<a href="<?php echo esc_attr($atts['url']);?>" target="_blank">
	           	<?php echo shoestheme_helpers_get_image_by_id($atts['img'], 'noushoes_157x157');?>
	        </a>
			<?php
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand items.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Shoes - Brand Item", 'shoestheme-helpers' ),
	      	"base" => "noushoes_brand_item",
	      	"class" => "",
	      	"category" => esc_html__( "Shoes Theme", 'shoestheme-helpers'),
	      	"content_element" => true,
    		"as_child" => array('only' => 'noushoes_brand'),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", 'shoestheme-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "attach_image",
		            "class" => "",
		            "heading" => esc_html__( "Image", 'shoestheme-helpers' ),
		            "param_name" => "img",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "URL", 'shoestheme-helpers' ),
		            "param_name" => "url",
		        )
	      	)
	    ) );
		endif;
	}
}
?>