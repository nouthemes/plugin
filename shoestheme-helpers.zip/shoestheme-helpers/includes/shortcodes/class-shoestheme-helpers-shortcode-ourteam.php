<?php
/**
* 
*/
class Shoestheme_Helpers_Shortcode_Ourteam
{
	
	public static function shortcode($atts, $content = ''){
		
		$atts = shortcode_atts( array(
			'title' => '',
			'desc' => '',
		), $atts, 'noushoes_our_team' );

		ob_start();
		?>
		<div class="ps-section ps-ourteam pt-80 pb-80">
            <div class="ps-container">

            	<?php if(!empty($atts['title']) || !empty($atts['desc'])){?>
				<div class="ps-section__header mb-50">
		            <h2 class="ps-section__title" data-mask="<?php echo esc_html($atts['desc']);?>"><?php echo esc_html($atts['title']);?></h2>
		        </div> 
		        <?php }?>

		        <div class="ps-section__content">
                    <div class="row"><?php echo do_shortcode($content);?></div>
                </div>
		    </div>
		</div>
		<?php
		return ob_get_clean();
	}

	public static function map(){
		if(function_exists('vc_map')):
			vc_map( array(
		      	"name" => esc_html__( "Shoes - Our Team", 'shoestheme-helpers' ),
		      	"base" => "noushoes_our_team",
		      	"class" => "",
		      	"as_parent" => array('only' => 'noushoes_our_team_item'),
		      	"content_element" => true,
			    "show_settings_on_create" => false,
			    "is_container" => true,
		      	"category" => esc_html__( "Shoes Theme", 'shoestheme-helpers'),
		      	"params" => array(
			        array(
			            "type" => "textfield",
			            "holder" => "div",
			            "class" => "",
			            "heading" => esc_html__( "Title", 'shoestheme-helpers' ),
			            "param_name" => "title",
			        ),
			        array(
			            "type" => "textfield",
			            "holder" => "div",
			            "class" => "",
			            "heading" => esc_html__( "Description", 'shoestheme-helpers' ),
			            "param_name" => "desc",
			        ),
			        
		      	),
		      	"js_view" => 'VcColumnView'
		    ) );
		endif;
	}
}
?>