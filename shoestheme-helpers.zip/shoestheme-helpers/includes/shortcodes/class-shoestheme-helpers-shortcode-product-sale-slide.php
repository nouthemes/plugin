<?php
/**
* 
*/
class Shoestheme_Helpers_Shortcode_Product_Sale_Slide
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		if ( empty( $atts ) ) {
			return '';
		}

		$atts = shortcode_atts( array(
			'title' => '',
			'subtitle' => '',
		), $atts, 'noushoes_product_sale_slide' );

		ob_start();
			?>
			<div class="ps-section ps-owl-root ps-hotdeal--2 pt-80 pb-80">
	            <div class="ps-container">
	                <div class="ps-section__header mb-50">
	                    <div class="row">
	                        
	                        <?php if(!empty($atts['title'])):?>
			                <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12 ">
			                    <h3 class="ps-section__title" <?php if(!empty($atts['subtitle'])){?>data-mask="<?php echo esc_html($atts['subtitle']);?>"<?php }?>><?php echo esc_html($atts['title']);?></h3>
			                </div>
			                <?php endif;?>

			                <?php if(!empty($content)):?>
	                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 ">
	                            <div class="ps-owl-actions"><a class="ps-prev" href="#"><i class="ps-icon-arrow-right"></i><?php esc_html_e('Prev', 'shoestheme-helpers');?></a><a class="ps-next" href="#"><?php esc_html_e('Next', 'shoestheme-helpers');?><i class="ps-icon-arrow-left"></i></a></div>
	                        </div>
	                        <?php endif;?>

	                    </div>
	                </div>
	                <?php if(!empty($content)):?>
	                <div class="ps-section__content">
	                    <div class="row">
	                        <div class="ps-owl--collection owl-slider" data-owl-auto="true" data-owl-loop="true" data-owl-speed="50000" data-owl-gap="30" data-owl-nav="false" data-owl-dots="false" data-owl-item="2" data-owl-item-xs="1" data-owl-item-sm="1" data-owl-item-md="2" data-owl-item-lg="2" data-owl-duration="1000" data-owl-mousedrag="on">
	           					<?php echo do_shortcode($content);?>
	                        </div>
	                    </div>
	                </div>
	                <?php endif;?>
	            </div>
	        </div>
			<?php
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Shoes - Product Sale Carousel", 'shoestheme-helpers' ),
	      	"base" => "noushoes_product_sale_slide",
	      	"class" => "",
	      	"category" => esc_html__( "Shoes Theme", 'shoestheme-helpers'),
	      	"as_parent" => array('only' => 'noushoes_product_sale_slide_item'),
	      	"content_element" => true,
		    "show_settings_on_create" => false,
		    "is_container" => true,
	      	"params" => array(
		        
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Title of section", 'shoestheme-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Subtitle of section", 'shoestheme-helpers' ),
		            "param_name" => "subtitle",
		           
		        ),
		        
		 
		   
	      	),
	      	"js_view" => 'VcColumnView'
	    ) );
		endif;
	}
}
?>