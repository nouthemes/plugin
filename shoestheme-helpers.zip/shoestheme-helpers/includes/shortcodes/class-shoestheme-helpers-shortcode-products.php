<?php
/**
* 
*/
class Shoestheme_Helpers_Shortcode_Products
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		if ( empty( $atts ) ) {
			return '';
		}

		$atts = shortcode_atts( array(
			'title' => '',
			'desc' => '',
			'style' => '',
			'type' => '',
			'ids' => '',
			'cat' => '',
			'number' => '',
			'order_by' => '',
		), $atts, 'noushoes_products' );
		
		$products = self::get_products($atts);
		ob_start();
			if($products->have_posts()):

				if(isset($atts['style']) && $atts['style'] != 'slider'){
					?>
					<div class="ps-section--features-product ps-section masonry-root">
						<div class="ps-container">
							
							<div class="ps-section__header mb-50">
			                    <?php if(!empty($atts['title'])){?>
			                    	<h3 class="ps-section__title" <?php if(!empty($atts['desc'])){?>data-mask="<?php echo esc_html($atts['desc']);?>"<?php }?>><?php echo esc_html($atts['title']);?></h3>
			                    <?php }?>

			                    <?php 
			                    $all_terms = array();
				                while($products->have_posts()){ $products->the_post();
					                $terms = get_the_terms ( get_the_ID(), 'product_cat' );
									foreach ( $terms as $term ) {
									    if(!in_array($term->term_id, $all_terms)){
									    	$all_terms[] = $term->term_id;
									    }
									}
								}
								if ( ! empty( $all_terms ) ){
								    echo '<ul class="ps-masonry__filter">';
								    	echo '<li class="current"><a href="#" data-filter="*">'.esc_html__('All', 'shoestheme-helpers').'</a></li>';
									    foreach ( $all_terms as $term_id ) {
									    	$term = get_term( $term_id, 'product_cat' );
									        echo '<li><a href="#" data-filter=".product_cat-'.esc_attr($term->slug).'">' . esc_html($term->name) . ' <sup>' . esc_html($term->count) . '</sup></a></li>';
									    }
								    echo '</ul>';
								}
			                    ?>

			                </div>
			                <div class="ps-section__content pb-50">
			                    <div class="masonry-wrapper" data-col-md="4" data-col-sm="2" data-col-xs="1" data-gap="30" data-radio="100%">
			                        <div class="ps-masonry products">
			                        	<div class="grid-sizer"></div>
				        				<?php while($products->have_posts()): $products->the_post();?>
				        					<?php wc_get_template_part('content', 'product-masonry');?>
				        				<?php endwhile;?>
				        			</div>
				        		</div>
				        	</div>
	        			</div>
            		</div>
					<?php
				}else{
					?>
					<div class="ps-section ps-section--top-sales ps-owl-root">
            			<div class="ps-container">
            				<div class="ps-section__header mb-50">
			                    <div class="row">
			                        <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 ">
			                            <?php if(!empty($atts['title'])){?>
					                    	<h3 class="ps-section__title" <?php if(!empty($atts['desc'])){?>data-mask="<?php echo esc_html($atts['desc']);?>"<?php }?>><?php echo esc_html($atts['title']);?></h3>
					                    <?php }?>
			                        </div>
			                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 ">
			                            <div class="ps-owl-actions"><a class="ps-prev" href="#"><i class="ps-icon-arrow-right"></i><?php esc_html_e('Prev', 'shoestheme-helpers');?></a><a class="ps-next" href="#"><?php esc_html_e('Next', 'shoestheme-helpers');?><i class="ps-icon-arrow-left"></i></a></div>
			                        </div>
			                    </div>
			                </div>


							<div class="ps-section__content products">
                    			<div class="ps-owl--colection owl-slider" data-owl-auto="true" data-owl-loop="true" data-owl-speed="5000" data-owl-gap="30" data-owl-nav="false" data-owl-dots="false" data-owl-item="4" data-owl-item-xs="1" data-owl-item-sm="2" data-owl-item-md="3" data-owl-item-lg="4" data-owl-duration="1000" data-owl-mousedrag="on">

		            				<?php while($products->have_posts()): $products->the_post();?>
			        					<?php wc_get_template_part('content', 'product-related');?>
		            				<?php endwhile;?>

		            			</div>
		            		</div>




		            	</div>
		            </div>
					<?php
				}

			endif;wp_reset_postdata();
		return ob_get_clean();
		
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		vc_map( array(
	      	"name" => esc_html__( "Shoes - Products", 'shoestheme-helpers' ),
	      	"base" => "noushoes_products",
	      	"class" => "",
	      	"category" => esc_html__( "Shoes Theme", 'shoestheme-helpers'),
	      	'description' => esc_html__('Products display type Slider or Grid', 'shoestheme-helpers'),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "heading" => esc_html__( "Title", 'shoestheme-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "heading" => esc_html__( "Description", 'shoestheme-helpers' ),
		            "param_name" => "desc",
		        ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "holder" => "div",
		            "heading" => esc_html__( "Type of section show", 'shoestheme-helpers' ),
		            "param_name" => "style",
		            "value" => array(esc_html__('Grid', 'shoestheme-helpers') => 'grid', esc_html__('Slider', 'shoestheme-helpers') => 'slider'), 
		            'group' => esc_html__('Display', 'shoestheme-helpers'),
		        ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "holder" => "div",
		            "heading" => esc_html__( "Type of products show", 'shoestheme-helpers' ),
		            "param_name" => "type",
		            "value" => array(esc_html__('--Select type--', 'shoestheme-helpers') => '', esc_html__('Recent', 'shoestheme-helpers') => 'recent', esc_html__('Featured', 'shoestheme-helpers') => 'featured', esc_html__('Sale', 'shoestheme-helpers') => 'onsale', esc_html__('Best sale', 'shoestheme-helpers') => 'bestsale'), 
		            'group' => esc_html__('Display', 'shoestheme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "IDs posts, EX: 21,22,23", 'shoestheme-helpers' ),
		            "param_name" => "ids",
		            'group' => esc_html__('Display', 'shoestheme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Category ID", 'shoestheme-helpers' ),
		            "param_name" => "cat",
		            'group' => esc_html__('Display', 'shoestheme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Number of posts show(default 8)", 'shoestheme-helpers' ),
		            "param_name" => "number",
		            'group' => esc_html__('Display', 'shoestheme-helpers'),
		        ),
	      	)
	    ) );
	}

	private static function get_products($atts){
		
		$per_page = !empty($atts['number']) ? intval($atts['number']) : '8';
		$args = array(
			'post_type' => 'product', 
			'post_status' => 'publish',
			'posts_per_page' => $per_page
			);

		if(!empty($atts['ids'])){
			$args['post__in'] = explode(',', $atts['ids']);
		}else{
			if(!empty($atts['cat'])){
				$args['tax_query'] = array(
					array(
						'taxonomy' => 'product_cat',
						'field'    => 'term_id',
						'terms'    => $atts['cat'],
					),
				);
			}
		}
		switch ( $atts['type'] ) {
			case 'featured' :
				$args['tax_query'][] = array(
                    'taxonomy' => 'product_visibility',
                    'field'    => 'name',
                    'terms'    => 'featured',
                );
				break;
			case 'onsale' :
				$product_ids_on_sale    = wc_get_product_ids_on_sale();
				$product_ids_on_sale[]  = 0;
				$args['post__in'] = $product_ids_on_sale;
				break;	
			case 'bestsale' :
				$args['meta_key'] = 'total_sales';
				$args['orderby']  = 'meta_value_num';
		}
		
		return new WP_Query( apply_filters( 'noushoes_products_shortcode_query_args', $args ) );
	}
}
?>