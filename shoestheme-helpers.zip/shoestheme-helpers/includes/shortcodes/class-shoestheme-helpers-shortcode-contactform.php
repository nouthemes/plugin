<?php
/**
* 
*/
class Shoestheme_Helpers_Shortcode_Contactform
{
	
	public static function shortcode($atts){
		$atts = shortcode_atts( array(
			'type' => '',
			'lat' => '',
			'lng' => '',
			'title' => '',
			'desc' => '',
			'address' => '',
			'zoom' => '',
			'map_title' => '',
			'marker' => ''
		), $atts, 'noushoes_contact_form' );
		$zoom = !empty($atts['zoom']) ? $atts['zoom'] : '17';
		$marker_id = !empty($atts['marker']) ? $atts['marker'] : '';
		$map_title = !empty($atts['map_title']) ? $atts['map_title'] : $atts['address'];

		$marker = SHOESTHEME_HELPERS_URL.'public/images/marker.png';
		if(!empty($marker_id)){
			$image = wp_get_attachment_image_src($marker_id, 'full');
			if($image){
				$marker = $image[0];
			}
		}

		$lng = '';
		$lat = '';
		$type = 'address';
		$display = false;

		if($atts['type'] == 'coordinates'){
			$lng = !empty($atts['lng']) ? $atts['lng'] : '';
			$lat = !empty($atts['lat']) ? $atts['lat'] : '';
			$type = 'coordinates';
			if(!empty($lng) && !empty($lat)){
				$display = true;
			}
		}else{
			if(!empty($atts['address'])){
				$display = true;
			}
		}

		ob_start();
		?>
		<div class="ps-home-contact">
			<?php 
			if($display):
			?>
	        <div class="noushoes-google-map google-map" data-type="<?php echo esc_attr($type);?>" data-address="<?php echo esc_attr($atts['address']);?>" data-lng="<?php echo esc_attr($lng);?>" data-lat="<?php echo esc_attr($lat);?>" data-zoom="<?php echo intval($zoom);?>" data-icon="<?php echo esc_attr($marker);?>" data-title="<?php echo esc_attr($map_title);?>"></div>

	        <div class="ps-home-contact__form">
	          <header>
	            <?php if(!empty($atts['title'])):?><h3><?php echo esc_html($atts['title']);?></h3><?php endif;?>
	            <?php if(!empty($atts['desc'])): echo wpautop(esc_html($atts['desc']));endif;?>
	          </header>
	          <footer>
	            <form class="ps-delivery__form" action="<?php echo esc_url(home_url('/'));?>" method="post">
	              <div class="form-group">
	                <label><?php esc_html_e('Name', 'shoestheme-helpers');?><span>*</span></label>
	                <input class="form-control" type="text" name="name">
	              </div>
	              <div class="form-group">
	                <label><?php esc_html_e('Email', 'shoestheme-helpers');?><span>*</span></label>
	                <input class="form-control" type="email" name="email">
	              </div>
	          
	              <div class="form-group">
	                <label><?php esc_html_e('Your message', 'shoestheme-helpers');?><span>*</span></label>
	                <textarea class="form-control" name="content"></textarea>
	              </div>
	              <div class="form-group text-center">
	                <button class="ps-btn noushoes-contact__submit"><?php esc_html_e('Send Message', 'shoestheme-helpers');?><i class="fa fa-angle-right"></i></button>
	              </div>
	            </form>
	          </footer>
	        </div>
	        <?php endif;?>
	    </div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Shoes - Contact form with Google map", 'shoestheme-helpers' ),
	      	"base" => "noushoes_contact_form",
	      	"class" => "",
	      	"category" => esc_html__( "Shoes Theme", 'shoestheme-helpers'),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", 'shoestheme-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textarea",
		            "class" => "",
		            "heading" => esc_html__( "Description", 'shoestheme-helpers' ),
		            "param_name" => "desc",
		        ),
		        array(
					'type' => 'dropdown',
					'heading' => __( 'Type of address.', 'shoestheme-helpers' ),
					'value' => array(
						__( 'Address', 'shoestheme-helpers' ) => 'address',
						__( 'Coordinates', 'shoestheme-helpers' ) => 'coordinates',
					),
					'param_name' => 'type',
					'group' => esc_html__('Google Map', 'shoestheme-helpers'),
				),
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "heading" => esc_html__( "Address", 'shoestheme-helpers' ),
		            "param_name" => "address",
		            'dependency' => array(
						'element' => 'type',
						'value' => array('address'),
					),
		            'group' => esc_html__('Google Map', 'shoestheme-helpers'),
		        ),

		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "heading" => esc_html__( "Latitude", 'shoestheme-helpers' ),
		            "param_name" => "lat",
		            'dependency' => array(
						'element' => 'type',
						'value' => array('coordinates'),
					),
		            'group' => esc_html__('Google Map', 'shoestheme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "heading" => esc_html__( "Longitude", 'shoestheme-helpers' ),
		            "param_name" => "lng",
		            'dependency' => array(
						'element' => 'type',
						'value' => array('coordinates'),
					),
		            'group' => esc_html__('Google Map', 'shoestheme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Zoom(Default: 17)", 'shoestheme-helpers' ),
		            "param_name" => "zoom",
		            'group' => esc_html__('Google Map', 'shoestheme-helpers'),
		        ),
		        array(
		            "type" => "textarea",
		            "class" => "",
		            "heading" => esc_html__( "Title", 'shoestheme-helpers' ),
		            "param_name" => "map_title",
		            'group' => esc_html__('Google Map', 'shoestheme-helpers'),
		        ),
		        array(
		            "type" => "attach_image",
		            "class" => "",
		            "heading" => esc_html__( "Image Marker", 'shoestheme-helpers' ),
		            "param_name" => "marker",
		            'group' => esc_html__('Google Map', 'shoestheme-helpers'),
		        ),
	      	)
	    ) );
		endif;
	}
}