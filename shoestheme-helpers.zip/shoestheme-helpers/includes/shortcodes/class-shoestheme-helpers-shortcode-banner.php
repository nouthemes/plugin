<?php
/**
* 
*/
class Shoestheme_Helpers_Shortcode_Banner
{
	
	public static function shortcode($atts){
		$atts = shortcode_atts( array(
			'url' => '',
			'img' => '',
			'class' => '',
		), $atts, 'noushoes_banner' );

		$bg = '';
		
		if(!empty($atts['img'])){
			$image = wp_get_attachment_image_src($atts['img'], 'full');
			if($image){
				$bg = $image[0];
			}
		}

		ob_start(); 
			if(!empty($bg)):
			?>
	        <a class="ps-offer <?php if(!empty($atts['class'])){echo esc_attr($atts['class']);}?>" href="<?php echo esc_url($atts['url']);?>">
	        	<img src="<?php echo esc_attr($bg);?>" alt="" />
	        </a>
			<?php
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Shoes - Banner", 'shoestheme-helpers' ),
	      	'description' => esc_html__('Simple banner with image vs URL.', 'shoestheme-helpers'),
	      	"base" => "noushoes_banner",
	      	"class" => "",
	      	"category" => esc_html__( "Shoes Theme", 'shoestheme-helpers'),
    		"params" => array(
		    
		        array(
		            "type" => "textfield",
		            "heading" => esc_html__( "URL", 'shoestheme-helpers' ),
		            "param_name" => "url",
		        ),
		        array(
		            "type" => "attach_image",
		            "class" => "",
		            "heading" => esc_html__( "Image", 'shoestheme-helpers' ),
		            "param_name" => "img",
		        ),
		        array(
		            "type" => "textfield",
		            "heading" => esc_html__( "Custom Class CSS", 'shoestheme-helpers' ),
		            "param_name" => "class",
		            'group' => esc_html__('Style', 'shoestheme-helpers')
		        ),
	      	)
	    ) );
		endif;
	}
}