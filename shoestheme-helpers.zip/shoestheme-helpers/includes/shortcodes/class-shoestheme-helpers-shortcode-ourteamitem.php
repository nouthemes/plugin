<?php
/**
* 
*/
class Shoestheme_Helpers_Shortcode_Ourteamitem
{
	public static function shortcode($atts){
		$atts = shortcode_atts( array(
			'title' => '',
			'position' => '',
			'img' => '',
			'fb' => '',
			'twitter' => '',
			'dribbble' => '',
			
		), $atts, 'noushoes_our_team_item' );
		ob_start();
		?>
		<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 ">
            <div class="ps-user">
                <div class="ps-user__thumbnnail">
                	<?php echo shoestheme_helpers_get_image_by_id($atts['img'], 'noushoes_staff');?>
                    <ul class="ps-user__social">
                        <?php if($atts['twitter']){?><li><a href="<?php echo esc_url($atts['twitter']);?>" target="_blank"><i class="fa fa-twitter"></i></a></li><?php }?>
                        <?php if($atts['fb']){?><li><a href="<?php echo esc_url($atts['fb']);?>" target="_blank"><i class="fa fa-facebook"></i></a></li><?php }?>
                        <?php if($atts['dribbble']){?><li><a href="<?php echo esc_url($atts['dribbble']);?>" target="_blank"><i class="fa fa-dribbble"></i></a></li><?php }?>
                    </ul>
                </div>
                <div class="ps-user__content">
                    <?php if(!empty($atts['title'])){?><h3><?php echo esc_html($atts['title']);?></h3><?php }?>
                    <?php if(!empty($atts['position'])){?><p><?php echo esc_html($atts['position']);?></p><?php }?>
                </div>
            </div>
        </div>
		<?php
		return ob_get_clean();
	}

	public static function map(){
		if(function_exists('vc_map')):
			vc_map( array(
		      	"name" => esc_html__( "Shoes - Our team item", 'shoestheme-helpers' ),
		      	"base" => "noushoes_our_team_item",
		      	"class" => "",
		      	"as_child" => array('only' => 'noushoes_our_team'),
		      	"category" => esc_html__( "Shoes Theme", 'shoestheme-helpers'),
		      	"params" => array(
			        
			        array(
			            "type" => "textfield",
			            "holder" => "div",
			            "class" => "",
			            "heading" => esc_html__( "Name", 'shoestheme-helpers' ),
			            "param_name" => "title",
			        ),
			        array(
			            "type" => "textfield",
			            "class" => "",
			            "heading" => esc_html__( "Position", 'shoestheme-helpers' ),
			            "param_name" => "position",
			        ),
			        
			        array(
			            "type" => "attach_image",
			            "class" => "",
			            "heading" => esc_html__( "Image", 'shoestheme-helpers' ),
			            "param_name" => "img",
			        ),
			        
			        array(
			            "type" => "textfield",
			            "class" => "",
			            "heading" => esc_html__( "Facebook URL", 'shoestheme-helpers' ),
			            "param_name" => "fb",
			            'group' => esc_html__('Social', 'shoestheme-helpers'),
			        ),
			        array(
			            "type" => "textfield",
			            "class" => "",
			            "heading" => esc_html__( "Dribbble URL", 'shoestheme-helpers' ),
			            "param_name" => "dribbble",
			            'group' => esc_html__('Social', 'shoestheme-helpers'),
			        ),
			        array(
			            "type" => "textfield",
			            "class" => "",
			            "heading" => esc_html__( "Twitter URL", 'shoestheme-helpers' ),
			            "param_name" => "twitter",
			            'group' => esc_html__('Social', 'shoestheme-helpers'),
			        ),
			        
		      	)
		    ) );
		endif;
	}
}
?>