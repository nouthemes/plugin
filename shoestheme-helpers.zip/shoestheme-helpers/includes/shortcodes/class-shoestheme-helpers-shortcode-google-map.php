<?php
/**
* 
*/
class Shoestheme_Helpers_Shortcode_Google_Map
{
	
	public static function shortcode($atts){
		$atts = shortcode_atts( array(
			'type' => '',
			'lat' => '',
			'lng' => '',
			'address' => '',
			'zoom' => '',
			'map_title' => '',
			'marker' => ''
		), $atts, 'noushoes_google_map' );
		$zoom = !empty($atts['zoom']) ? $atts['zoom'] : '17';
		$marker_id = !empty($atts['marker']) ? $atts['marker'] : '';
		$map_title = !empty($atts['map_title']) ? $atts['map_title'] : $atts['address'];

		$marker = SHOESTHEME_HELPERS_URL.'public/images/marker.png';
		if(!empty($marker_id)){
			$image = wp_get_attachment_image_src($marker_id, 'full');
			if($image){
				$marker = $image[0];
			}
		}

		$lng = '';
		$lat = '';
		$type = 'address';
		$display = false;

		if($atts['type'] == 'coordinates'){
			$lng = !empty($atts['lng']) ? $atts['lng'] : '';
			$lat = !empty($atts['lat']) ? $atts['lat'] : '';
			$type = 'coordinates';
			if(!empty($lng) && !empty($lat)){
				$display = true;
			}
		}else{
			if(!empty($atts['address'])){
				$display = true;
			}
		}

		ob_start(); 
			if($display):
			?>
	        <div class="noushoes-google-map google-map" data-type="<?php echo esc_attr($type);?>" data-address="<?php echo esc_attr($atts['address']);?>" data-lng="<?php echo esc_attr($lng);?>" data-lat="<?php echo esc_attr($lat);?>" data-zoom="<?php echo intval($zoom);?>" data-icon="<?php echo esc_attr($marker);?>" data-title="<?php echo esc_attr($map_title);?>"></div>
	        <?php endif;?>
		    </div>
			<?php
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Shoes - Google map", 'shoestheme-helpers' ),
	      	"base" => "noushoes_google_map",
	      	"class" => "",
	      	"category" => esc_html__( "Shoes Theme", 'shoestheme-helpers'),
    		"params" => array(
		     
		        array(
					'type' => 'dropdown',
					'heading' => __( 'Type of address.', 'shoestheme-helpers' ),
					'value' => array(
						__( 'Address', 'shoestheme-helpers' ) => 'address',
						__( 'Coordinates', 'shoestheme-helpers' ) => 'coordinates',
					),
					'param_name' => 'type',
				),
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "heading" => esc_html__( "Address", 'shoestheme-helpers' ),
		            "param_name" => "address",
		            'dependency' => array(
						'element' => 'type',
						'value' => array('address'),
					),
		        ),

		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "heading" => esc_html__( "Latitude", 'shoestheme-helpers' ),
		            "param_name" => "lat",
		            'dependency' => array(
						'element' => 'type',
						'value' => array('coordinates'),
					),
		        ),
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "heading" => esc_html__( "Longitude", 'shoestheme-helpers' ),
		            "param_name" => "lng",
		            'dependency' => array(
						'element' => 'type',
						'value' => array('coordinates'),
					),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Zoom(Default: 17)", 'shoestheme-helpers' ),
		            "param_name" => "zoom",
		            'group' => esc_html__('Google Map', 'shoestheme-helpers'),
		        ),
		        array(
		            "type" => "textarea",
		            "class" => "",
		            "heading" => esc_html__( "Title", 'shoestheme-helpers' ),
		            "param_name" => "map_title",
		            'group' => esc_html__('Google Map', 'shoestheme-helpers'),
		        ),
		        array(
		            "type" => "attach_image",
		            "class" => "",
		            "heading" => esc_html__( "Image Marker", 'shoestheme-helpers' ),
		            "param_name" => "marker",
		            'group' => esc_html__('Google Map', 'shoestheme-helpers'),
		        ),
	      	)
	    ) );
		endif;
	}
}