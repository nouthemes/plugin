<?php
/**
* 
*/
class Shoestheme_Helpers_Shortcode_Sectiontitle
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		$atts = shortcode_atts( array(
			'title' => '',
			'sub' => '',
		), $atts, 'noushoes_section_title' );
		
		ob_start();
			if(!empty($atts['title'])):
			?>
			<div class="ps-section__header mb-50">
                <h3 class="ps-section__title" <?php if(!empty($atts['title'])){?>data-mask="<?php echo esc_html($atts['sub']);?>"<?php }?>><?php echo esc_html($atts['title']);?></h3>
            </div>
			<?php	
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Shoes - Section Title", 'shoestheme-helpers' ),
	      	"base" => "noushoes_section_title",
	      	"class" => "",
	      	"category" => esc_html__( "Shoes Theme", 'shoestheme-helpers'),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", 'shoestheme-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Subtitle", 'shoestheme-helpers' ),
		            "param_name" => "sub",
		        ),
	      	)
	    ) );
		endif;
	}
}
?>