<?php
/**
* 
*/
class Shoestheme_Helpers_Shortcode_Blog
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		if(empty($atts)){
			return '';
		}

		$atts = shortcode_atts( array(
			'title' => '',
			'desc' => '',
			'ids' => '',
			'cat' => '',
			'number' => '',
		), $atts, 'noushoes_posts' );
		
		$per_page = !empty($atts['number']) ? intval($atts['number']) : '3';
		$args = array(
			'post_type' => 'post', 
			'post_status' => 'publish',
			'ignore_sticky_posts' => true,
			'posts_per_page' => $per_page
			);

		if(!empty($atts['ids'])){
			$args['post__in'] = explode(',', $atts['ids']);
		}else{
			if(!empty($atts['cat'])){
				$args['tax_query'] = array(
					array(
						'taxonomy' => 'category',
						'field'    => 'term_id',
						'terms'    => $atts['cat'],
					),
				);
			}
		}

		$query = new WP_Query($args);
		ob_start();
			if($query->have_posts()):

				$link = home_url('/');
				$show_on_front = get_option('show_on_front');
				if($show_on_front == 'page'){
					$link = get_permalink(get_option('page_for_posts'));
				}
				?>
				<div class="ps-section ps-home-blog pt-80 pb-80">
		            <div class="ps-container">
		                <div class="ps-section__header mb-50">
		                    <?php if(!empty($atts['title'])){?>
		                    	<h2 class="ps-section__title" <?php if(!empty($atts['desc'])){?>data-mask="<?php echo esc_html($atts['desc']);?>"<?php }?>><?php echo esc_html($atts['title']);?></h2>
		                    <?php }?>
		                    <div class="ps-section__action"><a class="ps-morelink text-uppercase" href="<?php echo esc_url($link);?>"><?php esc_html_e('View all posts', 'shoestheme-helpers');?><i class="fa fa-long-arrow-right"></i></a></div>
		                </div>
		                <div class="ps-section__content">
		                    <div class="row">
		                        <?php while($query->have_posts()): $query->the_post();?>
			                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 ">
			                            <div id="post-<?php the_ID();?>" <?php post_class('ps-post');?>>
			                                <?php noushoes_post_thumbnail();?>
			                                <div class="ps-post__content">
			                                	<a class="ps-post__title" href="<?php the_permalink();?>">
										    		<?php
										              if ( is_sticky() && is_home() ) :
										                noushoes_sticky_post_icon();
										              endif;
										            ?>
										    		<?php the_title();?>
										    	</a>
										        <p class="ps-post__meta">
										        	<span><?php esc_html_e('By', 'shoestheme-helpers');?>:<a class="mr-5" href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) );?>"><?php echo esc_html( get_the_author() );?></a></span> -<span class="ml-5"><?php echo get_the_date();?></span>
										        </p>

			                                    <?php if('gallery' != get_post_format()):?>
										            <p><?php echo wp_trim_words(get_the_excerpt(), 29, '...');?></p>
										        <?php endif;?>
										        <a class="ps-morelink" href="<?php the_permalink();?>"><?php esc_html_e('Read more', 'shoestheme-helpers');?><i class="fa fa-long-arrow-right"></i></a>
			                                </div>
			                            </div>
			                        </div>
		                        <?php endwhile;?>
		                    </div>
		                </div>
		            </div>
		        </div>
				<?php
			endif;wp_reset_postdata();
		return ob_get_clean();
	}

	/**
	 * Map shortcode Post items.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Shoes - Posts", 'shoestheme-helpers' ),
	      	"base" => "noushoes_posts",
	      	"class" => "",
	      	"category" => esc_html__( "Shoes Theme", 'shoestheme-helpers'),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", 'shoestheme-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Description", 'shoestheme-helpers' ),
		            "param_name" => "desc",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "IDs posts, EX: 21,22,23", 'shoestheme-helpers' ),
		            "param_name" => "ids",
		            'group' => esc_html__('Display', 'shoestheme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Category ID", 'shoestheme-helpers' ),
		            "param_name" => "cat",
		            'group' => esc_html__('Display', 'shoestheme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Number of posts show(default 3)", 'shoestheme-helpers' ),
		            "param_name" => "number",
		            'group' => esc_html__('Display', 'shoestheme-helpers'),
		        ),
	      	)
	    ) );
		endif;
	}
}
?>