<?php
/**
* 
*/
class Shoestheme_Helpers_Shortcode_Banner_Simple
{
	
	public static function shortcode($atts){
		$atts = shortcode_atts( array(
			'title' => '',
			'desc' => '',
			'bg' => '',
		), $atts, 'noushoes_banner_simple' );

		$bg = '';
		if(!empty($atts['bg'])){
			$image = wp_get_attachment_image_src($atts['bg'], 'full');
			if($image){
				$bg = $image[0];
			}
		}

		ob_start(); 
			if(!empty($atts['title']) || !empty($atts['desc']) || !empty($atts['bg'])):
			?>
	        <div class="ps-mission bg-cover" <?php if(!empty($bg)){?>data-background="<?php echo esc_attr($bg);?>"<?php }?>>
	            <div class="ps-container">
	                <?php if(!empty($atts['title'])){?><h3><?php echo esc_html($atts['title']);?></h3><?php }?>
	                <?php if(!empty($atts['desc'])){?><h2><?php echo wp_kses_post($atts['desc']);?></h2><?php }?>
	            </div>
	        </div>
			<?php
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Shoes - Full Width Banner", 'shoestheme-helpers' ),
	      	'description' => esc_html__('Full width banner with caption.', 'shoestheme-helpers'),
	      	"base" => "noushoes_banner_simple",
	      	"class" => "",
	      	"category" => esc_html__( "Shoes Theme", 'shoestheme-helpers'),
    		"params" => array(
		    
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "heading" => esc_html__( "Title", 'shoestheme-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textarea",
		            "holder" => "div",
		            "heading" => esc_html__( "Description", 'shoestheme-helpers' ),
		            "param_name" => "desc",
		        ),
		        array(
		            "type" => "attach_image",
		            "class" => "",
		            "heading" => esc_html__( "Image", 'shoestheme-helpers' ),
		            "param_name" => "bg",
		        ),
	      	)
	    ) );
		endif;
	}
}