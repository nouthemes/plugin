<?php
/**
* 
*/
class Shoestheme_Helpers_Shortcode_Product_Sale
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		if ( empty( $atts ) ) {
			return '';
		}

		$atts = shortcode_atts( array(
			'type' => '',
			'id' => '',
			'ids' => '',
			'img' => '',
			'title' => '',
			'subtitle' => '',
			
			'hotspot_1_title' => '',
			'hotspot_1_desc' => '',
			'hotspot_1_left' => '',
			'hotspot_1_right' => '',
			'hotspot_1_bottom' => '',
			'hotspot_1_top' => '',
			'hotspot_1_active' => '',

			'hotspot_2_title' => '',
			'hotspot_2_desc' => '',
			'hotspot_2_left' => '',
			'hotspot_2_right' => '',
			'hotspot_2_bottom' => '',
			'hotspot_2_top' => '',
			'hotspot_2_active' => '',

			'hotspot_3_title' => '',
			'hotspot_3_desc' => '',
			'hotspot_3_left' => '',
			'hotspot_3_right' => '',
			'hotspot_3_bottom' => '',
			'hotspot_3_top' => '',
			'hotspot_3_active' => '',

		), $atts, 'noushoes_product_sale' );

		$html = '';
		$args = array(
				'post_type' => 'product', 
				'post_status' => 'publish',
			);

		if($atts['type'] == 'slide' && !empty($atts['ids'])){
			$args['post__in'] = explode(',', $atts['ids']);
		}else{
			$args['p'] = $atts['id'];
		}

		ob_start();
			$products = new WP_Query($args);
			if($products->have_posts()):
				while($products->have_posts()): $products->the_post();
					$product = wc_get_product(get_the_ID());
					if($product){
						if($atts['type'] == 'small'){
							self::product_small($product, $atts);
						}else{
							self::product_fullwidth($product, $atts);
						}

					}
				endwhile;
			endif; wp_reset_postdata();
		return ob_get_clean();
	}

	private static function product_small($product, $atts){
		$sales_price_to = get_post_meta($product->get_id(), '_sale_price_dates_to', true);
		$image_id = $product->get_image_id();
		if(!empty($atts['img'])){
			$image_id = $atts['img'];
		}

		$images = wp_get_attachment_image_src($image_id, 'full');
		?>
		<div class="ps-product--hotdeal reverse product" data-id="<?php echo esc_attr($product->get_id());?>" data-url="<?php echo get_permalink($product->get_id());?>" data-title="<?php echo esc_html($product->get_name());?>">
            <?php if($images):?>
            <div class="ps-product__thumbnail">
            	<a class="ps-product__overlay" href="<?php echo get_permalink($product->get_id());?>"></a>
            	<img src="<?php echo esc_attr($images[0]);?>" alt="" />
            </div>
            <?php endif;?>
            <div class="ps-product__content">
            	<a class="ps-product__title" href="<?php echo get_permalink($product->get_id());?>"><?php echo esc_html($product->get_name());?></a>
                <p class="ps-product__price"><?php esc_html_e('Only', 'shoestheme-helpers');?>: <?php echo wp_kses_post($product->get_price_html());?></p>
                
                <?php self::proccess($product);?>

                <?php if(!empty($sales_price_to)){self::countdown(date("F d, Y", $sales_price_to));}?>
                
                <?php
                $class = implode( ' ', array_filter( array(
					            'button',
					            'product_type_' . $product->get_type(),
					            $product->is_purchasable() && $product->is_in_stock() ? 'add_to_cart_button' : '',
					            $product->supports( 'ajax_add_to_cart' ) ? 'ajax_add_to_cart' : '',
					        ) ) );
		      	echo apply_filters( 'woocommerce_sale_product_small_add_to_cart_link',
					sprintf( '<a rel="nofollow" href="%s" data-quantity="%s" data-product_id="%s" data-product_sku="%s" class="ps-btn product-item-cart %s">%s<i class="ps-icon-next"></i></a>',
						esc_url( $product->add_to_cart_url() ),
						esc_attr( isset( $quantity ) ? $quantity : 1 ),
						esc_attr( $product->get_id() ),
						esc_attr( $product->get_sku() ),
						esc_attr( isset( $class ) ? $class : 'button' ),
						esc_html__('Order Today', 'shoestheme-helpers')
					),
				$product );
		      	?>
            </div>
        </div>
		<?php
	}

	private static function product_fullwidth($product, $atts){
		$image_id = $product->get_image_id();
		if(!empty($atts['img'])){
			$image_id = $atts['img'];
		}

		$images = wp_get_attachment_image_src($image_id, 'full');
		$sales_price_to = get_post_meta($product->get_id(), '_sale_price_dates_to', true);
		?>
		<div class="ps-section--sale-off ps-section pt-80 pb-40">
            <div class="ps-container">
            	
            	<?php if(!empty($atts['title'])):?>
                <div class="ps-section__header mb-50">
                    <h3 class="ps-section__title" <?php if(!empty($atts['subtitle'])){?>data-mask="<?php echo esc_html($atts['subtitle']);?>"<?php }?>><?php echo esc_html($atts['title']);?></h3>
                </div>
                <?php endif;?>

                <div class="ps-section__content">
                    <div class="row product" data-id="<?php echo esc_attr($product->get_id());?>" data-url="<?php echo get_permalink($product->get_id());?>" data-title="<?php echo esc_html($product->get_name());?>">
                        <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 ">
                            <div class="ps-hot-deal">
                                <h3><a href="<?php echo get_permalink($product->get_id());?>"><?php echo esc_html($product->get_name());?></a></h3>
                                
                                <p class="ps-hot-deal__price"><?php esc_html_e('Only', 'shoestheme-helpers');?>: <?php echo wp_kses_post($product->get_price_html());?></p>
                                
                                <?php self::proccess($product);?>

                                <?php if(!empty($sales_price_to)){self::countdown(date("F d, Y", $sales_price_to));}?>
                                
                                <?php
                                $class = implode( ' ', array_filter( array(
									            'button',
									            'product_type_' . $product->get_type(),
									            $product->is_purchasable() && $product->is_in_stock() ? 'add_to_cart_button' : '',
									            $product->supports( 'ajax_add_to_cart' ) ? 'ajax_add_to_cart' : '',
									        ) ) );
						      	echo apply_filters( 'woocommerce_sale_product_full_add_to_cart_link',
									sprintf( '<a rel="nofollow" href="%s" data-quantity="%s" data-product_id="%s" data-product_sku="%s" class="ps-btn product-item-cart %s">%s<i class="ps-icon-next"></i></a>',
										esc_url( $product->add_to_cart_url() ),
										esc_attr( isset( $quantity ) ? $quantity : 1 ),
										esc_attr( $product->get_id() ),
										esc_attr( $product->get_sku() ),
										esc_attr( isset( $class ) ? $class : 'button' ),
										esc_html__('Order Today', 'shoestheme-helpers')
									),
								$product );
						      	?>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 ">
                            <?php if($images):?>
                            <div class="ps-hotspot">

                            <?php 
                            $left1 = !empty($atts['hotspot_1_left']) ? $atts['hotspot_1_left'] : '';
                            $right1 = !empty($atts['hotspot_1_right']) ? $atts['hotspot_1_right'] : '';
                            $bottom1 = !empty($atts['hotspot_1_bottom']) ? $atts['hotspot_1_bottom'] : '';
                            $top1 = !empty($atts['hotspot_1_top']) ? $atts['hotspot_1_top'] : '';

                            $left2 = !empty($atts['hotspot_2_left']) ? $atts['hotspot_2_left'] : '';
                            $right2 = !empty($atts['hotspot_2_right']) ? $atts['hotspot_2_right'] : '';
                            $bottom2 = !empty($atts['hotspot_2_bottom']) ? $atts['hotspot_2_bottom'] : '';
                            $top2 = !empty($atts['hotspot_2_top']) ? $atts['hotspot_2_top'] : '';


                            $left3 = !empty($atts['hotspot_3_left']) ? $atts['hotspot_3_left'] : '';
                            $right3 = !empty($atts['hotspot_3_right']) ? $atts['hotspot_3_right'] : '';
                            $bottom3 = !empty($atts['hotspot_3_bottom']) ? $atts['hotspot_3_bottom'] : '';
                            $top3 = !empty($atts['hotspot_3_top']) ? $atts['hotspot_3_top'] : '';
                            ?>

                            	<?php if(!empty($atts['hotspot_1_title']) || !empty($atts['hotspot_1_desc'])):?>
                            	<a data-left="<?php echo esc_attr($left1);?>" data-right="<?php echo esc_attr($right1);?>" data-bottom="<?php echo esc_attr($bottom1);?>" data-top="<?php echo esc_attr($top1);?>" class="point first <?php if(!empty($atts['hotspot_1_active'])){echo 'active';}?>" href="javascript:void(0);"><i class="fa fa-plus"></i>
	                            	<span class="ps-hotspot__content">
	                          			<?php if(!empty($atts['hotspot_1_title'])){?>
	                          				<span class="heading"><?php echo esc_html($atts['hotspot_1_title']);?></span>
	                          			<?php }?>
	                          			<?php if(!empty($atts['hotspot_1_desc'])){?>
	                          				<span><?php echo esc_html($atts['hotspot_1_desc']);?></span>
	                          			<?php }?>
	                          		</span>
                          		</a>
                          		<?php endif;?>

                          		<?php if(!empty($atts['hotspot_2_title']) || !empty($atts['hotspot_2_desc'])):?>
                          		<a data-left="<?php echo esc_attr($left2);?>" data-right="<?php echo esc_attr($right2);?>" data-bottom="<?php echo esc_attr($bottom2);?>" data-top="<?php echo esc_attr($top2);?>" class="point second <?php if(!empty($atts['hotspot_2_active'])){echo 'active';}?>" href="javascript:void(0);"><i class="fa fa-plus"></i>
	                          		<span class="ps-hotspot__content">
	                          			<?php if(!empty($atts['hotspot_2_title'])){?><span class="heading"><?php echo esc_html($atts['hotspot_2_title']);?></span><?php }?>
	                          			<?php if(!empty($atts['hotspot_2_desc'])){?><span><?php echo esc_html($atts['hotspot_2_desc']);?></span><?php }?>
	                          		</span>
                          		</a>
                          		<?php endif;?>

                          		<?php if(!empty($atts['hotspot_3_title']) || !empty($atts['hotspot_3_desc'])):?>
                          		<a data-left="<?php echo esc_attr($left3);?>" data-right="<?php echo esc_attr($right3);?>" data-bottom="<?php echo esc_attr($bottom3);?>" data-top="<?php echo esc_attr($top3);?>" class="point third <?php if(!empty($atts['hotspot_3_active'])){echo 'active';}?>" href="javascript:void(0);"><i class="fa fa-plus"></i>
	                          		<span class="ps-hotspot__content">
	                          			<?php if(!empty($atts['hotspot_3_title'])){?><span class="heading"><?php echo esc_html($atts['hotspot_3_title']);?></span><?php }?>
	                          			<?php if(!empty($atts['hotspot_3_desc'])){?><span><?php echo esc_html($atts['hotspot_3_desc']);?></span><?php }?>
	                          		</span>
                          		</a>
                          		<?php endif;?>


                          		<img src="<?php echo esc_attr($images[0]);?>" alt="">
                          	</div>
                          	<?php endif;?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<?php
	}

	private static function countdown($str){
		echo shoestheme_helpers_product_countdown($str);
	}

	private static function proccess($product){
		echo shoestheme_helpers_product_proccess($product);
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Shoes - Product sale", 'shoestheme-helpers' ),
	      	"description" => esc_html__( "Products with countdown.", 'shoestheme-helpers' ),
	      	"base" => "noushoes_product_sale",
	      	"class" => "",
	      	"category" => esc_html__( "Shoes Theme", 'shoestheme-helpers'),
	      	"params" => array(
		        array(
					'type' => 'dropdown',
					'heading' => __( 'Style', 'shoestheme-helpers' ),
					'value' => array(
						__( 'Single Product Fullwidth', 'shoestheme-helpers' ) => 'full',
						__( 'Single Product Small', 'shoestheme-helpers' ) => 'small',
					),
					'admin_label' => true,
					'param_name' => 'type',
					'description' => __( 'Type of products show.', 'shoestheme-helpers' ),
				),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Product ID", 'shoestheme-helpers' ),
		            "param_name" => "id",
		            'dependency' => array(
						'element' => 'type',
						'value' => array('full', 'small'),
					),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "IDs posts, EX: 21,22,23", 'shoestheme-helpers' ),
		            "param_name" => "ids",
		            'dependency' => array(
						'element' => 'type',
						'value' => 'slide',
					),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Title of section", 'shoestheme-helpers' ),
		            "param_name" => "title",
		            'dependency' => array(
						'element' => 'type',
						'value' => 'full',
					),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Subtitle of section", 'shoestheme-helpers' ),
		            "param_name" => "subtitle",
		            'dependency' => array(
						'element' => 'type',
						'value' => 'full',
					),
		        ),
		        
		        array(
		            "type" => "attach_image",
		            "class" => "",
		            "heading" => esc_html__( "Image", 'shoestheme-helpers' ),
		            "param_name" => "img",
		            'description' => esc_html__('If used this image, it will replace the default.', 'shoestheme-helpers'),
		            'dependency' => array(
						'element' => 'type',
						'value' => array('full', 'small'),
					),
		        ),

		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Hotspot #1: Title", 'shoestheme-helpers' ),
		            "param_name" => "hotspot_1_title",
		            'dependency' => array(
						'element' => 'type',
						'value' => 'full',
					),
					'group' => esc_html__('Image Hotspot #1', 'shoestheme-helpers'),
		        ),
		        array(
		            "type" => "textarea",
		            "class" => "",
		            "heading" => esc_html__( "Hotspot #1: Description", 'shoestheme-helpers' ),
		            "param_name" => "hotspot_1_desc",
		            'dependency' => array(
						'element' => 'type',
						'value' => 'full',
					),
					'group' => esc_html__('Image Hotspot #1', 'shoestheme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Position For Hotspot #1: Left", 'shoestheme-helpers' ),
		            "param_name" => "hotspot_1_left",
		            'dependency' => array(
						'element' => 'type',
						'value' => 'full',
					),
					'group' => esc_html__('Image Hotspot #1', 'shoestheme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Position For Hotspot #1: Right", 'shoestheme-helpers' ),
		            "param_name" => "hotspot_1_right",
		            'dependency' => array(
						'element' => 'type',
						'value' => 'full',
					),
					'group' => esc_html__('Image Hotspot #1', 'shoestheme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Position For Hotspot #1: Bottom", 'shoestheme-helpers' ),
		            "param_name" => "hotspot_1_bottom",
		            'dependency' => array(
						'element' => 'type',
						'value' => 'full',
					),
					'group' => esc_html__('Image Hotspot #1', 'shoestheme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Position For Hotspot #1: Top", 'shoestheme-helpers' ),
		            "param_name" => "hotspot_1_top",
		            'dependency' => array(
						'element' => 'type',
						'value' => 'full',
					),
					'group' => esc_html__('Image Hotspot #1', 'shoestheme-helpers'),
		        ),
		        array(
		            "type" => "checkbox",
		            "class" => "",
		            "heading" => esc_html__( "Active", 'shoestheme-helpers' ),
		            "param_name" => "hotspot_1_active",
		            'dependency' => array(
						'element' => 'type',
						'value' => 'full',
					),
					'group' => esc_html__('Image Hotspot #1', 'shoestheme-helpers'),
		        ),


		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Hotspot #2: Title", 'shoestheme-helpers' ),
		            "param_name" => "hotspot_2_title",
		            'dependency' => array(
						'element' => 'type',
						'value' => 'full',
					),
					'group' => esc_html__('Image Hotspot #2', 'shoestheme-helpers'),
		        ),
		        array(
		            "type" => "textarea",
		            "class" => "",
		            "heading" => esc_html__( "Hotspot #2: Description", 'shoestheme-helpers' ),
		            "param_name" => "hotspot_2_desc",
		            'dependency' => array(
						'element' => 'type',
						'value' => 'full',
					),
					'group' => esc_html__('Image Hotspot #2', 'shoestheme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Position For Hotspot #2: Left", 'shoestheme-helpers' ),
		            "param_name" => "hotspot_2_left",
		            'dependency' => array(
						'element' => 'type',
						'value' => 'full',
					),
					'group' => esc_html__('Image Hotspot #2', 'shoestheme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Position For Hotspot #2: Right", 'shoestheme-helpers' ),
		            "param_name" => "hotspot_2_right",
		            'dependency' => array(
						'element' => 'type',
						'value' => 'full',
					),
					'group' => esc_html__('Image Hotspot #2', 'shoestheme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Position For Hotspot #2: Bottom", 'shoestheme-helpers' ),
		            "param_name" => "hotspot_2_bottom",
		            'dependency' => array(
						'element' => 'type',
						'value' => 'full',
					),
					'group' => esc_html__('Image Hotspot #2', 'shoestheme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Position For Hotspot #2: Top", 'shoestheme-helpers' ),
		            "param_name" => "hotspot_2_top",
		            'dependency' => array(
						'element' => 'type',
						'value' => 'full',
					),
					'group' => esc_html__('Image Hotspot #2', 'shoestheme-helpers'),
		        ),
		        array(
		            "type" => "checkbox",
		            "class" => "",
		            "heading" => esc_html__( "Active", 'shoestheme-helpers' ),
		            "param_name" => "hotspot_2_active",
		            'dependency' => array(
						'element' => 'type',
						'value' => 'full',
					),
					'group' => esc_html__('Image Hotspot #2', 'shoestheme-helpers'),
		        ),



		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Hotspot #3: Title", 'shoestheme-helpers' ),
		            "param_name" => "hotspot_3_title",
		            'dependency' => array(
						'element' => 'type',
						'value' => 'full',
					),
					'group' => esc_html__('Image Hotspot #3', 'shoestheme-helpers'),
		        ),
		        array(
		            "type" => "textarea",
		            "class" => "",
		            "heading" => esc_html__( "Hotspot #3: Description", 'shoestheme-helpers' ),
		            "param_name" => "hotspot_3_desc",
		            'dependency' => array(
						'element' => 'type',
						'value' => 'full',
					),
					'group' => esc_html__('Image Hotspot #3', 'shoestheme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Position For Hotspot #3: Left", 'shoestheme-helpers' ),
		            "param_name" => "hotspot_3_left",
		            'dependency' => array(
						'element' => 'type',
						'value' => 'full',
					),
					'group' => esc_html__('Image Hotspot #3', 'shoestheme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Position For Hotspot #3: Right", 'shoestheme-helpers' ),
		            "param_name" => "hotspot_3_right",
		            'dependency' => array(
						'element' => 'type',
						'value' => 'full',
					),
					'group' => esc_html__('Image Hotspot #3', 'shoestheme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Position For Hotspot #3: Bottom", 'shoestheme-helpers' ),
		            "param_name" => "hotspot_3_bottom",
		            'dependency' => array(
						'element' => 'type',
						'value' => 'full',
					),
					'group' => esc_html__('Image Hotspot #3', 'shoestheme-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Position For Hotspot #3: Top", 'shoestheme-helpers' ),
		            "param_name" => "hotspot_3_top",
		            'dependency' => array(
						'element' => 'type',
						'value' => 'full',
					),
					'group' => esc_html__('Image Hotspot #3', 'shoestheme-helpers'),
		        ),
		        array(
		            "type" => "checkbox",
		            "class" => "",
		            "heading" => esc_html__( "Active", 'shoestheme-helpers' ),
		            "param_name" => "hotspot_3_active",
		            'dependency' => array(
						'element' => 'type',
						'value' => 'full',
					),
					'group' => esc_html__('Image Hotspot #3', 'shoestheme-helpers'),
		        ),
		   
	      	)
	    ) );
		endif;
	}
}
?>