<?php
/**
* 
*/
class Shoestheme_Helpers_Shortcode_Testimonial_Item
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		$atts = shortcode_atts( array(
			'name' => '',
			'rating' => '',
			'img' => '',
			'desc' => '',
		), $atts, 'noushoes_testimonial_item' );
		
		ob_start();
			if(!empty($atts['desc'])):
			?>
			<div class="ps-testimonial">
                <?php 
				if($atts['img']):
				$image = wp_get_attachment_image_src($atts['img'], 'thumbnail');
				if($image){	
				?>
              	<div class="ps-testimonial__thumbnail"><img src="<?php echo esc_attr($image[0]);?>" alt=""><i class="fa fa-quote-left"></i></div>
              	<?php }endif;?>
                <header>
                    <?php if(!empty($atts['rating'])):?>
	              		<select class="ps-rating">
		                  <option value="1" <?php selected($atts['rating'], 1);?>>1</option>
		                  <option value="2" <?php selected($atts['rating'], 2);?>>2</option>
		                  <option value="3" <?php selected($atts['rating'], 3);?>>3</option>
		                  <option value="4" <?php selected($atts['rating'], 4);?>>4</option>
		                  <option value="5" <?php selected($atts['rating'], 5);?>>5</option>
		                </select>
	              	<?php endif;?>
                    <?php if(!empty($atts['name'])):?>
	              		<p><?php echo esc_html($atts['name']);?></p>
	              	<?php endif;?>
                </header>

                <?php if(!empty($atts['desc'])):?>
                <footer>
                    <p>“<?php echo esc_html($atts['desc']);?>“</p>
                </footer>
                <?php endif;?>
            </div>
			<?php	
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		vc_map( array(
	      	"name" => esc_html__( "Shoes - Testimonial Item", 'shoestheme-helpers' ),
	      	"base" => "noushoes_testimonial_item",
	      	"class" => "",
	      	"category" => esc_html__( "Shoes Theme", 'shoestheme-helpers'),
	      	"content_element" => true,
    		"as_child" => array('only' => 'noushoes_testimonial'),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Name", 'shoestheme-helpers' ),
		            "param_name" => "name",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Rating", 'shoestheme-helpers' ),
		            "param_name" => "rating",
		        ),
		        array(
		            "type" => "attach_image",
		            "class" => "",
		            "heading" => esc_html__( "Avatar", 'shoestheme-helpers' ),
		            "param_name" => "img",
		        ),
		        array(
		            "type" => "textarea",
		            "class" => "",
		            "heading" => esc_html__( "Description", 'shoestheme-helpers' ),
		            "param_name" => "desc",
		        )
	      	)
	    ) );
	}
}
?>