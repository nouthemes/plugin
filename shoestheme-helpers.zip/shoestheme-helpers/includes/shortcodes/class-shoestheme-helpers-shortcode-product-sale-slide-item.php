<?php
/**
* 
*/
class Shoestheme_Helpers_Shortcode_Product_Sale_Slide_Item
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		if ( empty( $atts ) ) {
			return '';
		}

		$atts = shortcode_atts( array(
			'id' => '',
			'img' => '',
		), $atts, 'noushoes_product_sale_slide_item' );

		if(!empty($atts['id']) && intval($atts['id'])):

			$args = array(
					'post_type' => 'product', 
					'post_status' => 'publish',
					'p' => $atts['id']
				);
			$products = new WP_Query($args);
			if($products->have_posts()):
			ob_start();
				while($products->have_posts()): $products->the_post();
					$product = wc_get_product(get_the_ID());
					if($product){
						$sales_price_to = get_post_meta($product->get_id(), '_sale_price_dates_to', true);
						$image_id = $product->get_image_id();
						if(!empty($atts['img'])){
							$image_id = $atts['img'];
						}

						$images = wp_get_attachment_image_src($image_id, 'full');
						?>
						<div class="ps-product--hotdeal product" data-id="<?php echo esc_attr($product->get_id());?>" data-url="<?php echo get_permalink($product->get_id());?>" data-title="<?php echo esc_html($product->get_name());?>">
			                

							<?php if($images):?>
				            <div class="ps-product__thumbnail">
				            	<a class="ps-product__overlay" href="<?php echo get_permalink($product->get_id());?>"></a>
				            	<img src="<?php echo esc_attr($images[0]);?>" alt="" />
				            </div>
				            <?php endif;?>

			              
			                <div class="ps-product__content">
			                	<a class="ps-product__title" href="<?php echo get_permalink($product->get_id());?>"><?php echo esc_html($product->get_name());?></a>

			                    <p class="ps-product__price"><?php esc_html_e('Only', 'shoestheme-helpers');?>: <?php echo wp_kses_post($product->get_price_html());?></p>

			                    <?php self::proccess($product);?>

		                        <?php if(!empty($sales_price_to)){self::countdown(date("F d, Y", $sales_price_to));}?>

			                    <?php
		                            $class = implode( ' ', array_filter( array(
										            'button',
										            'product_type_' . $product->get_type(),
										            $product->is_purchasable() && $product->is_in_stock() ? 'add_to_cart_button' : '',
										            $product->supports( 'ajax_add_to_cart' ) ? 'ajax_add_to_cart' : '',
										        ) ) );
							      	echo apply_filters( 'woocommerce_sale_product_slide_item_add_to_cart_link',
										sprintf( '<a rel="nofollow" href="%s" data-quantity="%s" data-product_id="%s" data-product_sku="%s" class="ps-btn product-item-cart %s">%s<i class="ps-icon-next"></i></a>',
											esc_url( $product->add_to_cart_url() ),
											esc_attr( isset( $quantity ) ? $quantity : 1 ),
											esc_attr( $product->get_id() ),
											esc_attr( $product->get_sku() ),
											esc_attr( isset( $class ) ? $class : 'button' ),
											esc_html__('Order Today', 'shoestheme-helpers')
										),
									$product );
							      	?>
			                </div>
			            </div>
						<?php
					}
				endwhile;
			endif;wp_reset_postdata();
		endif; 
		return ob_get_clean();
	}

	private static function countdown($str){
		echo shoestheme_helpers_product_countdown($str);
	}

	private static function proccess($product){
		echo shoestheme_helpers_product_proccess($product);
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Shoes - Product Sale Carousel Item", 'shoestheme-helpers' ),
	      	"base" => "noushoes_product_sale_slide_item",
	      	"class" => "",
	      	"as_child" => array('only' => 'noushoes_product_sale_slide'),
	      	"category" => esc_html__( "Shoes Theme", 'shoestheme-helpers'),
	      	"params" => array(
		        
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Product ID", 'shoestheme-helpers' ),
		            "param_name" => "id",
		      
		        ),
		        array(
		            "type" => "attach_image",
		            "class" => "",
		            "heading" => esc_html__( "Image", 'shoestheme-helpers' ),
		            "param_name" => "img",
		            'description' => esc_html__('If used this image, it will replace the default.', 'shoestheme-helpers'),
		          
		        ),
		        
		 
		   
	      	)
	    ) );
		endif;
	}
}
?>