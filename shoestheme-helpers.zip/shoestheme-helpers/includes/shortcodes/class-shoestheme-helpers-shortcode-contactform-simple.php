<?php
/**
* 
*/
class Shoestheme_Helpers_Shortcode_Contactform_Simple
{
	
	public static function shortcode($atts){
		$atts = shortcode_atts( array(
			'title' => '',
			'desc' => '',
			'style' => '',
		), $atts, 'noushoes_contact_form_simple' );
		ob_start();
		?>
		<div class="ps-contact-simple">
			<div class="ps-section__header">
                <?php if(!empty($atts['title']) && !empty($atts['desc'])){?>
                	<h2 class="ps-section__title" data-mask="<?php echo esc_html($atts['desc']);?>"><?php echo esc_html($atts['title']);?></h2>
                <?php }?>
                <form class="ps-contact__form" action="do_action" method="post">
                	<?php if($atts['style'] != 'normal'):?>
	                    <div class="form-group">
                            <label><?php esc_html_e('Name', 'shoestheme-helpers');?> <sub>*</sub></label>
                            <input class="form-control" type="text" name="name">
                        </div>
                        <div class="form-group">
                            <label><?php esc_html_e('Email', 'shoestheme-helpers');?> <sub>*</sub></label>
                            <input class="form-control" type="email" name="email">
                        </div>
                        <div class="form-group mb-25">
                            <label><?php esc_html_e('Your Message', 'shoestheme-helpers');?> <sub>*</sub></label>
                            <textarea class="form-control" row="6" name="content"></textarea>
                        </div>
                        <div class="form-group">
                            <button class="ps-btn noushoes-contact__submit"><?php esc_html_e('Send Message', 'shoestheme-helpers');?><i class="ps-icon-next"></i></button>
                        </div>
                    <?php else:?>
                    	<div class="row">
	                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 ">
	                            <div class="form-group">
	                                <label><?php esc_html_e('Name', 'shoestheme-helpers');?> <sub>*</sub></label>
	                                <input class="form-control" type="text" name="name">
	                            </div>
	                        </div>
	                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 ">
	                            <div class="form-group">
	                                <label><?php esc_html_e('Email', 'shoestheme-helpers');?> <sub>*</sub></label>
	                                <input class="form-control" type="email" name="email">
	                            </div>
	                        </div>
	                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 ">
	                            <div class="form-group mb-25">
	                                <label><?php esc_html_e('Your Message', 'shoestheme-helpers');?> <sub>*</sub></label>
	                                <textarea class="form-control" row="6" name="content"></textarea>
	                            </div>
	                            <div class="form-group">
	                                <button class="ps-btn noushoes-contact__submit"><?php esc_html_e('Send Message', 'shoestheme-helpers');?><i class="ps-icon-next"></i></button>
	                            </div>
	                        </div>
	                    </div>
                    	
                    <?php endif;?>
                </form>
            </div>
	    </div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Shoes - Simple contact form", 'shoestheme-helpers' ),
	      	"base" => "noushoes_contact_form_simple",
	      	"class" => "",
	      	"category" => esc_html__( "Shoes Theme", 'shoestheme-helpers'),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", 'shoestheme-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textarea",
		            "class" => "",
		            "heading" => esc_html__( "Description", 'shoestheme-helpers' ),
		            "param_name" => "desc",
		        ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "heading" => esc_html__( "Type of form show", 'shoestheme-helpers' ),
		            "param_name" => "style",
		            "value" => array(esc_html__('Fields Full', 'shoestheme-helpers') => 'full', esc_html__('Normal', 'shoestheme-helpers') => 'normal'), 
		        ),
		        
	      	)
	    ) );
		endif;
	}
}