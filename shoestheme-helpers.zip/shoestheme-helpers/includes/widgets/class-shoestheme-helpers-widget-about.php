<?php 
defined( 'ABSPATH' ) OR exit;

/**
* Class widget about
*
* @author nouthemes [nouthemes@gmail.com] 
* @since 1.0
* @Code Nam
*/

class Shoestheme_Helpers_Widget_About extends WP_Widget {

	public function __construct() {
		$widget_ops = array(
			'classname' => 'ps-widget--info',
			'description' => esc_html__( 'About store with phone, email, address ...', 'shoes' ),
			'customize_selective_refresh' => true,
		);
		parent::__construct('Shoestheme_Helpers_Widget_About', esc_html__('* Shoes - About store', 'shoes'), $widget_ops);
	}

	/**
	 * @param array $args
	 * @param array $instance
	 */
	// Creating widget front-end
	// This is where the action happens
	public function widget( $args, $instance ) {

		$title = ( isset($instance['title']) && !empty($instance['title']) ) ? $instance['title'] : '';
		$phone = ( isset($instance['phone_1']) && !empty($instance['phone_1']) ) ? $instance['phone_1'] : '';
		$email = ( isset($instance['email']) && !empty($instance['email']) ) ? $instance['email'] : '';
		$address = ( isset($instance['address']) && !empty($instance['address']) ) ? $instance['address'] : '';
		$fax = ( isset($instance['fax']) && !empty($instance['fax']) ) ? $instance['fax'] : '';
		$logo = ( isset($instance['logo']) && !empty($instance['logo']) ) ? $instance['logo'] : '';
		

		echo $args['before_widget'];
		
			?>
			<header>
				<?php if(!empty($logo)){?><a class="ps-logo" href="<?php echo esc_url(home_url('/'));?>"><img src="<?php echo esc_attr($logo);?>" alt=""></a><?php }?>
                <?php if(!empty($title)){?><h3 class="ps-widget__title"><?php echo esc_html($title);?></h3><?php }?>
            </header>
            <footer>
                <?php if(!empty($address)){?><p><strong><?php echo esc_html($address);?></strong></p><?php }?>
                <?php if(!empty($email)){?><p><?php esc_html_e('Email', 'shoes');?>: <a href='mailto:<?php echo esc_html($email);?>'><?php echo esc_html($email);?></a></p><?php }?>
                <?php if(!empty($phone)){?><p><?php esc_html_e('Phone', 'shoes');?>: <?php echo esc_html($phone);?></p><?php }?>
                <?php if(!empty($fax)){?><p><?php esc_html_e('Fax', 'shoes');?>: <?php echo esc_html($fax);?></p><?php }?>
            </footer>
			<?php
		echo $args['after_widget'];

	}
		
	// Widget Backend 
	public function form( $instance ) {

		$instance = wp_parse_args( 
			(array) $instance, array(
									 'title' => '', 
									 'phone_1' => '',
									 'fax' => '',
									 'email' => '',
									 'address' => '',
									 'logo' => '',
									 ) 
		);
		$title 				= strip_tags($instance['title']);
		$phone_1            = sanitize_text_field( $instance['phone_1'] );
		$fax            = sanitize_text_field( $instance['fax'] );
		$logo     		= sanitize_text_field( $instance['logo'] );
		$email           	= sanitize_text_field( $instance['email'] );
		$address     		= sanitize_text_field( $instance['address'] );
		?>

		<p><label for="<?php echo esc_attr( $this->get_field_id('title') ); ?>"><?php esc_html_e('Title:', 'shoes'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('title') ); ?>" name="<?php echo esc_attr( $this->get_field_name('title') ); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>

		
		<p><label for="<?php echo esc_attr( $this->get_field_id('phone_1') ); ?>"><?php esc_html_e('Phone:', 'shoes'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('phone_1') ); ?>" name="<?php echo esc_attr( $this->get_field_name('phone_1') ); ?>" type="text" value="<?php echo esc_attr($phone_1); ?>" /></p>

		<p><label for="<?php echo esc_attr( $this->get_field_id('fax') ); ?>"><?php esc_html_e('Fax:', 'shoes'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('fax') ); ?>" name="<?php echo esc_attr( $this->get_field_name('fax') ); ?>" type="text" value="<?php echo esc_attr($fax); ?>" /></p>

		<p><label for="<?php echo esc_attr( $this->get_field_id('email') ); ?>"><?php esc_html_e('Email:', 'shoes'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('email') ); ?>" name="<?php echo esc_attr( $this->get_field_name('email') ); ?>" type="email" value="<?php echo esc_attr($email); ?>" /></p>

		<p><label for="<?php echo esc_attr( $this->get_field_id('address') ); ?>"><?php esc_html_e('Address:', 'shoes'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('address') ); ?>" name="<?php echo esc_attr( $this->get_field_name('address') ); ?>" type="text" value="<?php echo esc_attr($address); ?>" /></p>

		<p><label for="<?php echo esc_attr( $this->get_field_id('logo') ); ?>"><?php esc_html_e('Logo:', 'shoes'); ?></label>
		<?php echo shoestheme_helpers_cs_add_element(
      		array(
      			'title' => '',
      			'id' => esc_attr( $this->get_field_id('logo') ),
      			'name' => esc_attr( $this->get_field_name('logo') ),
      			'type' => 'upload',
      			'value' => $logo,
      			)
      	);?></p>
		
		<?php
	}

	
	
	// Updating widget replacing old instances with new
	public function update( $new_instance, $old_instance ) {
		
		$instance = $old_instance;

		$instance['title'] 				= strip_tags($new_instance['title']);
		
		$instance['phone_1']            = sanitize_text_field( $new_instance['phone_1'] );
		$instance['fax']            = sanitize_text_field( $new_instance['fax'] );
		$instance['logo']     		= sanitize_text_field( $new_instance['logo'] );
		$instance['email']            	= sanitize_text_field( $new_instance['email'] );
		$instance['address']     		= sanitize_text_field( $new_instance['address'] );

		return $instance;
	}

}

?>