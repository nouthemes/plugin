<?php 
defined( 'ABSPATH' ) OR exit;

/**
* Class widget Banner
*
* @author nouthemes [nouthemes@gmail.com] 
* @since 1.0
* @Code Nam
*/

class Shoestheme_Helpers_Widget_Banner extends WP_Widget {

	/**
	 * Sets up a new Upload a banner.
	 *
	 * @since 2.8.0
	 * @access public
	 */
	public function __construct() {
		$widget_ops = array(
			'description' => esc_html__( 'Upload a banner.', 'shoestheme-helpers' ),
			'customize_selective_refresh' => true,
		);
		parent::__construct('Shoestheme_Helpers_Widget_Banner', esc_html__('* Shoes - Banner', 'shoestheme-helpers'), $widget_ops);
	}

	/**
	 * @param array $args
	 * @param array $instance
	 */
	// Creating widget front-end
	// This is where the action happens
	public function widget( $args, $instance ) {

		$url = ( isset($instance['url']) && !empty($instance['url']) ) ? $instance['url'] : '';
		$img = ( isset($instance['img']) && !empty($instance['img']) ) ? $instance['img'] : '';
		$title = ( isset($instance['title']) && !empty($instance['title']) ) ? $instance['title'] : '';
		if(!empty($img)){
			echo $args['before_widget'];
		
			if(!empty($title)){ echo $args['before_title'].$title.$args['after_title']; }
			
			if(!empty($img)):
			?>
			<div class="ps-widget__content"><a href="<?php echo esc_attr($url);?>"><img src="<?php echo esc_attr($img);?>" alt=""></a></div>
			<?php
			endif;
			echo $args['after_widget'];
		}	

	}
		
	// Widget Backend 
	public function form( $instance ) {

		$instance = wp_parse_args( 
			(array) $instance, array(
									 'url' => '', 
									 'img' => '',
									 'title' => '',
									 ) 
		);
		$url = strip_tags($instance['url']);
		$title = strip_tags($instance['title']);
		$img = sanitize_text_field( $instance['img'] );
		?>

		<p><label for="<?php echo esc_attr( $this->get_field_id('title') ); ?>"><?php esc_html_e('Title:', 'shoestheme-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('title') ); ?>" name="<?php echo esc_attr( $this->get_field_name('title') ); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>

		<p><label for="<?php echo esc_attr( $this->get_field_id('url') ); ?>"><?php esc_html_e('Link:', 'shoestheme-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('url') ); ?>" name="<?php echo esc_attr( $this->get_field_name('url') ); ?>" type="text" value="<?php echo esc_attr($url); ?>" /></p>

		
		<p><label for="<?php echo esc_attr( $this->get_field_id('img') ); ?>"><?php esc_html_e('Upload banner', 'shoestheme-helpers'); ?></label></p>
		<div class="cs-element cs-field-upload">
			<div class="cs-fieldset">
				<input type="text" class="widefat" id="<?php echo esc_attr( $this->get_field_id('img') ); ?>" name="<?php echo esc_attr( $this->get_field_name('img') ); ?>" value="<?php echo esc_attr($img); ?>">
				<a href="#" class="button cs-add" data-frame-title="<?php esc_html_e('Upload', 'shoestheme-helpers');?>" data-upload-type="image" data-insert-title="<?php esc_html_e('Use Image', 'shoestheme-helpers');?>"><?php esc_html_e('Upload', 'shoestheme-helpers');?></a>
			</div>
			<div class="clear"></div>
		</div>

		<?php
	}

	
	
	// Updating widget replacing old instances with new
	public function update( $new_instance, $old_instance ) {
		
		$instance = $old_instance;

		$instance['title'] = strip_tags($new_instance['title']);
		$instance['url'] = strip_tags($new_instance['url']);
		$instance['img'] = sanitize_text_field( $new_instance['img'] );

		return $instance;
	}

}

?>