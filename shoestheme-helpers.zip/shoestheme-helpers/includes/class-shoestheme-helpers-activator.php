<?php

/**
 * Fired during plugin activation
 *
 * @link       http://nouthemes.com/
 * @since      1.0.0
 *
 * @package    Shoestheme_Helpers
 * @subpackage Shoestheme_Helpers/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Shoestheme_Helpers
 * @subpackage Shoestheme_Helpers/includes
 * @author     Nouthemes.com <nouthemes@gmail.com>
 */
class Shoestheme_Helpers_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
		self::update_option();
	}

	public static function update_option(){
		
		update_option('posts_per_page', 9);
		update_option('date_format', 'F d, Y');
		update_option('thumbnail_size_w', '300');
		update_option('thumbnail_size_h', '300');

		$woocs_option = get_option('woocs');
		if(empty($woocs_option)){
			$woocs = array(
				'USD' => array(
					'name' => 'USD',
					'rate' => '1',
					'symbol' => '&#36;',
					'position' => 'left',
					'is_etalon' => '1',
					'hide_cents' => '0',
					'decimals' => '2',
					'flag' => SHOESTHEME_HELPERS_URL.'public/images/flag/usa.svg',
					'description' => esc_html__('USA dollar', 'shoestheme-helpers'),
					),
				'EUR' => array(
					'name' => 'EUR',
					'rate' => '0.89',
					'symbol' => '&euro;',
					'position' => 'left',
					'is_etalon' => '0',
					'hide_cents' => '0',
					'decimals' => '2',
					'flag' => SHOESTHEME_HELPERS_URL.'public/images/flag/europe.png',
					'description' => esc_html__('European Euro', 'shoestheme-helpers'),
					),
				);
			update_option('woocs', $woocs);
		}
	}

}
