<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// CUSTOMIZE SETTINGS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options              = array();

// -----------------------------------------
// Customize Core Fields                   -
// -----------------------------------------
$options[]            = array(
  'name'              => 'header',
  'title'             => esc_html__('Header', 'shoestheme-helpers'),
  'settings'          => array(

    // textarea
    array(
      'name'          => 'header_notify',
      'transport'     => 'postMessage',
      'control'       => array(
        'label'       => esc_html__('Address', 'shoestheme-helpers'),
        'type'        => 'textarea',
      ),
    ),
    array(
      'name'          => 'logo',
      'transport'     => 'postMessage',
      'control'       => array(
        'label'       => esc_html__('Logo', 'shoestheme-helpers'),
        'type'        => 'upload',
      ),
    ),

  )
);
$options[]            = array(
  'name'              => 'footer',
  'title'             => esc_html__('Footer', 'shoestheme-helpers'),
  'settings'          => array(

    array(
      'name'          => 'copyright_subheading',
      'control'       => array(
        'type'        => 'cs_field',
        'options'     => array(
          'type'      => 'subheading',
          'content'   => esc_html__('Copyright', 'shoestheme-helpers'),
        ),
      ),
    ),
    // textarea
    array(
      'name'          => 'copyright',
      'transport'     => 'postMessage',
      'control'       => array(
        'label'       => esc_html__('Copyright text', 'shoestheme-helpers'),
        'type'        => 'textarea',
      ),
    ),

  )
);

Shoestheme_Helpers_CSFramework_Customize::instance( $options );
