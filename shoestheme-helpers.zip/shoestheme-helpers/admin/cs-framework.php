<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
/**
 *
 * ------------------------------------------------------------------------------------------------
 *
 * Codestar Framework
 * A Lightweight and easy-to-use WordPress Options Framework
 *
 * Plugin Name: Codestar Framework
 * Plugin URI: http://codestarframework.com/
 * Author: Codestar
 * Author URI: http://codestarlive.com/
 * Version: 1.0.1
 * Description: A Lightweight and easy-to-use WordPress Options Framework
 * License: GPLv2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain: cs-framework
 *
 * ------------------------------------------------------------------------------------------------
 *
 * Copyright 2015 Codestar <info@codestarlive.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * ------------------------------------------------------------------------------------------------
 *
 */

// ------------------------------------------------------------------------------------------------
require_once plugin_dir_path( __FILE__ ) .'/cs-framework-path.php';
// ------------------------------------------------------------------------------------------------

if( ! function_exists( 'shoestheme_helpers_cs_framework_init' ) && ! class_exists( 'Shoestheme_Helpers_CSFramework' ) ) {
  function shoestheme_helpers_cs_framework_init() {

    // active modules
    define( 'SHOESTHEME_HELPERS_CS_ACTIVE_FRAMEWORK',  false );
    define( 'SHOESTHEME_HELPERS_CS_ACTIVE_METABOX',    true );
    define( 'SHOESTHEME_HELPERS_CS_ACTIVE_TAXONOMY',   true );
    define( 'SHOESTHEME_HELPERS_CS_ACTIVE_SHORTCODE',  false );
    define( 'SHOESTHEME_HELPERS_CS_ACTIVE_CUSTOMIZE',  false );

    // helpers
    shoestheme_helpers_cs_locate_template( 'functions/deprecated.php'     );
    shoestheme_helpers_cs_locate_template( 'functions/fallback.php'       );
    shoestheme_helpers_cs_locate_template( 'functions/helpers.php'        );
    shoestheme_helpers_cs_locate_template( 'functions/actions.php'        );
    shoestheme_helpers_cs_locate_template( 'functions/enqueue.php'        );
    shoestheme_helpers_cs_locate_template( 'functions/sanitize.php'       );
    shoestheme_helpers_cs_locate_template( 'functions/validate.php'       );

    // classes
    shoestheme_helpers_cs_locate_template( 'classes/abstract.class.php'   );
    shoestheme_helpers_cs_locate_template( 'classes/options.class.php'    );
    shoestheme_helpers_cs_locate_template( 'classes/framework.class.php'  );
    shoestheme_helpers_cs_locate_template( 'classes/metabox.class.php'    );
    shoestheme_helpers_cs_locate_template( 'classes/taxonomy.class.php'   );
    shoestheme_helpers_cs_locate_template( 'classes/shortcode.class.php'  );
    shoestheme_helpers_cs_locate_template( 'classes/customize.class.php'  );

    // configs
    shoestheme_helpers_cs_locate_template( 'config/framework.config.php'  );
    shoestheme_helpers_cs_locate_template( 'config/metabox.config.php'    );
    shoestheme_helpers_cs_locate_template( 'config/taxonomy.config.php'   );
    shoestheme_helpers_cs_locate_template( 'config/shortcode.config.php'  );
    shoestheme_helpers_cs_locate_template( 'config/customize.config.php'  );

  }
  add_action( 'init', 'shoestheme_helpers_cs_framework_init', 10 );
}
