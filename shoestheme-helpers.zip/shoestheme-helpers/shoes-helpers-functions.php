<?php
/**
* Sync from customizer vs theme options
* 
* @author nouthemes [nouthemes@gmail.com]
* @since 1.0
* @return url
* @code Nam
*/
if(!function_exists('shoestheme_helpers_theme_option')){
  function shoestheme_helpers_theme_option($setting, $default = '')
  { 
    $options = get_option( '_noushoes_options', array() );
    $value = $default;
    if ( isset( $options[ $setting ] ) ) {
        $value = $options[ $setting ];
    }
    return $value;
  }
}

/**
 *
 * Get option
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! function_exists( 'shoestheme_helpers_cs_get_option' ) ) {
  function shoestheme_helpers_cs_get_option( $option_name = '', $default = '' ) {

    $options = apply_filters( 'cs_get_option', get_option( SHOESTHEME_HELPERS_CS_OPTION ), $option_name, $default );

    if( ! empty( $option_name ) && ! empty( $options[$option_name] ) ) {
      return $options[$option_name];
    } else {
      return ( ! empty( $default ) ) ? $default : null;
    }

  }
}

function shoestheme_helpers_get_current_id(){
	$object_id = get_queried_object_id();
    if ( ( get_option( 'show_on_front' ) && get_option( 'page_for_posts' ) && is_home() ) || ( get_option( 'page_for_posts' ) && is_archive() && ! is_post_type_archive() && ! is_tax() ) && ! ( is_tax( 'product_cat' ) || is_tax( 'product_tag' ) ) || ( get_option( 'page_for_posts' ) && is_search() ) ) {
        
        $page_ID = get_option( 'page_for_posts' );

    } else {

        if ( isset( $object_id ) ) {
            $page_ID = $object_id;
        }

        if ( ! is_singular() ) {
            $page_ID = false;
        }

    }

    return $page_ID;
}

/**
 * Get post like
 *
 * @package Masta
 * @since 1.0
 * @author nouthemes [nouthemes@gmail.com]
 */

if(!function_exists('shoestheme_helpers_post_like')){
	function shoestheme_helpers_post_like($id = null) 
	{
		$post_id = shoestheme_helpers_get_current_id();
		if($id){
			$post_id = $id;
		}
		$meta = get_post_meta($post_id, '_post_like_count', true);

		if ( is_numeric( $meta ) && $meta > 0 ) { 
			$number = shoestheme_helpers_format_count($meta);
		} else {
			$number = 0;
		}
			
	    return $number;
	}
}


/**
 * Format number with K, M, B
 *
 * @package Masta
 * @since 1.0
 * @author nouthemes [nouthemes@gmail.com]
 */
if(!function_exists('shoestheme_helpers_format_count')){
	function shoestheme_helpers_format_count( $number ) {
		$precision = 2;
		if ( $number >= 1000 && $number < 1000000 ) {
			$formatted = number_format( $number/1000, $precision ).'K';
		} else if ( $number >= 1000000 && $number < 1000000000 ) {
			$formatted = number_format( $number/1000000, $precision ).'M';
		} else if ( $number >= 1000000000 ) {
			$formatted = number_format( $number/1000000000, $precision ).'B';
		} else {
			$formatted = $number; // Number is less than 1000
		}
		$formatted = str_replace( '.00', '', $formatted );
		return $formatted;
	}
}


/**
 * Get current IP address
 *
 * @package Masta
 * @since 1.0
 * @author nouthemes [nouthemes@gmail.com]
 */
if(!function_exists('shoestheme_helpers_get_ip')){
	function shoestheme_helpers_get_ip() {
		if ( isset( $_SERVER['HTTP_CLIENT_IP'] ) && ! empty( $_SERVER['HTTP_CLIENT_IP'] ) ) {
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		} elseif ( isset( $_SERVER['HTTP_X_FORWARDED_FOR'] ) && ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} else {
			$ip = ( isset( $_SERVER['REMOTE_ADDR'] ) ) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
		}
		$ip = filter_var( $ip, FILTER_VALIDATE_IP );
		$ip = ( $ip === false ) ? '0.0.0.0' : $ip;
		return $ip;
	}
}


if(!function_exists('shoestheme_helpers_already_liked')){
	function shoestheme_helpers_already_liked( $post_id, $is_comment = null ) {
		
		$post_users = NULL;
		$user_id = NULL;

		if ( is_user_logged_in() ) { // user is logged in

			$user_id = get_current_user_id();
			$post_meta_users = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_liked" ) : get_post_meta( $post_id, "_user_liked" );
			
			if ( count( $post_meta_users ) != 0 ) {
				$post_users = $post_meta_users[0];
			}

		} else { // user is anonymous

			$user_id = shoestheme_helpers_get_ip();
			$post_meta_users = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_IP" ) : get_post_meta( $post_id, "_user_IP" ); 
			
			if ( count( $post_meta_users ) != 0 ) { // meta exists, set up values
				$post_users = $post_meta_users[0];
			}
		}

		if ( is_array( $post_users ) && in_array( $user_id, $post_users ) ) {
			return true;
		} else {
			return false;
		}
	}
}

/**
 * Utility returns the button icon for "like" action
 * @since    1.0
 */
if(!function_exists('shoestheme_helpers_get_liked_icon')){
	function shoestheme_helpers_get_liked_icon() {
		$loved_icon = shoestheme_helpers_theme_option('shoestheme_helpers_loved_icon', 'fa fa-heart');
		$icon = ' <i class="'.esc_attr( $loved_icon ).'"></i>';
		return $icon;
	}
}	

/**
 * Utility returns the button icon for "unlike" action
 * @since   1.0
 */
if(!function_exists('shoestheme_helpers_get_unliked_icon')){
	function shoestheme_helpers_get_unliked_icon() {
		$love_icon = shoestheme_helpers_theme_option('shoestheme_helpers_love_icon', 'fa fa-heart-o');
		$icon = '<i class="'.esc_attr( $love_icon ).'"></i>';
		return $icon;
	}
}	

if(!function_exists('shoestheme_helpers_button_like')){
	function shoestheme_helpers_button_like($post_id, $class = '', $icon = '', $count = '', $title = '', $echo = true)
	{
		if(empty($title)){
			$title = esc_html__('Like', 'shoestheme-helpers');
		}

		if(empty($icon)){
			$icon = shoestheme_helpers_get_unliked_icon();
		}

		$liked = shoestheme_helpers_already_liked($post_id);
		if($liked){
			$class = esc_attr( 'liked', 'shoestheme-helpers' );
			$title = esc_html__( 'Unlike', 'shoestheme-helpers' );
			$icon = shoestheme_helpers_get_liked_icon();
		}
		
		$output = '<span data-id="'.intval($post_id).'" class="post-like like '.esc_attr($class).'">'.wp_kses_post($icon).' ' . esc_attr( $title ) . '</span>';

		
		$display_button = shoestheme_helpers_theme_option('shoestheme_helpers_post_like');
		$post_id = shoestheme_helpers_get_current_id();
		if($post_id){
			$noushoes_meta = get_post_meta( $post_id, 'noushoes_layout_settings', true );
	        if ( !empty($noushoes_meta['social_like']) ) {
	          $display_button = $noushoes_meta['social_like'];
	        }
		}

		if(empty($display_button)){
			$output = '';
		}

		if($echo){
			echo $output;
		}else{
			return $output;
		}
	}
}

/**
* Single share post
*
*/
if(!function_exists('shoestheme_helpers_share_post')){
	function shoestheme_helpers_share_post()
	{
		$share = shoestheme_helpers_theme_option('noushoes_enable_share');
		$post_id = shoestheme_helpers_get_current_id();
		if($post_id){
			$noushoes_meta = get_post_meta( $post_id, 'noushoes_layout_settings', true );
	        if ( !empty($noushoes_meta['social_share']) ) {
	          $share = $noushoes_meta['social_share'];
	        }
		}
		if($share):
			$facebook = shoestheme_helpers_theme_option('noushoes_single_share_facebook');
			$google = shoestheme_helpers_theme_option('noushoes_single_share_google');
			$twitter = shoestheme_helpers_theme_option('noushoes_single_share_twitter');
			if( !empty($facebook) || !empty($google) || !empty($twitter) ):
			?>
				<div class="ps-post__social share-posts">
					<i class="fa fa-share-alt"></i><a href="#"><?php esc_html_e('Share', 'shoestheme-helpers');?></a>
	                <ul data-title="<?php the_title();?>" data-url="<?php the_permalink();?>">
	                	<?php if(!empty($facebook)):?>
	                    <li><a href="#" class="share" data-type="facebook"><i class="fa fa-facebook"></i></a></li>
	                    <?php endif;?>

	                    <?php if(!empty($twitter)):?>
	                    <li><a href="#" class="share" data-type="twitter"><i class="fa fa-twitter"></i></a></li>
	                    <?php endif;?>

	                    <?php if(!empty($google)):?>
	                    <li><a href="#" class="share" data-type="google"><i class="fa fa-google-plus"></i></a></li>
	                    <?php endif;?>
	                </ul>
	            </div>
			<?php
			endif;
		endif;
	}
}

function shoestheme_helpers_post_user_likes( $user_id, $post_id, $is_comment ) {
	$post_users = '';
	$post_meta_users = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_liked" ) : get_post_meta( $post_id, "_user_liked" );
	if ( count( $post_meta_users ) != 0 ) {
		$post_users = $post_meta_users[0];
	}
	if ( !is_array( $post_users ) ) {
		$post_users = array();
	}
	if ( !in_array( $user_id, $post_users ) ) {
		$post_users['user-' . $user_id] = $user_id;
	}
	return $post_users;
} 

function shoestheme_helpers_post_ip_likes( $user_ip, $post_id, $is_comment ) {
	$post_users = '';
	$post_meta_users = ( $is_comment == 1 ) ? get_comment_meta( $post_id, "_user_comment_IP" ) : get_post_meta( $post_id, "_user_IP" );
	// Retrieve post information
	if ( count( $post_meta_users ) != 0 ) {
		$post_users = $post_meta_users[0];
	}
	if ( !is_array( $post_users ) ) {
		$post_users = array();
	}
	if ( !in_array( $user_ip, $post_users ) ) {
		$post_users['ip-' . $user_ip] = $user_ip;
	}
	return $post_users;
}

function shoestheme_helpers_get_image_by_id($id, $size, $class = array()){
	$image_attributes = wp_get_attachment_image_src( $id, $size );
	if($image_attributes){
		echo '<img src="'.esc_attr($image_attributes[0]).'" alt="">';
	}
}

function shoestheme_helpers_product_countdown($str){
	?>
	<ul class="ps-countdown" data-time="<?php echo esc_attr($str);?> 23:59:59">
        <li><span class="hours"></span>
            <p><?php esc_html_e('Hours', 'shoestheme-helpers');?></p>
        </li>
        <li class="divider">:</li>
        <li><span class="minutes"></span>
            <p><?php esc_html_e('Minutes', 'shoestheme-helpers');?></p>
        </li>
        <li class="divider">:</li>
        <li><span class="seconds"></span>
            <p><?php esc_html_e('Seconds', 'shoestheme-helpers');?></p>
        </li>
    </ul>
	<?php
}

function shoestheme_helpers_product_proccess($product){
	if($product->get_manage_stock() && $product->get_stock_quantity() > 0):
		$total_sales = get_post_meta($product->get_id(), 'total_sales', true);
      	$total_sales = !empty($total_sales) ? $total_sales : '0';
      	$total_stock = $product->get_stock_quantity();
		?>
		<div class="ps-product__status">
            <div class="sold"><?php esc_html_e('Already sold', 'shoestheme-helpers');?>: <span><?php echo intval($total_sales)?></span></div>
            <div class="avaiable"><?php esc_html_e('avaiable', 'shoestheme-helpers');?>: <span><?php echo intval($total_stock)?></span></div>
        </div>
        <div class="progress">
            <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo intval($total_sales*100/$total_stock)?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo intval($total_sales*100/$total_stock)?>%;"></div>
        </div>
		<?php
	endif;
}
?>